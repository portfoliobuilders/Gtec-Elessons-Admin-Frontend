import { BadRequestException } from '@nestjs/common';
import { diskStorage } from 'multer';
import { extname, join } from 'path';
import { randomBytes } from 'crypto';
import { mkdirSync } from 'fs';
import { MAX_UPLOAD_FILE_SIZE_BYTES } from '../common/utils/upload-limits';

// Curriculum entity photos (Grade/Subject/Chapter) — same local-disk stopgap
// and same validation rules as the avatar/KYC uploads in
// ../users/upload.config.ts (JPEG/PNG/WEBP, 15MB — see
// ../common/utils/upload-limits.ts). Kept as a sibling file rather than
// importing that one so the admin module doesn't reach into users/ for
// something that isn't user-scoped; the pattern (filter + disk storage
// shape) is deliberately identical.
const imageFileFilter = (_req: any, file: Express.Multer.File, cb: (error: Error | null, accept: boolean) => void) => {
  if (!/^image\/(jpeg|png|webp)$/.test(file.mimetype)) {
    return cb(new BadRequestException('Only JPEG, PNG, or WEBP images are allowed'), false);
  }
  cb(null, true);
};

// filename is prefixed with the :id route param (the grade/subject/chapter
// being photographed) — the same "owner id" convention avatarUploadOptions
// uses (userId), just sourced from the URL instead of the authenticated user.
function storageFor(subfolder: 'grades' | 'subjects' | 'chapters') {
  const uploadDir = join(process.cwd(), 'uploads', subfolder);
  mkdirSync(uploadDir, { recursive: true });
  return diskStorage({
    destination: uploadDir,
    filename: (req: any, file, cb) => {
      const entityId = req.params?.id ?? 'unknown';
      const unique = randomBytes(8).toString('hex');
      cb(null, `${entityId}-${unique}${extname(file.originalname)}`);
    },
  });
}

const limits = { fileSize: MAX_UPLOAD_FILE_SIZE_BYTES };

export const gradeIconUploadOptions = {
  storage: storageFor('grades'),
  fileFilter: imageFileFilter,
  limits,
};

export const subjectIconUploadOptions = {
  storage: storageFor('subjects'),
  fileFilter: imageFileFilter,
  limits,
};

export const chapterIconUploadOptions = {
  storage: storageFor('chapters'),
  fileFilter: imageFileFilter,
  limits,
};
