import { ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { toFlatPrice, toMultiFlatPrice, toProductVariants } from '../common/pricing/flatten-price';
import { resolveYoutubeId } from '../common/utils/youtube.util';

interface Requester {
  id: string;
  role: string;
}

@Injectable()
export class AdminCurriculumService {
  constructor(private prisma: PrismaService) { }

  async tree(requester?: Requester) {
    const teacherId = requester?.role === 'TEACHER' ? requester.id : undefined;
    const grades = await this.prisma.grade.findMany({
      where: teacherId ? { subjects: { some: { teacherId } } } : undefined,
      orderBy: { order: 'asc' },
      include: {
        subjects: {
          where: teacherId ? { teacherId } : undefined,
          orderBy: { order: 'asc' },
          include: {
            chapters: {
              orderBy: { order: 'asc' },
              include: {
                _count: { select: { lessons: true } },
                products: { where: { isActive: true }, include: { prices: true } },
              },
            },
            products: { where: { isActive: true }, include: { prices: true } },
          },
        },
        products: { where: { isActive: true }, include: { prices: true } },
      },
    });

    return grades.map((grade) => {
      const { products: gradeProducts, ...gradeRest } = grade;
      const gradePrice = toMultiFlatPrice(gradeProducts[0]);
      return {
        ...gradeRest,
        // `price`/`prices` stay derived from products[0] only — unchanged,
        // for existing callers that only ever read those. `products` below
        // is the new, complete view: every active variant (e.g. RECORDED
        // and LIVE_AND_RECORDED both), not just whichever came first.
        ...(gradePrice?.price ? { price: gradePrice.price } : {}),
        ...(gradePrice ? { prices: gradePrice.prices } : {}),
        products: toProductVariants(gradeProducts),
        subjects: grade.subjects.map((subject) => {
          const subjectPrice = toMultiFlatPrice(subject.products[0]);
          return {
            ...this.toSubjectResponse(subject),
            products: toProductVariants(subject.products),
            chapters: subject.chapters.map((chapter) => {
              const { products: chapterProducts, ...chapterRest } = chapter;
              const chapterPrice = toMultiFlatPrice(chapterProducts[0]);
              return {
                ...chapterRest,
                ...(chapterPrice?.price ? { price: chapterPrice.price } : {}),
                ...(chapterPrice ? { prices: chapterPrice.prices } : {}),
                products: toProductVariants(chapterProducts),
              };
            }),
            ...(subjectPrice?.price ? { price: subjectPrice.price } : {}),
            ...(subjectPrice ? { prices: subjectPrice.prices } : {}),
          };
        }),
      };
    });
  }

  async createGrade(d: any) {
    try {
      return await this.prisma.grade.create({
        data: {
          name: d.name,
          board: d.board ?? 'CBSE',
          syllabus: d.syllabus,
          description: d.description ?? null,
          ...this.buildTrailerData(d),
          order: d.order ?? 0,
        },
      });
    } catch (error) {
      this.handleGradeUniqueConflict(error, d.name, d.board ?? 'CBSE');
      throw error;
    }
  }
  async updateGrade(id: string, d: any) {
    try {
      const { thumbnailUrl, ...rest } = d;
      return await this.prisma.grade.update({ where: { id }, data: { ...rest, ...this.buildTrailerData(d) } });
    } catch (error) {
      this.handleGradeUniqueConflict(error, d.name, d.board);
      throw error;
    }
  }

  // Blocks deletion when subjects exist — cascading a grade delete would silently
  // wipe subjects → chapters → lessons → purchased enrollments (irreversible data
  // loss). A clear 409 forces the admin to clean up explicitly.
  async deleteGrade(id: string) {
    const grade = await this.prisma.grade.findUnique({
      where: { id },
      include: { _count: { select: { subjects: true } } },
    });
    if (!grade) throw new NotFoundException('Grade not found');
    if (grade._count.subjects > 0) {
      throw new ConflictException(
        `Cannot delete grade "${grade.name}": it has ${grade._count.subjects} subject(s). ` +
        'Delete or reassign all subjects first.',
      );
    }
    return this.prisma.grade.delete({ where: { id } });
  }

  // Sets/clears the grade's photo (iconUrl). Called from the POST/DELETE
  // .../photo routes — the file itself is already saved to disk by the
  // FileInterceptor before this runs; this just persists its URL.
  async setGradeIcon(id: string, iconUrl: string | null) {
    await this.ensureGradeExists(id);
    return this.prisma.grade.update({ where: { id }, data: { iconUrl } });
  }

  // teacherId and teacherName are NOT taken from the client DTO.
  // TEACHER callers automatically become the subject owner; ADMIN/SUPER_ADMIN
  // leave both null so the assignment can be done later via PATCH.
  async createSubject(gradeId: string, d: any, requester: Requester) {
    let teacherId: string | null = null;
    let teacherName: string | null = null;

    if (requester.role === 'TEACHER') {
      teacherId = requester.id;
      // Fetch the teacher's display name from the DB so it's always accurate.
      const teacher = await this.prisma.user.findUnique({ where: { id: requester.id }, select: { name: true } });
      teacherName = teacher?.name ?? null;
    }

    const created = await this.prisma.subject.create({
      data: {
        name: d.name,
        code: d.code,
        description: d.description ?? null,
        ...this.buildTrailerData(d),
        gradeId,
        teacherName,
        teacherId,
        order: d.order ?? 0,
        iconUrl: d.iconUrl ?? null,
      },
    });

    return this.toSubjectResponse(created);
  }

  async updateSubject(id: string, d: any) {
    const { thumbnailUrl, ...rest } = d;
    const updated = await this.prisma.subject.update({ where: { id }, data: { ...rest, ...this.buildTrailerData(d) } });
    return this.toSubjectResponse(updated);
  }

  async getSubject(id: string) {
    const subject = await this.prisma.subject.findUnique({
      where: { id },
      include: {
        chapters: {
          orderBy: { order: 'asc' },
          include: { _count: { select: { lessons: true } } },
        },
      },
    });
    if (!subject) throw new NotFoundException('Subject not found');
    return {
      ...this.toSubjectResponse(subject),
      chapters: subject.chapters,
    };
  }
  async deleteSubject(id: string) {
    return this.prisma.$transaction(async (tx) => {
      const subject = await tx.subject.findUnique({
        where: { id },
        include: {
          chapters: {
            select: {
              id: true,
              lessons: { select: { id: true } },
            },
          },
          products: { select: { id: true } },
        },
      });
      if (!subject) throw new NotFoundException('Subject not found');

      const chapterIds = subject.chapters.map((chapter) => chapter.id);
      const lessonIds = subject.chapters.flatMap((chapter) => chapter.lessons.map((lesson) => lesson.id));
      const subjectProductIds = subject.products.map((product) => product.id);
      const chapterProducts = chapterIds.length
        ? await tx.product.findMany({ where: { chapterId: { in: chapterIds } }, select: { id: true } })
        : [];
      const productIds = [...new Set([...subjectProductIds, ...chapterProducts.map((product) => product.id)])];
      const orderItems = productIds.length
        ? await tx.orderItem.findMany({ where: { productId: { in: productIds } }, select: { orderId: true } })
        : [];
      const orderIds = [...new Set(orderItems.map((item) => item.orderId))];

      if (lessonIds.length) {
        await tx.doubt.deleteMany({ where: { lessonId: { in: lessonIds } } });
      }

      await tx.enrollment.deleteMany({
        where: {
          OR: [
            { subjectId: id },
            ...(chapterIds.length ? [{ chapterId: { in: chapterIds } }] : []),
            ...(productIds.length ? [{ productId: { in: productIds } }] : []),
          ],
        },
      });

      if (productIds.length) {
        await tx.cartItem.deleteMany({ where: { productId: { in: productIds } } });
        await tx.orderItem.deleteMany({ where: { productId: { in: productIds } } });
        await tx.review.deleteMany({ where: { productId: { in: productIds } } });
      }

      await tx.review.deleteMany({ where: { subjectId: id } });
      await tx.assignment.deleteMany({ where: { subjectId: id } });
      await tx.liveClass.deleteMany({ where: { subjectId: id } });
      await tx.assessment.deleteMany({
        where: {
          OR: [
            { subjectId: id },
            ...(chapterIds.length ? [{ chapterId: { in: chapterIds } }] : []),
          ],
        },
      });
      await tx.batch.deleteMany({ where: { subjectId: id } });

      if (productIds.length) await tx.product.deleteMany({ where: { id: { in: productIds } } });

      const deleted = await tx.subject.delete({ where: { id } });

      if (orderIds.length) {
        await tx.order.deleteMany({
          where: {
            id: { in: orderIds },
            items: { none: {} },
          },
        });
      }

      return deleted;
    });
  }

  // Sets/clears the subject's photo (iconUrl) — reuses toSubjectResponse so
  // the shape matches every other subject-returning route.
  async setSubjectIcon(id: string, iconUrl: string | null) {
    await this.ensureSubjectExists(id);
    const updated = await this.prisma.subject.update({ where: { id }, data: { iconUrl } });
    return this.toSubjectResponse(updated);
  }

  createChapter(subjectId: string, d: any) {
    return this.prisma.chapter.create({
      data: { name: d.name, description: d.description ?? null, ...this.buildTrailerData(d), subjectId, order: d.order ?? 0 },
    });
  }
  updateChapter(id: string, d: any) {
    const { thumbnailUrl, ...rest } = d;
    return this.prisma.chapter.update({ where: { id }, data: { ...rest, ...this.buildTrailerData(d) } });
  }
  deleteChapter(id: string) { return this.prisma.chapter.delete({ where: { id } }); }

  // Sets/clears the chapter's photo (iconUrl).
  async setChapterIcon(id: string, iconUrl: string | null) {
    await this.ensureChapterExists(id);
    return this.prisma.chapter.update({ where: { id }, data: { iconUrl } });
  }

  async setGradeTrailer(id: string, youtubeId: string, thumbnailUrl?: string) {
    await this.ensureGradeExists(id);
    const updated = await this.prisma.grade.update({
      where: { id },
      data: this.buildTrailerData({ trailerYoutubeId: youtubeId, thumbnailUrl }),
    });
    return this.toTrailerResponse('gradeId', updated.id, updated.trailerYoutubeId);
  }

  async setSubjectTrailer(id: string, youtubeId: string, thumbnailUrl?: string) {
    await this.ensureSubjectExists(id);
    const updated = await this.prisma.subject.update({
      where: { id },
      data: this.buildTrailerData({ trailerYoutubeId: youtubeId, thumbnailUrl }),
    });
    return this.toTrailerResponse('subjectId', updated.id, updated.trailerYoutubeId);
  }

  async setChapterTrailer(id: string, youtubeId: string, thumbnailUrl?: string) {
    await this.ensureChapterExists(id);
    const updated = await this.prisma.chapter.update({
      where: { id },
      data: this.buildTrailerData({ trailerYoutubeId: youtubeId, thumbnailUrl }),
    });
    return this.toTrailerResponse('chapterId', updated.id, updated.trailerYoutubeId);
  }

  lessonsByChapter(chapterId: string) {
    return this.prisma.lesson.findMany({
      where: { chapterId },
      orderBy: { order: 'asc' },
      include: { resources: true, batches: { include: { batch: { select: { id: true, name: true } } } } },
    });
  }

  async createLesson(chapterId: string, d: any, requester: Requester) {
    await this.assertChapterOwnership(chapterId, requester);
    const lesson = await this.prisma.lesson.create({
      data: { title: d.title, description: d.description ?? null, chapterId, order: d.order ?? 0, isFreePreview: d.isFreePreview ?? false, isPublished: d.isPublished ?? false },
    });
    if (Array.isArray(d.batchIds)) await this.syncLessonBatches(lesson.id, d.batchIds);
    return lesson;
  }

  async updateLesson(id: string, d: any, requester: Requester) {
    const existing = await this.prisma.lesson.findUnique({ where: { id }, select: { chapterId: true } });
    if (!existing) throw new NotFoundException('Lesson not found');
    await this.assertChapterOwnership(existing.chapterId, requester);
    const { batchIds, ...rest } = d;
    const lesson = await this.prisma.lesson.update({ where: { id }, data: rest });
    if (Array.isArray(batchIds)) await this.syncLessonBatches(id, batchIds);
    return lesson;
  }
  deleteLesson(id: string) { return this.prisma.lesson.delete({ where: { id } }); }

  // TEACHER may only manage lessons/resources under a subject they teach;
  // ADMIN/SUPER_ADMIN are unrestricted.
  private async assertChapterOwnership(chapterId: string, requester: Requester) {
    if (requester.role !== 'TEACHER') return;
    const chapter = await this.prisma.chapter.findUnique({
      where: { id: chapterId },
      select: { subject: { select: { teacherId: true } } },
    });
    if (!chapter || chapter.subject.teacherId !== requester.id) {
      throw new ForbiddenException('You can only manage content for subjects you teach');
    }
  }

  private async syncLessonBatches(lessonId: string, batchIds: string[]) {
    await this.prisma.lessonBatch.deleteMany({ where: { lessonId } });
    if (batchIds.length) {
      await this.prisma.lessonBatch.createMany({
        data: batchIds.map((batchId) => ({ lessonId, batchId })),
        skipDuplicates: true,
      });
    }
  }

  async reorder(entity: 'grade' | 'subject' | 'chapter' | 'lesson', items: { id: string; order: number }[]) {
    const model: any =
      entity === 'grade' ? this.prisma.grade
        : entity === 'subject' ? this.prisma.subject
          : entity === 'chapter' ? this.prisma.chapter
            : this.prisma.lesson;
    await this.prisma.$transaction(items.map((i) => model.update({ where: { id: i.id }, data: { order: i.order } })));
    return { reordered: items.length };
  }

  async setPublished(entity: 'lesson' | 'chapter', id: string, isPublished: boolean) {
    if (entity === 'lesson') return this.prisma.lesson.update({ where: { id }, data: { isPublished } });
    await this.prisma.lesson.updateMany({ where: { chapterId: id }, data: { isPublished } });
    return { chapterId: id, isPublished };
  }

  // Attaches a note/PDF/PYQ to a lesson or a chapter. fileKey holds any URL
  // (a Drive link today, a signed cloud URL later) — students only ever see
  // this through the access-gated GET /lessons/:id response.
  async createResource(scope: { chapterId?: string; lessonId?: string }, d: any, requester: Requester) {
    const chapterId = scope.chapterId ?? (scope.lessonId ? (await this.chapterIdForLesson(scope.lessonId)) : null);
    if (chapterId) await this.assertChapterOwnership(chapterId, requester);
    return this.prisma.resource.create({
      data: {
        type: d.type ?? 'NOTE',
        title: d.title,
        fileKey: d.fileKey,
        pageCount: d.pageCount ?? null,
        sizeBytes: d.sizeBytes ?? null,
        isDownloadable: d.isDownloadable ?? true,
        lessonId: scope.lessonId ?? null,
        chapterId: scope.lessonId ? null : scope.chapterId ?? null,
      },
    });
  }

  private async chapterIdForLesson(lessonId: string): Promise<string | null> {
    const lesson = await this.prisma.lesson.findUnique({ where: { id: lessonId }, select: { chapterId: true } });
    return lesson?.chapterId ?? null;
  }

  private toSubjectResponse(subject: {
    id: string;
    name: string;
    code: string | null;
    description?: string | null;
    gradeId: string;
    order: number;
    iconUrl: string | null;
    trailerYoutubeId?: string | null;
    trailerThumbnailUrl?: string | null;
  }) {
    return {
      id: subject.id,
      name: subject.name,
      code: subject.code,
      ...(subject.description ? { description: subject.description } : {}),
      gradeId: subject.gradeId,
      order: subject.order,
      iconUrl: subject.iconUrl,
      trailerYoutubeId: subject.trailerYoutubeId ?? null,
      trailerThumbnailUrl: subject.trailerThumbnailUrl ?? null,
    };
  }

  // Accepts either a bare 11-char id or a full YouTube URL in
  // trailerYoutubeId — resolveYoutubeId throws a 400 explaining the accepted
  // formats if neither matches.
  private buildTrailerData(d: { trailerYoutubeId?: string; thumbnailUrl?: string }) {
    if (d.trailerYoutubeId === undefined) return {};
    const youtubeId = resolveYoutubeId(d.trailerYoutubeId);
    return {
      trailerYoutubeId: youtubeId,
      trailerThumbnailUrl: d.thumbnailUrl ?? `https://img.youtube.com/vi/${youtubeId}/hqdefault.jpg`,
    };
  }

  private toTrailerResponse(key: 'gradeId' | 'subjectId' | 'chapterId', id: string, youtubeId: string | null) {
    return {
      [key]: id,
      youtubeId,
      embedUrl: `https://www.youtube.com/embed/${youtubeId}`,
      verified: true,
    };
  }

  private async ensureGradeExists(id: string) {
    const grade = await this.prisma.grade.findUnique({ where: { id }, select: { id: true } });
    if (!grade) throw new NotFoundException('Grade not found');
  }

  private async ensureSubjectExists(id: string) {
    const subject = await this.prisma.subject.findUnique({ where: { id }, select: { id: true } });
    if (!subject) throw new NotFoundException('Subject not found');
  }

  private async ensureChapterExists(id: string) {
    const chapter = await this.prisma.chapter.findUnique({ where: { id }, select: { id: true } });
    if (!chapter) throw new NotFoundException('Chapter not found');
  }

  private handleGradeUniqueConflict(error: unknown, name?: string, board?: string) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
      const label = name && board ? `"${name}" (${board})` : 'with this name and board';
      throw new ConflictException(`Grade ${label} already exists`);
    }
  }

  deleteResource(id: string) { return this.prisma.resource.delete({ where: { id } }); }
}
