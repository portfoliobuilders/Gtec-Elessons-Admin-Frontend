import { BadRequestException, Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { randomBytes } from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { UpdateAssignmentDto } from './dto/feature.dto';

interface Requester {
    id: string;
    role: string;
}

@Injectable()
export class AdminFeatureService {
    constructor(
        private prisma: PrismaService,
        private notifications: NotificationsService,
    ) { }

    // Team invites
    listTeamInvites() {
        return this.prisma.teamInvite.findMany({
            orderBy: { createdAt: 'desc' },
            include: { inviter: { select: { id: true, name: true, email: true } } },
        });
    }

    async createTeamInvite(inviterId: string, dto: { email: string; role?: 'TEACHER' | 'ADMIN'; teamName?: string }) {
        const token = randomBytes(16).toString('hex');
        // Storage still uses the Prisma TeamInviteRole enum (OWNER/ADMIN/MEMBER);
        // acceptTeamInvite() below maps ADMIN->ADMIN and everything else->TEACHER,
        // so MEMBER is the correct stored value for a teacher invite.
        const storedRole = dto.role === 'ADMIN' ? 'ADMIN' : 'MEMBER';
        const invite = await this.prisma.teamInvite.create({
            data: {
                inviterId,
                email: dto.email.toLowerCase(),
                role: storedRole,
                teamName: dto.teamName,
                token,
                expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
            },
            include: { inviter: { select: { id: true, name: true, email: true } } },
        });
        // Same dev-only gating as sendVerificationEmail's devVerifyToken — lets
        // localhost testing accept an invite without real email delivery.
        const dev = process.env.ALLOW_DEV_LOGIN === 'true';
        return { ...invite, ...(dev ? { devInviteToken: token } : {}) };
    }

    async acceptTeamInvite(token: string, userId: string) {
        const invite = await this.prisma.teamInvite.findUnique({ where: { token } });
        if (!invite) throw new NotFoundException('Invite not found');
        if (invite.usedAt) throw new BadRequestException('Invite already used');
        if (invite.expiresAt && invite.expiresAt < new Date()) throw new BadRequestException('Invite expired');

        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!user) throw new NotFoundException('User not found');
        if (invite.email && user.email && invite.email.toLowerCase() !== user.email.toLowerCase()) {
            throw new ForbiddenException('This invite does not match your account email');
        }

        const nextRole = invite.role === 'OWNER' || invite.role === 'ADMIN' ? 'ADMIN' : 'TEACHER';

        await this.prisma.$transaction([
            this.prisma.user.update({ where: { id: userId }, data: { role: nextRole } }),
            this.prisma.teamInvite.update({ where: { id: invite.id }, data: { usedAt: new Date() } }),
        ]);

        return { accepted: true, role: nextRole };
    }

    // Assignments / grading queue

    // TEACHER sees only assignments tied to subjects they teach;
    // ADMIN/SUPER_ADMIN gets the full unfiltered queue, as before.
    listAssignments(requester?: Requester) {
        const teacherId = requester?.role === 'TEACHER' ? requester.id : undefined;
        return this.prisma.assignment.findMany({
            where: teacherId ? { subject: { teacherId } } : undefined,
            orderBy: { createdAt: 'desc' },
            include: {
                teacher: { select: { id: true, name: true, email: true } },
                subject: { select: { id: true, name: true } },
                _count: { select: { submissions: true } },
            },
        });
    }

    // TEACHER may only view/grade submissions for assignments under a subject
    // they teach; ADMIN/SUPER_ADMIN are unrestricted.
    private async assertAssignmentOwnership(assignmentId: string, requester?: Requester) {
        if (requester?.role !== 'TEACHER') return;
        const assignment = await this.prisma.assignment.findUnique({
            where: { id: assignmentId },
            select: { subject: { select: { teacherId: true } } },
        });
        if (!assignment) throw new NotFoundException('Assignment not found');
        if (assignment.subject?.teacherId !== requester.id) {
            throw new ForbiddenException('You can only manage assignments for subjects you teach');
        }
    }

    async createAssignment(dto: {
        title: string;
        description?: string;
        teacherId: string;
        subjectId?: string;
        dueDate?: string;
        totalMarks?: number;
        isPublished?: boolean;
    }) {
        return this.prisma.assignment.create({
            data: {
                title: dto.title,
                description: dto.description,
                teacherId: dto.teacherId,
                subjectId: dto.subjectId,
                dueDate: dto.dueDate ? new Date(dto.dueDate) : null,
                totalMarks: dto.totalMarks ?? 100,
                isPublished: dto.isPublished ?? true,
            },
        });
    }

    async updateAssignment(id: string, dto: UpdateAssignmentDto) {
        return this.prisma.assignment.update({
            where: { id },
            data: { ...dto, dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined },
        });
    }

    async deleteAssignment(id: string) {
        await this.prisma.assignment.delete({ where: { id } });
        return { deleted: true };
    }

    async listSubmissions(assignmentId: string, requester?: Requester) {
        await this.assertAssignmentOwnership(assignmentId, requester);
        return this.prisma.assignmentSubmission.findMany({
            where: { assignmentId },
            orderBy: { createdAt: 'asc' },
            include: { student: { select: { id: true, name: true, email: true } } },
        });
    }

    async submitAssignment(studentId: string, dto: { assignmentId: string; answers?: Record<string, unknown> }) {
        const existing = await this.prisma.assignmentSubmission.findUnique({
            where: { assignmentId_studentId: { assignmentId: dto.assignmentId, studentId } },
        });

        if (existing) {
            return this.prisma.assignmentSubmission.update({
                where: { id: existing.id },
                data: { answers: (dto.answers ?? existing.answers ?? {}) as any, status: 'SUBMITTED', submittedAt: new Date() },
            });
        }

        return this.prisma.assignmentSubmission.create({
            data: {
                assignmentId: dto.assignmentId,
                studentId,
                answers: (dto.answers ?? {}) as any,
                status: 'SUBMITTED',
                submittedAt: new Date(),
            },
        });
    }

    async gradeSubmission(id: string, dto: { score?: number; feedback?: string }, requester?: Requester) {
        const submission = await this.prisma.assignmentSubmission.findUnique({
            where: { id },
            select: { assignmentId: true },
        });
        if (!submission) throw new NotFoundException('Submission not found');
        await this.assertAssignmentOwnership(submission.assignmentId, requester);
        return this.prisma.assignmentSubmission.update({
            where: { id },
            data: {
                score: dto.score,
                feedback: dto.feedback,
                status: 'GRADED',
            },
        });
    }

    // Reviews
    listReviews() {
        return this.prisma.review.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                user: { select: { id: true, name: true, email: true } },
                product: { select: { id: true, title: true } },
                subject: { select: { id: true, name: true } },
            },
        });
    }

    async createReview(userId: string, dto: { productId?: string; subjectId?: string; rating: number; comment?: string }) {
        if (dto.rating < 1 || dto.rating > 5) throw new BadRequestException('Rating must be between 1 and 5');
        return this.prisma.review.create({
            data: {
                userId,
                productId: dto.productId,
                subjectId: dto.subjectId,
                rating: dto.rating,
                comment: dto.comment,
            },
        });
    }

    async updateReviewApproval(id: string, isApproved: boolean) {
        return this.prisma.review.update({ where: { id }, data: { isApproved } });
    }

    // Broadcast — sends an in-app (+ best-effort push) notification to every
    // student, or just those in one grade if gradeId is given.
    async broadcast(dto: { title: string; body: string; gradeId?: string }) {
        const where: any = { role: 'STUDENT' };
        if (dto.gradeId) where.studentProfile = { gradeId: dto.gradeId };
        const students = await this.prisma.user.findMany({ where, select: { id: true } });
        await Promise.all(students.map((s) => this.notifications.push(s.id, 'ANNOUNCEMENT', dto.title, dto.body)));
        return { sent: students.length };
    }

    // Growth & insights
    async overview() {
        const [students, teachers, activeEnrollments, pendingOrders, reviews] = await Promise.all([
            this.prisma.user.count({ where: { role: 'STUDENT' } }),
            this.prisma.user.count({ where: { role: 'TEACHER' } }),
            this.prisma.enrollment.count({ where: { status: 'ACTIVE' } }),
            this.prisma.order.count({ where: { status: 'PENDING' } }),
            this.prisma.review.aggregate({ _avg: { rating: true } }),
        ]);

        return {
            students,
            teachers,
            activeEnrollments,
            pendingOrders,
            averageRating: reviews._avg.rating ?? null,
        };
    }

    async funnel() {
        const activeEnrollments = await this.prisma.enrollment.count({ where: { status: 'ACTIVE' } });
        return {
            visitors: null,
            trialStarts: null,
            paidEnrollments: activeEnrollments,
            conversionRate: null,
            note: 'Visitor and trial-start tracking are not instrumented yet.',
        };
    }

    async courses() {
        const items = await this.prisma.product.findMany({
            where: { isActive: true },
            select: {
                id: true,
                title: true,
                _count: { select: { enrollments: true } },
            },
            orderBy: { title: 'asc' },
        });

        return items.map((item) => ({ id: item.id, title: item.title, enrollments: item._count.enrollments }));
    }

    async teachers() {
        const items = await this.prisma.user.findMany({
            where: { role: 'TEACHER' },
            select: {
                id: true,
                name: true,
                email: true,
                _count: { select: { answeredDoubts: true } },
            },
            orderBy: { name: 'asc' },
        });

        return items.map((item) => ({ id: item.id, name: item.name, email: item.email, answeredDoubts: item._count.answeredDoubts }));
    }
}
