import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { GrantEnrollmentDto } from './dto/enrollments.dto';

@Injectable()
export class AdminEnrollmentsService {
  constructor(private prisma: PrismaService) {}

  async grantSubject(dto: GrantEnrollmentDto) {
    const student = await this.prisma.user.findUnique({
      where: { id: dto.studentId },
      select: { id: true, email: true, role: true },
    });
    if (!student) throw new NotFoundException('Student not found');
    if (student.role !== 'STUDENT') throw new BadRequestException('User is not a student');

    const subject = await this.prisma.subject.findUnique({
      where: { id: dto.subjectId },
      select: { id: true, name: true, gradeId: true },
    });
    if (!subject) throw new NotFoundException('Subject not found');

    let product = await this.prisma.product.findFirst({
      where: {
        type: 'SUBJECT',
        subjectId: subject.id,
      },
      orderBy: [{ isActive: 'desc' }, { accessDays: 'desc' }],
    });
    if (!product) {
      product = await this.prisma.product.create({
        data: {
          type: 'SUBJECT',
          format: 'RECORDED',
          title: `Manual grant - ${subject.name}`,
          isActive: false,
          subjectId: subject.id,
          accessDays: 365,
        },
      });
    }

    const now = new Date();
    const expiresAt = product.accessDays
      ? new Date(now.getTime() + product.accessDays * 24 * 60 * 60 * 1000)
      : null;

    const existing = await this.prisma.enrollment.findFirst({
      where: {
        userId: student.id,
        scopeType: 'SUBJECT',
        subjectId: subject.id,
        productId: product.id,
        orderItemId: null,
      },
      orderBy: { startsAt: 'desc' },
    });

    const enrollment = existing
      ? await this.prisma.enrollment.update({
          where: { id: existing.id },
          data: {
            format: product.format,
            gradeId: null,
            chapterId: null,
            status: 'ACTIVE',
            startsAt: now,
            expiresAt,
          },
        })
      : await this.prisma.enrollment.create({
          data: {
            userId: student.id,
            productId: product.id,
            scopeType: 'SUBJECT',
            format: product.format,
            subjectId: subject.id,
            status: 'ACTIVE',
            startsAt: now,
            expiresAt,
          },
        });

    return { student, subject, product, enrollment };
  }
}
