import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AdminOrdersService {
  constructor(private prisma: PrismaService) {}

  async list(status?: string, take = 50, skip = 0) {
    const where: any = {};
    if (status) where.status = status;
    const [total, orders] = await Promise.all([
      this.prisma.order.count({ where }),
      this.prisma.order.findMany({
        where,
        take,
        skip,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true, orderNumber: true, status: true, currency: true,
          subtotalCents: true, taxCents: true, totalCents: true, createdAt: true,
          billingName: true, billingPhone: true, billingAddress: true,
          billingCity: true, billingState: true, billingPincode: true,
          user: { select: { id: true, name: true, email: true } },
        },
      }),
    ]);
    return { total, orders };
  }

  async detail(orderId: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        items: true,
        user: { select: { id: true, name: true, email: true, phone: true } },
      },
    });
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }
}
