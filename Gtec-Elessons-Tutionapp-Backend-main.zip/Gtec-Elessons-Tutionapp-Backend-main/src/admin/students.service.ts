import { ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AdminStudentsService {
  constructor(private prisma: PrismaService) {}

  async list(search?: string, take = 50, skip = 0) {
    const where: any = { role: 'STUDENT' };
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }
    const [total, users] = await Promise.all([
      this.prisma.user.count({ where }),
      this.prisma.user.findMany({
        where, take, skip, orderBy: { createdAt: 'desc' },
        select: {
          id: true, name: true, email: true, phone: true, status: true, createdAt: true,
          studentProfile: { select: { board: true, grade: { select: { name: true } } } },
          _count: { select: { enrollments: true } },
        },
      }),
    ]);
    return { total, students: users };
  }

  async detail(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        studentProfile: { include: { grade: true } },
        enrollments: { include: { product: { select: { title: true } } } },
        orders: {
          where: { status: 'PAID' },
          select: {
            orderNumber: true, totalCents: true, currency: true, createdAt: true,
            billingName: true, billingPhone: true, billingAddress: true,
            billingCity: true, billingState: true, billingPincode: true,
          },
        },
        attempts: { where: { status: 'SUBMITTED' }, include: { assessment: { select: { title: true } } } },
      },
    });
    if (!user) throw new NotFoundException('Student not found');
    return {
      ...user,
      attempts: user.attempts.map((a) => ({
        ...a,
        scorePercent: a.totalMarks ? Math.round(((a.score ?? 0) / a.totalMarks) * 100) : null,
      })),
    };
  }

  async setStatus(userId: string, status: 'ACTIVE' | 'SUSPENDED', callerRole: string, callerId: string) {
    await this.assertCanModify(userId, callerRole, callerId);
    return this.prisma.user.update({ where: { id: userId }, data: { status } });
  }
  async setRole(userId: string, role: 'STUDENT' | 'TEACHER' | 'ADMIN', callerRole: string, callerId: string) {
    await this.assertCanModify(userId, callerRole, callerId);
    return this.prisma.user.update({ where: { id: userId }, data: { role } });
  }

  // Hard delete — only reachable when the account is genuinely empty. A
  // handful of the FKs pointing at User are safe to cascade automatically
  // (StudentProfile, RefreshToken, an abandoned Cart/CartItem, etc. — see
  // ../../prisma/schema.prisma), but several are not:
  //   - Order.userId is ON DELETE RESTRICT — deleting a user with any order
  //     would fail with a raw FK error anyway, but we check first so the
  //     admin gets a clear reason instead of a 500/P2003.
  //   - Enrollment.userId is CASCADE — deleting a student with real access
  //     grants would silently destroy their purchase-derived access.
  //   - Subject.teacherId / Batch.teacherId are SET NULL — survives, but
  //     silently orphans "who teaches this" attribution on live content.
  //   - Assignment.teacherId is CASCADE, and Assignment→AssignmentSubmission
  //     is CASCADE too — deleting a teacher with assignments would delete
  //     every one of THEIR STUDENTS' submissions/grades, not just the
  //     teacher's own data. This is the sharpest one.
  // CartItem is deliberately NOT a blocker — an abandoned cart is transient
  // pre-purchase state, not content/payment history, so it's just left to
  // cascade away with the rest of the account.
  async remove(userId: string, callerRole: string, callerId: string) {
    await this.assertCanModify(userId, callerRole, callerId);

    const [orders, enrollments, subjectsTaught, batchesTaught, assignmentsCreated] = await Promise.all([
      this.prisma.order.count({ where: { userId } }),
      this.prisma.enrollment.count({ where: { userId } }),
      this.prisma.subject.count({ where: { teacherId: userId } }),
      this.prisma.batch.count({ where: { teacherId: userId } }),
      this.prisma.assignment.count({ where: { teacherId: userId } }),
    ]);

    const blockers: string[] = [];
    if (orders > 0) blockers.push(`${orders} order${orders === 1 ? '' : 's'}`);
    if (enrollments > 0) blockers.push(`${enrollments} active enrollment${enrollments === 1 ? '' : 's'}`);
    if (subjectsTaught > 0) blockers.push(`${subjectsTaught} subject${subjectsTaught === 1 ? '' : 's'} taught`);
    if (batchesTaught > 0) blockers.push(`${batchesTaught} batch${batchesTaught === 1 ? '' : 'es'} taught`);
    if (assignmentsCreated > 0) blockers.push(`${assignmentsCreated} assignment${assignmentsCreated === 1 ? '' : 's'} created`);

    if (blockers.length > 0) {
      throw new ConflictException(`Cannot delete: user has ${blockers.join(', ')}`);
    }

    await this.prisma.user.delete({ where: { id: userId } });
    return { success: true, deletedUserId: userId };
  }

  // Only a SUPER_ADMIN may change the role or status of an existing
  // ADMIN/SUPER_ADMIN account. A regular ADMIN may still act on TEACHER
  // and STUDENT targets, unchanged. Nobody — including a SUPER_ADMIN — may
  // change their OWN role/status through this endpoint: without this, a
  // SUPER_ADMIN caller passes the check above against their own account
  // (they're a SUPER_ADMIN modifying a SUPER_ADMIN target) and could
  // self-demote or self-suspend with no other SUPER_ADMIN able to reverse it.
  private async assertCanModify(userId: string, callerRole: string, callerId: string) {
    if (userId === callerId) {
      throw new ForbiddenException('You cannot change your own role or status through this endpoint');
    }
    const target = await this.prisma.user.findUnique({ where: { id: userId }, select: { role: true } });
    if (!target) throw new NotFoundException('User not found');
    if ((target.role === 'ADMIN' || target.role === 'SUPER_ADMIN') && callerRole !== 'SUPER_ADMIN') {
      throw new ForbiddenException('Only a Super Admin can modify another Admin');
    }
  }
}
