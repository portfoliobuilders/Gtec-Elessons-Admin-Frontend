import { BadRequestException, Body, Controller, Delete, Get, Param, Patch, Post, Query, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { AdminAnalyticsService } from './analytics.service';
import { AdminCurriculumService } from './curriculum.service';
import { AdminStudentsService } from './students.service';
import { AdminPricingService } from './pricing-admin.service';
import { AdminOrdersService } from './orders-admin.service';
import { AdminEnrollmentsService } from './enrollments-admin.service';
import { PaymentsService } from '../payments/payments.service';
import { AdminFeatureService } from './feature.service';
import { AdminConfigService } from './config-admin.service';
import {
  CreateGradeDto, UpdateGradeDto, CreateSubjectDto, UpdateSubjectDto, CreateChapterDto, UpdateChapterDto,
  CreateLessonDto, UpdateLessonDto, CreateResourceDto, ReorderDto, PublishDto, SetTrailerDto, CreateInlinePriceDto,
} from './dto/curriculum.dto';
import { SetStudentStatusDto, SetStudentRoleDto } from './dto/students.dto';
import { CreateProductPriceDto, UpdatePriceDto, UpdateProductPriceDto, CreateProductVariantDto } from './dto/pricing.dto';
import { RefundOrderDto } from './dto/orders.dto';
import { toFlatPrice, toMultiFlatPrice } from '../common/pricing/flatten-price';
import {
  CreateTeamInviteDto, AcceptTeamInviteDto, CreateAssignmentDto, UpdateAssignmentDto, SubmitAssignmentDto,
  GradeSubmissionDto, CreateReviewDto, ApproveReviewDto, BroadcastDto,
} from './dto/feature.dto';
import {
  UpdateSettingDto, CreateCountryDto, UpdateCountryDto, UpdateExchangeRateDto,
  CreateNotificationTemplateDto, UpdateNotificationTemplateDto,
} from './dto/config.dto';
import { gradeIconUploadOptions, subjectIconUploadOptions, chapterIconUploadOptions } from './upload.config';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN')
@Controller('admin')
export class AdminController {
  constructor(
    private analytics: AdminAnalyticsService,
    private curriculum: AdminCurriculumService,
    private students: AdminStudentsService,
    private pricing: AdminPricingService,
    private orders: AdminOrdersService,
    private enrollments: AdminEnrollmentsService,
    private payments: PaymentsService,
    private features: AdminFeatureService,
    private config: AdminConfigService,
  ) { }

  @Get('analytics/overview') overview() { return this.analytics.overview(); }
  @Get('analytics/top-courses') top(@Query('limit') l?: string) { return this.analytics.topCourses(l ? +l : 5); }
  @Get('analytics/recent-orders') recent(@Query('limit') l?: string) { return this.analytics.recentOrders(l ? +l : 10); }

  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Get('curriculum')
  tree(@CurrentUser() user: AuthUser) { return this.curriculum.tree(user); }

  @Post('grades')
  async createGrade(@Body() d: CreateGradeDto) {
    if (d.price && d.prices && d.prices.length > 0) {
      throw new BadRequestException('Provide either price or prices, not both');
    }
    const grade = await this.curriculum.createGrade(d);
    return this.withInlinePrice(grade, d.price, d.prices, (title) =>
      this.pricing.createGradeProduct(grade.id, { title, format: d.format, accessDays: d.accessDays, price: d.price, prices: d.prices }));
  }
  @Patch('grades/:id') updateGrade(@Param('id') id: string, @Body() d: UpdateGradeDto) { return this.curriculum.updateGrade(id, d); }
  @Post('grades/:id/trailer') setGradeTrailer(@Param('id') id: string, @Body() d: SetTrailerDto) {
    return this.curriculum.setGradeTrailer(id, d.youtubeId, d.thumbnailUrl);
  }
  @Delete('grades/:id') deleteGrade(@Param('id') id: string) { return this.curriculum.deleteGrade(id); }

  // Grade photo. Local-disk storage, same JPEG/PNG/WEBP + 15MB rule as
  // POST /me/avatar — see admin/upload.config.ts.
  @Post('grades/:id/photo')
  @UseInterceptors(FileInterceptor('file', gradeIconUploadOptions))
  async uploadGradePhoto(@Param('id') id: string, @UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('No file uploaded');
    return this.curriculum.setGradeIcon(id, this.uploadUrl('grades', file.filename));
  }
  @Delete('grades/:id/photo')
  removeGradePhoto(@Param('id') id: string) { return this.curriculum.setGradeIcon(id, null); }

  // TEACHER role also allowed — they can create subjects scoped to themselves
  // (teacherId auto-set server-side in AdminCurriculumService.createSubject).
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Post('grades/:gradeId/subjects')
  async createSubject(@CurrentUser() user: AuthUser, @Param('gradeId') gradeId: string, @Body() d: CreateSubjectDto) {
    if (d.price && d.prices && d.prices.length > 0) {
      throw new BadRequestException('Provide either price or prices, not both');
    }
    const subject = await this.curriculum.createSubject(gradeId, d, user);
    return this.withInlinePrice(subject, d.price, d.prices, (title) =>
      this.pricing.createSubjectProduct(subject.id, { title, format: d.format, accessDays: d.accessDays, price: d.price, prices: d.prices }));
  }
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Get('subjects/:id') getSubject(@Param('id') id: string) { return this.curriculum.getSubject(id); }
  @Patch('subjects/:id') updateSubject(@Param('id') id: string, @Body() d: UpdateSubjectDto) { return this.curriculum.updateSubject(id, d); }
  @Post('subjects/:id/trailer') setSubjectTrailer(@Param('id') id: string, @Body() d: SetTrailerDto) {
    return this.curriculum.setSubjectTrailer(id, d.youtubeId, d.thumbnailUrl);
  }
  @Delete('subjects/:id') deleteSubject(@Param('id') id: string) { return this.curriculum.deleteSubject(id); }

  // Subject photo. Same pattern as the grade photo routes above.
  @Post('subjects/:id/photo')
  @UseInterceptors(FileInterceptor('file', subjectIconUploadOptions))
  async uploadSubjectPhoto(@Param('id') id: string, @UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('No file uploaded');
    return this.curriculum.setSubjectIcon(id, this.uploadUrl('subjects', file.filename));
  }
  @Delete('subjects/:id/photo')
  removeSubjectPhoto(@Param('id') id: string) { return this.curriculum.setSubjectIcon(id, null); }

  @Post('subjects/:subjectId/chapters')
  async createChapter(@Param('subjectId') subjectId: string, @Body() d: CreateChapterDto) {
    if (d.price && d.prices && d.prices.length > 0) {
      throw new BadRequestException('Provide either price or prices, not both');
    }
    const chapter = await this.curriculum.createChapter(subjectId, d);
    return this.withInlinePrice(chapter, d.price, d.prices, (title) =>
      this.pricing.createChapterProduct(chapter.id, { title, format: d.format, accessDays: d.accessDays, price: d.price, prices: d.prices }));
  }
  @Patch('chapters/:id') updateChapter(@Param('id') id: string, @Body() d: UpdateChapterDto) { return this.curriculum.updateChapter(id, d); }
  @Post('chapters/:id/trailer') setChapterTrailer(@Param('id') id: string, @Body() d: SetTrailerDto) {
    return this.curriculum.setChapterTrailer(id, d.youtubeId, d.thumbnailUrl);
  }
  @Delete('chapters/:id') deleteChapter(@Param('id') id: string) { return this.curriculum.deleteChapter(id); }

  // Chapter photo. Same pattern as the grade/subject photo routes above.
  @Post('chapters/:id/photo')
  @UseInterceptors(FileInterceptor('file', chapterIconUploadOptions))
  async uploadChapterPhoto(@Param('id') id: string, @UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('No file uploaded');
    return this.curriculum.setChapterIcon(id, this.uploadUrl('chapters', file.filename));
  }
  @Delete('chapters/:id/photo')
  removeChapterPhoto(@Param('id') id: string) { return this.curriculum.setChapterIcon(id, null); }
  @Get('chapters/:id/lessons') chapterLessons(@Param('id') id: string) { return this.curriculum.lessonsByChapter(id); }

  // Teachers may also create/update lessons — scoped to subjects they teach
  // (enforced in AdminCurriculumService), unlike the rest of this controller.
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Post('chapters/:chapterId/lessons')
  createLesson(@CurrentUser() user: AuthUser, @Param('chapterId') chapterId: string, @Body() d: CreateLessonDto) {
    return this.curriculum.createLesson(chapterId, d, user);
  }

  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Patch('lessons/:id')
  updateLesson(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() d: UpdateLessonDto) { return this.curriculum.updateLesson(id, d, user); }

  @Delete('lessons/:id') deleteLesson(@Param('id') id: string) { return this.curriculum.deleteLesson(id); }

  // Attach/remove a note or PDF (by URL) on a lesson or chapter.
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Post('chapters/:chapterId/resources')
  createChapterResource(@CurrentUser() user: AuthUser, @Param('chapterId') chapterId: string, @Body() d: CreateResourceDto) {
    return this.curriculum.createResource({ chapterId }, d, user);
  }

  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Post('lessons/:lessonId/resources')
  createLessonResource(@CurrentUser() user: AuthUser, @Param('lessonId') lessonId: string, @Body() d: CreateResourceDto) {
    return this.curriculum.createResource({ lessonId }, d, user);
  }

  @Delete('resources/:id') deleteResource(@Param('id') id: string) { return this.curriculum.deleteResource(id); }

  @Post('curriculum/reorder')
  reorder(@Body() body: ReorderDto) {
    return this.curriculum.reorder(body.entity, body.items);
  }

  @Patch('curriculum/publish')
  publish(@Body() body: PublishDto) {
    return this.curriculum.setPublished(body.entity, body.id, body.isPublished);
  }

  @Get('students')
  listStudents(@Query('search') search?: string, @Query('take') take?: string, @Query('skip') skip?: string) {
    return this.students.list(search, take ? +take : 50, skip ? +skip : 0);
  }
  @Get('students/:id') studentDetail(@Param('id') id: string) { return this.students.detail(id); }
  @Patch('students/:id/status')
  studentStatus(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() b: SetStudentStatusDto) {
    return this.students.setStatus(id, b.status, user.role, user.id);
  }
  @Patch('students/:id/role')
  studentRole(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() b: SetStudentRoleDto) {
    return this.students.setRole(id, b.role, user.role, user.id);
  }
  // Generic user delete — same route family/role guard as status+role above.
  // Not student-specific: setStatus/setRole already operate on any role via
  // this "students" namespace, and remove() does the same (see
  // students.service.ts for the emptiness checks that gate it).
  @Delete('students/:id')
  removeStudent(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.students.remove(id, user.role, user.id);
  }

  @Get('pricing') pricingGrid() { return this.pricing.list(); }
  // Corrects an existing price's amount only — cannot create a price for a
  // product that never had one. A product's first price is set once, at
  // creation time, via the grade/subject/chapter CREATE routes' inline
  // `price` (below); the standalone POST .../pricing routes that used to add
  // it later are gone. To price a curriculum entity a second way (e.g. a
  // LIVE_AND_RECORDED option alongside its RECORDED one), create another
  // Product variant instead — see POST .../products below.
  @Patch('pricing/products/:productId')
  updatePrice(@Param('productId') productId: string, @Body() d: UpdatePriceDto) {
    return this.pricing.updatePrice(productId, d);
  }
  @Post('pricing/products/:productId/prices')
  createRegionalPrice(@Param('productId') productId: string, @Body() d: CreateProductPriceDto) {
    return this.pricing.createRegionalPrice(productId, d);
  }
  @Patch('pricing/products/:productId/prices/:priceId')
  updateRegionalPrice(@Param('productId') productId: string, @Param('priceId') priceId: string, @Body() d: UpdateProductPriceDto) {
    return this.pricing.updateRegionalPrice(productId, priceId, d);
  }
  @Delete('pricing/products/:productId/prices/:priceId')
  deleteRegionalPrice(@Param('productId') productId: string, @Param('priceId') priceId: string) {
    return this.pricing.deleteRegionalPrice(productId, priceId);
  }
  @Delete('pricing/products/:id') deleteProduct(@Param('id') id: string) { return this.pricing.deleteProduct(id); }

  // ---- Additional product variants (e.g. RECORDED + LIVE_AND_RECORDED for
  // the same grade/subject/chapter) ----
  // ADMIN/SUPER_ADMIN only (unlike the entity CREATE routes above, TEACHER
  // is not granted this — adding a second commercial package to a curriculum
  // entity is an admin/pricing decision, not a content-authoring one).
  // Rejects with 400 if an active product of the same type+format already
  // exists for this scope — see AdminPricingService.assertNoActiveDuplicateVariant.
  @Post('grades/:gradeId/products')
  createGradeProductVariant(@Param('gradeId') gradeId: string, @Body() d: CreateProductVariantDto) {
    if (d.price && d.prices && d.prices.length > 0) {
      throw new BadRequestException('Provide either price or prices, not both');
    }
    return this.pricing.createGradeProduct(gradeId, d);
  }
  @Post('subjects/:subjectId/products')
  createSubjectProductVariant(@Param('subjectId') subjectId: string, @Body() d: CreateProductVariantDto) {
    if (d.price && d.prices && d.prices.length > 0) {
      throw new BadRequestException('Provide either price or prices, not both');
    }
    return this.pricing.createSubjectProduct(subjectId, d);
  }
  @Post('chapters/:chapterId/products')
  createChapterProductVariant(@Param('chapterId') chapterId: string, @Body() d: CreateProductVariantDto) {
    if (d.price && d.prices && d.prices.length > 0) {
      throw new BadRequestException('Provide either price or prices, not both');
    }
    return this.pricing.createChapterProduct(chapterId, d);
  }

  // Orders (billing snapshot / invoice data source).
  @Get('orders')
  ordersList(@Query('status') status?: string, @Query('take') take?: string, @Query('skip') skip?: string) {
    return this.orders.list(status, take ? +take : 50, skip ? +skip : 0);
  }
  @Get('orders/:id') orderDetail(@Param('id') id: string) { return this.orders.detail(id); }

  // Reverses the Razorpay charge, marks the order REFUNDED, revokes its enrollments.
  @Post('orders/:id/refund')
  refundOrder(@Param('id') id: string, @Body() body: RefundOrderDto) {
    return this.payments.refundOrder(id, body?.reason);
  }

  @Post('students/:studentId/subjects/:subjectId/enrollments')
  grantEnrollment(@Param('studentId') studentId: string, @Param('subjectId') subjectId: string) {
    return this.enrollments.grantSubject({ studentId, subjectId });
  }

  @Get('team-invites') listTeamInvites() { return this.features.listTeamInvites(); }
  // Inviter identity comes from the verified JWT, never the body — mirrors the
  // acceptTeamInvite/submitAssignment/createReview pattern below.
  @Post('team-invites') createTeamInvite(@CurrentUser() user: AuthUser, @Body() body: CreateTeamInviteDto) {
    return this.features.createTeamInvite(user.id, body);
  }
  // Open to any authenticated user — the invitee redeeming their own invite,
  // not an admin acting on someone's behalf. userId always comes from the
  // verified JWT, never the body, so nobody can accept an invite as another user.
  @Roles()
  @Post('team-invites/accept')
  acceptTeamInvite(@CurrentUser() user: AuthUser, @Body() body: AcceptTeamInviteDto) {
    return this.features.acceptTeamInvite(body.token, user.id);
  }

  // Teachers may also list/grade assignments — scoped to subjects they teach
  // (enforced in AdminFeatureService), unlike the rest of this controller.
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Get('assignments')
  listAssignments(@CurrentUser() user: AuthUser) { return this.features.listAssignments(user); }

  @Post('assignments') createAssignment(@Body() body: CreateAssignmentDto) { return this.features.createAssignment(body); }
  @Post('subjects/:subjectId/assignments')
  createSubjectAssignment(@Param('subjectId') subjectId: string, @Body() body: CreateAssignmentDto) {
    return this.features.createAssignment({ ...body, subjectId });
  }
  @Patch('assignments/:id') updateAssignment(@Param('id') id: string, @Body() body: UpdateAssignmentDto) { return this.features.updateAssignment(id, body); }
  @Delete('assignments/:id') deleteAssignment(@Param('id') id: string) { return this.features.deleteAssignment(id); }

  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Get('assignments/:assignmentId/submissions')
  listSubmissions(@CurrentUser() user: AuthUser, @Param('assignmentId') assignmentId: string) {
    return this.features.listSubmissions(assignmentId, user);
  }
  // Open to any authenticated user — a student submitting their own work.
  // studentId always comes from the verified JWT, never the body.
  @Roles()
  @Post('assignments/:assignmentId/submissions')
  submitAssignment(@CurrentUser() user: AuthUser, @Param('assignmentId') assignmentId: string, @Body() body: SubmitAssignmentDto) {
    return this.features.submitAssignment(user.id, { ...body, assignmentId });
  }
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Patch('assignments/submissions/:id/grade')
  gradeSubmission(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() body: GradeSubmissionDto) {
    return this.features.gradeSubmission(id, body, user);
  }

  @Get('reviews') listReviews() { return this.features.listReviews(); }

  // Open to any authenticated user — a student leaving their own review.
  // userId always comes from the verified JWT, never the body.
  @Roles()
  @Post('reviews')
  createReview(@CurrentUser() user: AuthUser, @Body() body: CreateReviewDto) {
    return this.features.createReview(user.id, body);
  }
  @Roles()
  @Post('subjects/:subjectId/reviews')
  createSubjectReview(@CurrentUser() user: AuthUser, @Param('subjectId') subjectId: string, @Body() body: CreateReviewDto) {
    return this.features.createReview(user.id, { ...body, subjectId });
  }
  @Roles()
  @Post('pricing/products/:productId/reviews')
  createProductReview(@CurrentUser() user: AuthUser, @Param('productId') productId: string, @Body() body: CreateReviewDto) {
    return this.features.createReview(user.id, { ...body, productId });
  }
  @Patch('reviews/:id/approve') approveReview(@Param('id') id: string, @Body() body: ApproveReviewDto) {
    return this.features.updateReviewApproval(id, body.isApproved);
  }

  @Post('broadcast') broadcast(@Body() body: BroadcastDto) {
    return this.features.broadcast(body);
  }
  @Post('grades/:gradeId/broadcast') broadcastGrade(@Param('gradeId') gradeId: string, @Body() body: BroadcastDto) {
    return this.features.broadcast({ ...body, gradeId });
  }

  @Get('insights/overview') insightsOverview() { return this.features.overview(); }
  @Get('insights/funnel') insightsFunnel() { return this.features.funnel(); }
  @Get('insights/courses') insightsCourses() { return this.features.courses(); }
  @Get('insights/teachers') insightsTeachers() { return this.features.teachers(); }

  // ---- Settings / countries / exchange rates / notification templates ----

  @Get('settings') listSettings() { return this.config.listSettings(); }
  @Patch('settings/:key') updateSetting(@Param('key') key: string, @Body() d: UpdateSettingDto) {
    return this.config.updateSetting(key, d.value);
  }

  @Get('countries') listCountries() { return this.config.listCountries(); }
  @Post('countries') createCountry(@Body() d: CreateCountryDto) { return this.config.createCountry(d); }
  @Patch('countries/:code') updateCountry(@Param('code') code: string, @Body() d: UpdateCountryDto) {
    return this.config.updateCountry(code, d);
  }
  @Delete('countries/:code') deleteCountry(@Param('code') code: string) { return this.config.deleteCountry(code); }

  @Get('exchange-rates') listExchangeRates() { return this.config.listExchangeRates(); }
  @Patch('exchange-rates/:currency') updateExchangeRate(@Param('currency') currency: string, @Body() d: UpdateExchangeRateDto) {
    return this.config.updateExchangeRate(currency, d.rateToInr);
  }

  @Get('notification-templates') listNotificationTemplates() { return this.config.listNotificationTemplates(); }
  @Post('notification-templates') createNotificationTemplate(@Body() d: CreateNotificationTemplateDto) {
    return this.config.createNotificationTemplate(d);
  }
  @Patch('notification-templates/:type') updateNotificationTemplate(@Param('type') type: string, @Body() d: UpdateNotificationTemplateDto) {
    return this.config.updateNotificationTemplate(type, d);
  }
  @Delete('notification-templates/:type') deleteNotificationTemplate(@Param('type') type: string) {
    return this.config.deleteNotificationTemplate(type);
  }

  // Turns a saved upload's filename into the public URL stored on the entity —
  // same APP_BASE_URL + /uploads/<subfolder>/<filename> convention as
  // POST /me/avatar (users.controller.ts).
  private uploadUrl(subfolder: 'grades' | 'subjects' | 'chapters', filename: string): string {
    const baseUrl = (process.env.APP_BASE_URL ?? 'http://localhost:3000').replace(/\/+$/, '');
    return `${baseUrl}/uploads/${subfolder}/${filename}`;
  }

  // Shared by the grade/subject/chapter CREATE routes' optional inline `price`.
  // When price is omitted, the entity is returned untouched. When present,
  // the product is created through the same AdminPricingService methods that
  // used to back the now-removed standalone POST .../pricing routes, then
  // flattened to `price: {...}` — matching the shape GET /admin/curriculum
  // (and the public catalog reads) return for existing content.
  private async withInlinePrice<T extends { id: string; name: string }>(
    entity: T,
    price: CreateInlinePriceDto | undefined,
    prices: CreateInlinePriceDto[] | undefined,
    createProduct: (title: string) => Promise<Parameters<typeof toFlatPrice>[0]>,
  ): Promise<T | (T & { price?: ReturnType<typeof toFlatPrice>; prices?: ReturnType<typeof toFlatPrice>[] })> {
    const selected = prices && prices.length > 0 ? prices : (price ? [price] : undefined);
    if (!selected || selected.length === 0) return entity;
    const product = await createProduct(entity.name);
    const flat = toMultiFlatPrice(product);
    return flat ? { ...entity, ...(flat.price ? { price: flat.price } : {}), prices: flat.prices } : entity;
  }
}
