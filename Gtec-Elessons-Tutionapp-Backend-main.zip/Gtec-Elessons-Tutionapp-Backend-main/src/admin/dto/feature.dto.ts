import {
  IsBoolean, IsDateString, IsEmail, IsEnum, IsInt, IsNotEmpty, IsObject, IsOptional, IsString, Max, Min,
} from 'class-validator';

// A real TS enum, not an array literal — class-validator's IsEnum derives its
// "allowed values" error message from Object.entries() with numeric-key
// filtering (for numeric-enum reverse mappings). Passed a plain array, every
// key is a numeric index and gets filtered out, so the message comes back
// empty even though the values themselves still validate correctly.
export enum InviteRole {
  TEACHER = 'TEACHER',
  ADMIN = 'ADMIN',
}

export class CreateTeamInviteDto {
  @IsEmail() email: string;
  @IsOptional() @IsEnum(InviteRole)
  role?: InviteRole;
  @IsOptional() @IsString() teamName?: string;
}

export class AcceptTeamInviteDto {
  @IsString() @IsNotEmpty() token: string;
  // Accepted but ignored server-side — the caller's identity comes from their
  // JWT, not this field. Kept optional so older clients that still send it don't 400.
  @IsOptional() @IsString() userId?: string;
}

export class CreateAssignmentDto {
  @IsString() @IsNotEmpty() title: string;
  @IsOptional() @IsString() description?: string;
  @IsString() @IsNotEmpty() teacherId: string;
  @IsOptional() @IsString() subjectId?: string;
  @IsOptional() @IsDateString() dueDate?: string;
  @IsOptional() @IsInt() totalMarks?: number;
  @IsOptional() @IsBoolean() isPublished?: boolean;
}

export class UpdateAssignmentDto {
  @IsOptional() @IsString() title?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() teacherId?: string;
  @IsOptional() @IsString() subjectId?: string;
  @IsOptional() @IsDateString() dueDate?: string;
  @IsOptional() @IsInt() totalMarks?: number;
  @IsOptional() @IsBoolean() isPublished?: boolean;
}

export class SubmitAssignmentDto {
  @IsOptional() @IsString() assignmentId?: string;
  @IsOptional() @IsString() userId?: string;
  @IsOptional() @IsObject() answers?: Record<string, unknown>;
}

export class GradeSubmissionDto {
  @IsOptional() @IsInt() @Min(0) score?: number;
  @IsOptional() @IsString() feedback?: string;
}

export class CreateReviewDto {
  @IsOptional() @IsString() userId?: string;
  @IsOptional() @IsString() productId?: string;
  @IsOptional() @IsString() subjectId?: string;
  @IsInt() @Min(1) @Max(5) rating: number;
  @IsOptional() @IsString() comment?: string;
}

export class ApproveReviewDto {
  @IsBoolean() isApproved: boolean;
}

export class BroadcastDto {
  @IsString() @IsNotEmpty() title: string;
  @IsString() @IsNotEmpty() body: string;
  @IsOptional() @IsString() gradeId?: string;
}
