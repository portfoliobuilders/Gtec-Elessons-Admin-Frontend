import { IsEnum } from 'class-validator';
import { UserStatus } from '@prisma/client';

export class SetStudentStatusDto {
  @IsEnum(UserStatus)
  status: UserStatus;
}

// Deliberately NOT the full Prisma Role enum — SUPER_ADMIN must never be
// settable through this endpoint. Promotion to SUPER_ADMIN is a one-time
// manual DB operation only (see the role-hierarchy work this DTO backs).
export enum SettableUserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER',
  ADMIN = 'ADMIN',
}

export class SetStudentRoleDto {
  @IsEnum(SettableUserRole)
  role: SettableUserRole;
}
