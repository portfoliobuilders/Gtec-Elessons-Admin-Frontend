import { IsString } from 'class-validator';

export class GrantEnrollmentDto {
  @IsString()
  studentId: string;

  @IsString()
  subjectId: string;
}
