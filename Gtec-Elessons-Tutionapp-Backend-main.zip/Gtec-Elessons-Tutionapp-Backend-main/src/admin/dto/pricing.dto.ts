import { IsArray, IsEnum, IsInt, IsNumber, IsOptional, IsString, IsNotEmpty, Min, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ProductFormat } from '@prisma/client';

// Phase 5B: pricing input is a plain business-currency amount — e.g.
// `amount: 12000` for ₹12,000, `amount: 800` for AED 800 — never a
// payment-gateway minor unit. maxDecimalPlaces: 3 covers the 3-decimal Gulf
// currencies (KWD/BHD/OMR) without being overly permissive for the rest.
//
// Backward compatibility: the deprecated amountCents/compareAtCents fields
// are still accepted temporarily for callers that haven't migrated (see
// src/common/money/resolve-price-input.ts). Supplying both `amount` and
// `amountCents` (or both `compareAt` and `compareAtCents`) for the same
// price is rejected with 400 — see AdminPricingService.
export class CreateProductPriceDto {
  @IsString() @IsNotEmpty() region: string;
  @IsString() @IsNotEmpty() currency: string;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) amount?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) compareAt?: number;
  /** @deprecated use `amount` — see resolve-price-input.ts */
  @IsOptional() @IsInt() amountCents?: number;
  /** @deprecated use `compareAt` — see resolve-price-input.ts */
  @IsOptional() @IsInt() compareAtCents?: number;
}

export class UpdateProductPriceDto {
  @IsOptional() @IsString() @IsNotEmpty() region?: string;
  @IsOptional() @IsString() @IsNotEmpty() currency?: string;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) amount?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) compareAt?: number;
  /** @deprecated use `amount` */
  @IsOptional() @IsInt() amountCents?: number;
  /** @deprecated use `compareAt` */
  @IsOptional() @IsInt() compareAtCents?: number;
}

// Backward-compatible shortcut for the primary/base price on a product.
export class UpdatePriceDto {
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) amount?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) compareAt?: number;
  /** @deprecated use `amount` */
  @IsOptional() @IsInt() amountCents?: number;
  /** @deprecated use `compareAt` */
  @IsOptional() @IsInt() compareAtCents?: number;
}

// Creates an ADDITIONAL Product variant for a curriculum entity that already
// has one (POST .../grades|subjects|chapters/:id/products) — e.g. a
// LIVE_AND_RECORDED product alongside an existing RECORDED one for the same
// grade. Unlike the grade/subject/chapter CREATE routes' inline `price`
// (which titles the product after the entity itself, since there's only
// ever one), `title` is required here — with more than one active product
// per scope, callers must be explicit about which is which.
export class CreateProductVariantDto {
  @IsString() @IsNotEmpty() title: string;
  // Omitted → RECORDED, matching Product.format's schema default.
  @IsOptional() @IsEnum(ProductFormat) format?: ProductFormat;
  @IsOptional() @IsInt() @Min(1) accessDays?: number;
  @IsOptional() @ValidateNested() @Type(() => CreateProductPriceDto) price?: CreateProductPriceDto;
  @IsOptional() @IsArray() @ValidateNested({ each: true }) @Type(() => CreateProductPriceDto) prices?: CreateProductPriceDto[];
}
