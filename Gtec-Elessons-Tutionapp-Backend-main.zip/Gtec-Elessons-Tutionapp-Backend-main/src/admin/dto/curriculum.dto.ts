import {
  ArrayNotEmpty, IsArray, IsBoolean, IsEnum, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Min, ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ProductFormat, ResourceType } from '@prisma/client';

// Optional inline pricing block accepted by the grade/subject/chapter CREATE
// routes — the only way to set a price now that the standalone POST
// .../pricing routes are gone. Deliberately has no `title` — the created
// product is titled after the entity itself.
//
// Phase 5B: `amount` is a plain business-currency amount (e.g. 12000 for
// ₹12,000, 65 for KWD 65), not a payment-gateway minor unit — see
// src/common/money. The deprecated `amountCents`/`compareAtCents` fields are
// still accepted temporarily for backward compatibility; supplying both the
// new and old field for the same value is rejected with 400 — see
// AdminPricingService / resolve-price-input.ts.
export class CreateInlinePriceDto {
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) amount?: number;
  /** @deprecated use `amount` */
  @IsOptional() @IsInt() amountCents?: number;
  @IsOptional() @IsNumber({ maxDecimalPlaces: 3 }) @Min(0) compareAt?: number;
  /** @deprecated use `compareAt` */
  @IsOptional() @IsInt() compareAtCents?: number;
  @IsString() @IsNotEmpty() region: string;
  @IsString() @IsNotEmpty() currency: string;
  @IsOptional() @IsEnum(ProductFormat) format?: ProductFormat;
  @IsOptional() @IsInt() accessDays?: number;
}

export class CreateGradeDto {
  @IsString() @IsNotEmpty() name: string;
  @IsOptional() @IsString() board?: string;
  @IsOptional() @IsString() syllabus?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() trailerYoutubeId?: string;
  @IsOptional() @IsString() thumbnailUrl?: string;
  @IsOptional() @IsInt() order?: number;
  // Product-level fields for the inline product this create route may build
  // (see AdminController.withInlinePrice). Previously accepted only nested
  // inside `price`/`prices` where they were silently never read — format
  // always defaulted to RECORDED regardless of what was sent. Top-level here
  // so they actually reach AdminPricingService.createProduct(). Omitted →
  // format defaults to RECORDED, accessDays defaults to 365, unchanged.
  @IsOptional() @IsEnum(ProductFormat) format?: ProductFormat;
  @IsOptional() @IsInt() accessDays?: number;
  @IsOptional() @ValidateNested() @Type(() => CreateInlinePriceDto) price?: CreateInlinePriceDto;
  @IsOptional() @IsArray() @ValidateNested({ each: true }) @Type(() => CreateInlinePriceDto) prices?: CreateInlinePriceDto[];
}

export class UpdateGradeDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() board?: string;
  @IsOptional() @IsString() syllabus?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() trailerYoutubeId?: string;
  @IsOptional() @IsString() thumbnailUrl?: string;
  @IsOptional() @IsInt() order?: number;
  @IsOptional() @IsBoolean() isActive?: boolean;
}

// teacherId and teacherName are intentionally absent — they are auto-derived
// server-side from the requester's identity (TEACHER → own id/name, ADMIN → null).
// Use PATCH /admin/subjects/:id to assign/reassign a teacher later.
export class CreateSubjectDto {
  @IsString() @IsNotEmpty() name: string;
  @IsOptional() @IsString() code?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() trailerYoutubeId?: string;
  @IsOptional() @IsString() thumbnailUrl?: string;
  @IsOptional() @IsInt() order?: number;
  @IsOptional() @IsString() iconUrl?: string;
  // See CreateGradeDto — same fix, same reasoning.
  @IsOptional() @IsEnum(ProductFormat) format?: ProductFormat;
  @IsOptional() @IsInt() accessDays?: number;
  @IsOptional() @ValidateNested() @Type(() => CreateInlinePriceDto) price?: CreateInlinePriceDto;
  @IsOptional() @IsArray() @ValidateNested({ each: true }) @Type(() => CreateInlinePriceDto) prices?: CreateInlinePriceDto[];
}

export class UpdateSubjectDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() code?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() trailerYoutubeId?: string;
  @IsOptional() @IsString() thumbnailUrl?: string;
  @IsOptional() @IsInt() order?: number;
  @IsOptional() @IsString() iconUrl?: string;
}

export class CreateChapterDto {
  @IsString() @IsNotEmpty() name: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() trailerYoutubeId?: string;
  @IsOptional() @IsString() thumbnailUrl?: string;
  @IsOptional() @IsInt() order?: number;
  // See CreateGradeDto — same fix, same reasoning.
  @IsOptional() @IsEnum(ProductFormat) format?: ProductFormat;
  @IsOptional() @IsInt() accessDays?: number;
  @IsOptional() @ValidateNested() @Type(() => CreateInlinePriceDto) price?: CreateInlinePriceDto;
  @IsOptional() @IsArray() @ValidateNested({ each: true }) @Type(() => CreateInlinePriceDto) prices?: CreateInlinePriceDto[];
}

export class UpdateChapterDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() trailerYoutubeId?: string;
  @IsOptional() @IsString() thumbnailUrl?: string;
  @IsOptional() @IsInt() order?: number;
}

// youtubeId accepts either a bare 11-character video id or a full YouTube
// URL (youtu.be/…, youtube.com/watch?v=…, /embed/…, /shorts/…, /live/…) —
// resolved server-side in AdminCurriculumService.buildTrailerData() via
// src/common/utils/youtube.util.ts.
export class SetTrailerDto {
  @IsString() @IsNotEmpty() youtubeId: string;
  @IsOptional() @IsString() thumbnailUrl?: string;
}

// chapterId is intentionally absent from body — it is supplied in the URL path
// (POST /admin/chapters/:chapterId/lessons).
export class CreateLessonDto {
  @IsString() @IsNotEmpty() title: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsInt() order?: number;
  @IsOptional() @IsBoolean() isFreePreview?: boolean;
  @IsOptional() @IsBoolean() isPublished?: boolean;
  @IsOptional() @IsArray() @IsString({ each: true }) batchIds?: string[];
}

export class UpdateLessonDto {
  @IsOptional() @IsString() title?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsInt() order?: number;
  @IsOptional() @IsBoolean() isFreePreview?: boolean;
  @IsOptional() @IsBoolean() isPublished?: boolean;
  @IsOptional() @IsInt() durationSeconds?: number;
  @IsOptional() @IsArray() @IsString({ each: true }) batchIds?: string[];
}

export class CreateResourceDto {
  // A real enum, not an array literal — same empty-allowed-values-message bug
  // as the team-invites DTO fixed earlier tonight (class-validator's IsEnum
  // filters numeric-looking keys out of the message, and every key of a plain
  // array is a numeric index, so the message comes back empty).
  @IsOptional() @IsEnum(ResourceType)
  type?: ResourceType;
  @IsString() @IsNotEmpty() title: string;
  @IsString() @IsNotEmpty() fileKey: string;
  @IsOptional() @IsInt() pageCount?: number;
  @IsOptional() @IsInt() sizeBytes?: number;
  @IsOptional() @IsBoolean() isDownloadable?: boolean;
}

class ReorderItemDto {
  @IsString() @IsNotEmpty() id: string;
  @IsInt() order: number;
}

// No backing Prisma enum — these are pure application-level discriminators
// branched on in AdminCurriculumService.reorder()/setPublished(), not tied
// to any model's field type.
export enum ReorderEntity {
  grade = 'grade',
  subject = 'subject',
  chapter = 'chapter',
  lesson = 'lesson',
}

export enum PublishEntity {
  lesson = 'lesson',
  chapter = 'chapter',
}

export class ReorderDto {
  @IsEnum(ReorderEntity)
  entity: ReorderEntity;
  @IsArray() @ArrayNotEmpty() @ValidateNested({ each: true }) @Type(() => ReorderItemDto)
  items: ReorderItemDto[];
}

export class PublishDto {
  @IsEnum(PublishEntity)
  entity: PublishEntity;
  @IsString() @IsNotEmpty() id: string;
  @IsBoolean() isPublished: boolean;
}
