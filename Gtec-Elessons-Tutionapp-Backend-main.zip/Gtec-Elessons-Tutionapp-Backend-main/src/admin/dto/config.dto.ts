import {
  IsBoolean, IsNotEmpty, IsNumber, IsOptional, IsString,
} from 'class-validator';

export class UpdateSettingDto {
  @IsString() @IsNotEmpty() value: string;
}

export class CreateCountryDto {
  @IsString() @IsNotEmpty() code: string;
  @IsString() @IsNotEmpty() name: string;
  @IsString() @IsNotEmpty() currency: string;
  @IsString() @IsNotEmpty() symbol: string;
  @IsOptional() @IsBoolean() isActive?: boolean;
}

export class UpdateCountryDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() currency?: string;
  @IsOptional() @IsString() symbol?: string;
  @IsOptional() @IsBoolean() isActive?: boolean;
}

export class UpdateExchangeRateDto {
  @IsNumber() rateToInr: number;
}

export class CreateNotificationTemplateDto {
  @IsString() @IsNotEmpty() type: string;
  @IsString() @IsNotEmpty() title: string;
  @IsString() @IsNotEmpty() body: string;
}

export class UpdateNotificationTemplateDto {
  @IsOptional() @IsString() title?: string;
  @IsOptional() @IsString() body?: string;
}
