import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AdminAnalyticsService {
  constructor(private prisma: PrismaService) {}

  async overview() {
    const [students, activeEnrollments, paidOrders, progressRows] = await Promise.all([
      this.prisma.user.count({ where: { role: 'STUDENT' } }),
      this.prisma.enrollment.count({ where: { status: 'ACTIVE' } }),
      this.prisma.order.findMany({
        where: { status: 'PAID' },
        select: { totalCents: true, currency: true, region: true, createdAt: true },
      }),
      this.prisma.lessonProgress.findMany({ select: { completed: true } }),
    ]);

    const revenueByCurrency: Record<string, number> = {};
    // Region -> currency -> cents. A region is NOT 1:1 with a currency (e.g.
    // pricing.service.ts buckets every non-INR order without a saved profile
    // region into the single 'INTL' region), so summing totalCents per region
    // without keying by currency too would silently add USD cents to AED cents.
    const revenueByRegion: Record<string, Record<string, number>> = {};
    for (const o of paidOrders) {
      revenueByCurrency[o.currency] = (revenueByCurrency[o.currency] ?? 0) + o.totalCents;
      revenueByRegion[o.region] ??= {};
      revenueByRegion[o.region][o.currency] = (revenueByRegion[o.region][o.currency] ?? 0) + o.totalCents;
    }

    const started = progressRows.length;
    const finished = progressRows.filter((p) => p.completed).length;
    const completionRate = started > 0 ? Math.round((finished / started) * 100) : 0;

    const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const recentEnr = await this.prisma.enrollment.findMany({
      where: { startsAt: { gte: since } },
      select: { startsAt: true },
    });
    const byDay: Record<string, number> = {};
    for (const e of recentEnr) {
      const day = e.startsAt.toISOString().slice(0, 10);
      byDay[day] = (byDay[day] ?? 0) + 1;
    }
    const enrollmentsOverTime = Object.entries(byDay)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, count]) => ({ date, count }));

    return { students, activeEnrollments, paidOrders: paidOrders.length, revenueByCurrency, revenueByRegion, completionRate, enrollmentsOverTime };
  }

  async topCourses(limit = 5) {
    const grouped = await this.prisma.enrollment.groupBy({
      by: ['subjectId'],
      where: { status: 'ACTIVE', subjectId: { not: null } },
      _count: { subjectId: true },
      orderBy: { _count: { subjectId: 'desc' } },
      take: limit,
    });
    const results: any[] = [];
    for (const g of grouped) {
      if (!g.subjectId) continue;
      const subject = await this.prisma.subject.findUnique({
        where: { id: g.subjectId },
        select: { name: true, grade: { select: { name: true } } },
      });
      results.push({ subjectId: g.subjectId, subject: subject?.name, grade: subject?.grade?.name, enrollments: g._count.subjectId });
    }
    return results;
  }

  async recentOrders(limit = 10) {
    return this.prisma.order.findMany({
      where: { status: 'PAID' },
      orderBy: { createdAt: 'desc' },
      take: limit,
      select: {
        orderNumber: true, totalCents: true, currency: true, createdAt: true,
        billingName: true, billingPhone: true, billingAddress: true,
        billingCity: true, billingState: true, billingPincode: true,
        user: { select: { name: true, email: true } },
      },
    });
  }
}
