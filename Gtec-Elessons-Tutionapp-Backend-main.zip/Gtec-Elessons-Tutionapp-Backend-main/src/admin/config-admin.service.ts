import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
  CreateCountryDto, UpdateCountryDto, CreateNotificationTemplateDto, UpdateNotificationTemplateDto,
} from './dto/config.dto';

@Injectable()
export class AdminConfigService {
  constructor(private prisma: PrismaService) {}

  // ---- Settings ----
  listSettings() {
    return this.prisma.setting.findMany({ orderBy: { key: 'asc' } });
  }

  updateSetting(key: string, value: string) {
    return this.prisma.setting.upsert({
      where: { key },
      update: { value },
      create: { key, value },
    });
  }

  // ---- Countries ---- (admin sees inactive rows too; GET /regions filters them out)
  listCountries() {
    return this.prisma.country.findMany({ orderBy: { name: 'asc' } });
  }

  createCountry(d: CreateCountryDto) {
    return this.prisma.country.create({
      data: { code: d.code.toUpperCase(), name: d.name, currency: d.currency.toUpperCase(), symbol: d.symbol, isActive: d.isActive ?? true },
    });
  }

  updateCountry(code: string, d: UpdateCountryDto) {
    return this.prisma.country.update({ where: { code: code.toUpperCase() }, data: d });
  }

  deleteCountry(code: string) {
    return this.prisma.country.delete({ where: { code: code.toUpperCase() } });
  }

  // ---- Exchange rates ----
  listExchangeRates() {
    return this.prisma.exchangeRate.findMany({ orderBy: { currency: 'asc' } });
  }

  updateExchangeRate(currency: string, rateToInr: number) {
    const code = currency.toUpperCase();
    return this.prisma.exchangeRate.upsert({
      where: { currency: code },
      update: { rateToInr },
      create: { currency: code, rateToInr },
    });
  }

  // ---- Notification templates ----
  listNotificationTemplates() {
    return this.prisma.notificationTemplate.findMany({ orderBy: { type: 'asc' } });
  }

  createNotificationTemplate(d: CreateNotificationTemplateDto) {
    return this.prisma.notificationTemplate.create({ data: d });
  }

  updateNotificationTemplate(type: string, d: UpdateNotificationTemplateDto) {
    return this.prisma.notificationTemplate.update({ where: { type }, data: d });
  }

  deleteNotificationTemplate(type: string) {
    return this.prisma.notificationTemplate.delete({ where: { type } });
  }
}
