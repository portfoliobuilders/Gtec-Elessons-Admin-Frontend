import { Module } from '@nestjs/common';
import { AdminController } from './admin.controller';
import { AdminAnalyticsService } from './analytics.service';
import { AdminCurriculumService } from './curriculum.service';
import { AdminStudentsService } from './students.service';
import { AdminPricingService } from './pricing-admin.service';
import { AdminOrdersService } from './orders-admin.service';
import { AdminEnrollmentsService } from './enrollments-admin.service';
import { PaymentsModule } from '../payments/payments.module';
import { AdminFeatureService } from './feature.service';
import { AdminConfigService } from './config-admin.service';

@Module({
  imports: [PaymentsModule],
  controllers: [AdminController],
  providers: [AdminAnalyticsService, AdminCurriculumService, AdminStudentsService, AdminPricingService, AdminOrdersService, AdminEnrollmentsService, AdminFeatureService, AdminConfigService],
})
export class AdminModule { }
