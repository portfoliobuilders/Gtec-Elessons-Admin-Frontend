import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { resolveAmount, resolveCompareAt } from '../common/money/resolve-price-input';

interface CreateProductPriceInput {
  region: string;
  currency: string;
  // Phase 5B: canonical business-currency amount (e.g. 12000 for ₹12,000).
  amount?: number;
  /** @deprecated use `amount` — see resolve-price-input.ts */
  amountCents?: number;
  compareAt?: number;
  /** @deprecated use `compareAt` */
  compareAtCents?: number;
  format?: 'RECORDED' | 'LIVE_AND_RECORDED';
  accessDays?: number;
}

interface CreateProductInput {
  format?: 'RECORDED' | 'LIVE_AND_RECORDED';
  title: string;
  accessDays?: number;
  prices?: CreateProductPriceInput[];
  price?: CreateProductPriceInput;
}

// A price input fully resolved to plain business-currency decimals — ready
// to persist. Never a minor unit.
interface ResolvedPrice {
  region: string;
  currency: string;
  amount: number;
  compareAt?: number;
  format?: 'RECORDED' | 'LIVE_AND_RECORDED';
  accessDays?: number;
}

interface ProductPriceRow {
  id: string;
  productId: string;
  region: string;
  currency: string;
  amount: Prisma.Decimal;
  compareAt: Prisma.Decimal | null;
  stripePriceId: string | null;
}

// API shape returned by this service: `amount`/`compareAt` are canonical.
// `amountCents`/`compareAtCents` are included alongside them, temporarily,
// for backward compatibility with existing admin-panel/API clients that
// haven't migrated off the old minor-unit fields — see Phase 5B report §10-11.
export interface PriceDto {
  id: string;
  productId: string;
  region: string;
  currency: string;
  amount: number;
  compareAt?: number;
  /** @deprecated use `amount` */
  amountCents: number;
  /** @deprecated use `compareAt` */
  compareAtCents?: number;
  stripePriceId: string | null;
}

@Injectable()
export class AdminPricingService {
  constructor(private prisma: PrismaService) { }

  async list() {
    const products = await this.prisma.product.findMany({
      where: { isActive: true },
      orderBy: [{ type: 'asc' }, { title: 'asc' }],
      include: { prices: true },
    });
    return products.map((p) => ({ ...p, prices: p.prices.map((pr) => this.toPriceDto(pr)) }));
  }

  async updatePrice(
    productId: string,
    d: { amount?: number; amountCents?: number; compareAt?: number; compareAtCents?: number },
  ) {
    const existing = await this.prisma.productPrice.findFirst({ where: { productId } });
    if (!existing) {
      throw new NotFoundException('This product has no price to update — price can only be set when its grade/subject/chapter is created.');
    }
    const amount = resolveAmount(d);
    if (amount === undefined) throw new BadRequestException("'amount' is required");
    const compareAt = resolveCompareAt(d);

    const updated = await this.prisma.productPrice.update({
      where: { id: existing.id },
      data: {
        amount,
        ...(compareAt !== undefined ? { compareAt } : {}),
      },
    });
    return this.toPriceDto(updated);
  }

  createGradeProduct(gradeId: string, d: CreateProductInput) {
    return this.createProduct({ ...d, type: 'FULL_CLASS', gradeId });
  }

  createSubjectProduct(subjectId: string, d: CreateProductInput) {
    return this.createProduct({ ...d, type: 'SUBJECT', subjectId });
  }

  createChapterProduct(chapterId: string, d: CreateProductInput) {
    return this.createProduct({ ...d, type: 'MODULE', chapterId });
  }

  async createRegionalPrice(productId: string, d: CreateProductPriceInput) {
    const product = await this.prisma.product.findUnique({ where: { id: productId } });
    if (!product) throw new NotFoundException('Product not found');

    const normalized = this.normalizePriceInput(d);
    await this.validateUniquePrice(productId, normalized);

    const created = await this.prisma.productPrice.create({
      data: {
        productId,
        region: normalized.region,
        currency: normalized.currency,
        amount: normalized.amount,
        compareAt: normalized.compareAt ?? null,
      },
    });
    return this.toPriceDto(created);
  }

  async updateRegionalPrice(
    productId: string,
    priceId: string,
    d: {
      region?: string; currency?: string;
      amount?: number; amountCents?: number;
      compareAt?: number; compareAtCents?: number;
    },
  ) {
    const price = await this.prisma.productPrice.findFirst({ where: { id: priceId, productId } });
    if (!price) throw new NotFoundException('Product price not found for this product');

    const resolvedAmount = resolveAmount(d);
    const resolvedCompareAt = resolveCompareAt(d);

    const normalized = {
      region: d.region ? this.normalizeRegion(d.region) : price.region,
      currency: d.currency ? this.normalizeCurrency(d.currency) : price.currency,
      amount: resolvedAmount ?? Number(price.amount),
      compareAt: resolvedCompareAt ?? (price.compareAt != null ? Number(price.compareAt) : undefined),
    };

    const duplicate = await this.prisma.productPrice.findFirst({
      where: {
        productId,
        region: normalized.region,
        currency: normalized.currency,
        NOT: { id: priceId },
      },
    });
    if (duplicate) {
      throw new BadRequestException(`Duplicate regional price for ${normalized.region}/${normalized.currency}`);
    }

    const updated = await this.prisma.productPrice.update({
      where: { id: priceId },
      data: {
        region: normalized.region,
        currency: normalized.currency,
        amount: normalized.amount,
        compareAt: normalized.compareAt ?? null,
      },
    });
    return this.toPriceDto(updated);
  }

  async deleteRegionalPrice(productId: string, priceId: string) {
    const price = await this.prisma.productPrice.findFirst({ where: { id: priceId, productId } });
    if (!price) throw new NotFoundException('Product price not found for this product');

    const count = await this.prisma.productPrice.count({ where: { productId } });
    if (count <= 1) {
      throw new BadRequestException('Cannot delete the last remaining price for a product');
    }

    const deleted = await this.prisma.productPrice.delete({ where: { id: priceId } });
    return this.toPriceDto(deleted);
  }

  deleteProduct(id: string) {
    return this.prisma.product.update({ where: { id }, data: { isActive: false } });
  }

  private async createProduct(d: CreateProductInput & {
    type: 'FULL_CLASS' | 'SUBJECT' | 'MODULE';
    gradeId?: string;
    subjectId?: string;
    chapterId?: string;
  }) {
    await this.validateProductScope(d);
    const format = d.format ?? 'RECORDED';
    await this.assertNoActiveDuplicateVariant({ type: d.type, format, gradeId: d.gradeId, subjectId: d.subjectId, chapterId: d.chapterId });

    const inputPrices = this.resolvePriceList(d);
    if (inputPrices.length > 0) {
      this.validateDuplicateRegionalPrices(inputPrices);
    }

    return this.prisma.$transaction(async (tx) => {
      const product = await tx.product.create({
        data: {
          type: d.type,
          format,
          title: d.title,
          gradeId: d.gradeId,
          subjectId: d.subjectId,
          chapterId: d.chapterId,
          accessDays: d.accessDays ?? 365,
        },
      });

      if (inputPrices.length > 0) {
        await tx.productPrice.createMany({
          data: inputPrices.map((p) => ({
            productId: product.id,
            region: p.region,
            currency: p.currency,
            amount: p.amount,
            compareAt: p.compareAt ?? null,
          })),
        });
      }

      return tx.product.findUnique({ where: { id: product.id }, include: { prices: true } });
    });
  }

  private resolvePriceList(d: CreateProductInput): ResolvedPrice[] {
    if (d.prices && d.prices.length > 0) {
      return d.prices.map((p) => this.normalizePriceInput(p));
    }
    if (d.price) {
      return [this.normalizePriceInput(d.price)];
    }
    return [];
  }

  private normalizePriceInput(p: CreateProductPriceInput): ResolvedPrice {
    const amount = resolveAmount(p);
    if (amount === undefined) {
      throw new BadRequestException("'amount' is required for each price");
    }
    return {
      region: this.normalizeRegion(p.region),
      currency: this.normalizeCurrency(p.currency),
      amount,
      compareAt: resolveCompareAt(p),
      format: p.format,
      accessDays: p.accessDays,
    };
  }

  private normalizeRegion(value: string): string {
    return value.trim().toUpperCase();
  }

  private normalizeCurrency(value: string): string {
    return value.trim().toUpperCase();
  }

  private validateDuplicateRegionalPrices(prices: ResolvedPrice[]) {
    const seen = new Set<string>();
    for (const price of prices) {
      const key = `${price.region}/${price.currency}`;
      if (seen.has(key)) {
        throw new BadRequestException(`Duplicate regional price for ${price.region}/${price.currency}`);
      }
      seen.add(key);
    }
  }

  private async validateUniquePrice(productId: string, price: ResolvedPrice) {
    const existing = await this.prisma.productPrice.findFirst({
      where: { productId, region: price.region, currency: price.currency },
    });
    if (existing) {
      throw new BadRequestException(`Duplicate regional price for ${price.region}/${price.currency}`);
    }
  }

  // Blocks two ACTIVE products with the same (type, format) for the same
  // scope — e.g. two active FULL_CLASS+RECORDED products for one grade.
  // Deliberately keyed on type as well as format: a grade legitimately
  // carries several coexisting ACTIVE products of *different* types today
  // (e.g. "Full Bundle" FULL_CLASS + "Mentorship" MENTORSHIP, both RECORDED
  // format) — this only rejects a genuine same-type-same-format duplicate,
  // e.g. trying to add a second RECORDED FULL_CLASS product to a grade that
  // already has one. A service-level check rather than a DB unique
  // constraint because Product uses isActive=false for soft deletion — a
  // unique index would incorrectly block re-adding a variant after its
  // predecessor was deactivated.
  private async assertNoActiveDuplicateVariant(d: {
    type: 'FULL_CLASS' | 'MENTORSHIP' | 'SUBJECT' | 'MODULE';
    format: 'RECORDED' | 'LIVE_AND_RECORDED';
    gradeId?: string;
    subjectId?: string;
    chapterId?: string;
  }) {
    const existing = await this.prisma.product.findFirst({
      where: {
        isActive: true,
        type: d.type,
        format: d.format,
        gradeId: d.gradeId ?? null,
        subjectId: d.subjectId ?? null,
        chapterId: d.chapterId ?? null,
      },
      select: { id: true, title: true },
    });
    if (existing) {
      const scopeLabel = d.gradeId ? 'this grade' : d.subjectId ? 'this subject' : 'this chapter';
      throw new BadRequestException(
        `An active ${d.format} product already exists for ${scopeLabel} ("${existing.title}"). `
        + 'Deactivate it first, or use a different format.',
      );
    }
  }

  private async validateProductScope(d: {
    type: 'FULL_CLASS' | 'MENTORSHIP' | 'SUBJECT' | 'MODULE';
    gradeId?: string;
    subjectId?: string;
    chapterId?: string;
  }) {
    if ((d.type === 'FULL_CLASS' || d.type === 'MENTORSHIP') && !d.gradeId) {
      throw new BadRequestException('gradeId is required for this product type');
    }

    if (d.type === 'SUBJECT' && !d.subjectId) {
      throw new BadRequestException('subjectId is required for SUBJECT products');
    }

    if (d.type === 'MODULE' && !d.chapterId) {
      throw new BadRequestException('chapterId is required for MODULE products');
    }

    if (d.gradeId) {
      const grade = await this.prisma.grade.findUnique({ where: { id: d.gradeId }, select: { id: true } });
      if (!grade) throw new BadRequestException('gradeId does not match an existing grade');
    }

    if (d.subjectId) {
      const subject = await this.prisma.subject.findUnique({ where: { id: d.subjectId }, select: { id: true } });
      if (!subject) throw new BadRequestException('subjectId does not match an existing subject');
    }

    if (d.chapterId) {
      const chapter = await this.prisma.chapter.findUnique({ where: { id: d.chapterId }, select: { id: true } });
      if (!chapter) throw new BadRequestException('chapterId does not match an existing chapter');
    }
  }

  private toPriceDto(price: ProductPriceRow): PriceDto {
    const amount = Number(price.amount);
    const compareAt = price.compareAt != null ? Number(price.compareAt) : undefined;
    return {
      id: price.id,
      productId: price.productId,
      region: price.region,
      currency: price.currency,
      amount,
      ...(compareAt !== undefined ? { compareAt } : {}),
      amountCents: Math.round(amount * 100),
      ...(compareAt !== undefined ? { compareAtCents: Math.round(compareAt * 100) } : {}),
      stripePriceId: price.stripePriceId,
    };
  }
}
