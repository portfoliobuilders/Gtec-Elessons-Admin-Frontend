import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { parseYouTubeId, resolveYoutubeId } from '../common/utils/youtube.util';

interface Requester {
  id: string;
  role: string;
}

@Injectable()
export class VideoService {
  private readonly logger = new Logger(VideoService.name);

  constructor(private prisma: PrismaService) { }

  async setLessonVideo(lessonId: string, youtubeIdOrUrl: string, requester: Requester) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      include: { chapter: { select: { subject: { select: { teacherId: true } } } } },
    });
    if (!lesson) throw new NotFoundException('Lesson not found');

    // TEACHER may only set video on lessons under a subject they teach;
    // ADMIN/SUPER_ADMIN are unrestricted. Mirrors assertChapterOwnership
    // in AdminCurriculumService.
    if (requester.role === 'TEACHER' && lesson.chapter.subject.teacherId !== requester.id) {
      throw new ForbiddenException('You can only manage content for subjects you teach');
    }

    // Accepts either a bare 11-char id or a full YouTube URL — throws a 400
    // explaining the accepted formats if neither matches.
    const youtubeId = resolveYoutubeId(youtubeIdOrUrl);

    const updated = await this.prisma.lesson.update({
      where: { id: lessonId },
      data: {
        youtubeId,
        // We store only the video id; any URL can be derived by the client as needed.
        youtubeUrl: null,
        thumbnailUrl: `https://img.youtube.com/vi/${youtubeId}/hqdefault.jpg`,
        isPublished: true,
      },
    });
    return {
      lessonId: updated.id,
      youtubeId: updated.youtubeId,
      embedUrl: `https://www.youtube.com/embed/${updated.youtubeId}`,
      verified: true,
    };
  }

  async getPlayback(lessonId: string) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      select: { title: true, youtubeId: true, durationSeconds: true, thumbnailUrl: true },
    });
    if (!lesson) throw new NotFoundException('Lesson not found');
    if (!lesson.youtubeId) {
      throw new BadRequestException('No video attached to this lesson yet');
    }
    return {
      title: lesson.title,
      youtubeId: lesson.youtubeId,
      embedUrl: `https://www.youtube.com/embed/${lesson.youtubeId}?rel=0&modestbranding=1`,
      thumbnailUrl: lesson.thumbnailUrl,
      durationSeconds: lesson.durationSeconds,
    };
  }

  async getLessonVideo(studentId: string, lessonId: string) {
    let resolvedLessonId: string | null = null;
    let success = false;
    let reason: string | undefined;

    try {
      const lesson = await this.prisma.lesson.findUnique({
        where: { id: lessonId },
        select: {
          id: true,
          isPublished: true,
          youtubeId: true,
          youtubeUrl: true,
          chapterId: true,
          chapter: {
            select: {
              subjectId: true,
              subject: { select: { gradeId: true } },
            },
          },
        },
      });

      if (!lesson || !lesson.isPublished) {
        reason = 'LESSON_NOT_FOUND';
        throw new NotFoundException('Lesson not found');
      }

      resolvedLessonId = lesson.id;
      const youtubeId = lesson.youtubeId ?? (lesson.youtubeUrl ? parseYouTubeId(lesson.youtubeUrl) : null);
      if (!youtubeId) {
        reason = 'VIDEO_NOT_ATTACHED';
        throw new BadRequestException('No video attached to this lesson yet');
      }

      const enrollment = await this.prisma.enrollment.findFirst({
        where: {
          userId: studentId,
          status: 'ACTIVE',
          OR: [
            { scopeType: 'FULL_CLASS', gradeId: lesson.chapter.subject.gradeId },
            { scopeType: 'SUBJECT', subjectId: lesson.chapter.subjectId },
            { scopeType: 'MODULE', chapterId: lesson.chapterId },
          ],
          AND: [{ OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] }],
        },
        select: { id: true },
      });

      if (!enrollment) {
        reason = 'NO_ACTIVE_ENROLLMENT';
        throw new ForbiddenException('You are not enrolled for this lesson');
      }

      success = true;
      return { youtubeId };
    } finally {
      await this.logLessonVideoAccess({
        studentId,
        lessonId: resolvedLessonId,
        requestedLessonId: lessonId,
        success,
        reason: success ? undefined : reason ?? 'REQUEST_FAILED',
      });
    }
  }

  private async logLessonVideoAccess(args: {
    studentId: string;
    lessonId: string | null;
    requestedLessonId: string;
    success: boolean;
    reason?: string;
  }) {
    try {
      await this.prisma.lessonVideoAccessLog.create({
        data: {
          userId: args.studentId,
          lessonId: args.lessonId,
          requestedLessonId: args.requestedLessonId,
          success: args.success,
          reason: args.reason,
        },
      });
    } catch (err) {
      this.logger.warn(`Failed to write lesson video audit log: ${err}`);
    }
  }
}
