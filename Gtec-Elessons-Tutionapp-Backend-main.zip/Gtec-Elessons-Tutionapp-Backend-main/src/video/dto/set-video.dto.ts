import { IsString, IsNotEmpty } from 'class-validator';

// Accepts either a bare 11-character YouTube video id or a full YouTube URL
// (https://youtu.be/ID, https://www.youtube.com/watch?v=ID, .../embed/ID,
// .../shorts/ID, .../live/ID) in the same `youtubeId` field — resolved
// server-side in VideoService via src/common/utils/youtube.util.ts, which is
// also where the "not a valid id/url" 400 is thrown.
export class SetVideoDto {
  @IsString()
  @IsNotEmpty()
  youtubeId: string;
}
