import { Module } from '@nestjs/common';
import { VideoService } from './video.service';
import { VideoController } from './video.controller';
import { LessonVideoRateLimitGuard } from './lesson-video-rate-limit.guard';

@Module({
  controllers: [VideoController],
  providers: [VideoService, LessonVideoRateLimitGuard],
  exports: [VideoService],
})
export class VideoModule {}
