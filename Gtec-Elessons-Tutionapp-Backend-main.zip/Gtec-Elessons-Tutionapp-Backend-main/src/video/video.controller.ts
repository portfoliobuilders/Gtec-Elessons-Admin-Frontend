import { Body, Controller, Get, Header, Param, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { VideoService } from './video.service';
import { SetVideoDto } from './dto/set-video.dto';
import { LessonVideoRateLimitGuard } from './lesson-video-rate-limit.guard';

@Controller()
export class VideoController {
  constructor(private video: VideoService) { }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/lessons/:id/video')
  setVideo(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() dto: SetVideoDto) {
    return this.video.setLessonVideo(id, dto.youtubeId, user);
  }

  @UseGuards(JwtAuthGuard, LessonVideoRateLimitGuard)
  @Header('Cache-Control', 'no-store, private')
  @Header('Pragma', 'no-cache')
  @Get('lessons/:lessonId/playback')
  playback(@CurrentUser() user: AuthUser, @Param('lessonId') lessonId: string) {
    return this.video.getLessonVideo(user.id, lessonId);
  }

  @UseGuards(JwtAuthGuard, LessonVideoRateLimitGuard)
  @Header('Cache-Control', 'no-store, private')
  @Header('Pragma', 'no-cache')
  @Get('lessons/:lessonId/video')
  lessonVideo(@CurrentUser() user: AuthUser, @Param('lessonId') lessonId: string) {
    return this.video.getLessonVideo(user.id, lessonId);
  }
}
