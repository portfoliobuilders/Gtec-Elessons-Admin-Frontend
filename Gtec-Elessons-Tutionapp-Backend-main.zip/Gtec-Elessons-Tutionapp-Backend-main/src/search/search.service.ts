import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class SearchService {
  constructor(private prisma: PrismaService) {}

  async search(q: string, type?: string) {
    const query = (q ?? '').trim();
    if (query.length < 2) {
      return { query, subjects: [], chapters: [], lessons: [], tests: [] };
    }
    const like = { contains: query, mode: 'insensitive' as const };
    const want = (t: string) => !type || type === t;

    const [subjects, chapters, lessons, tests] = await Promise.all([
      want('subjects')
        ? this.prisma.subject.findMany({
            where: { name: like },
            take: 15,
            select: { id: true, name: true, grade: { select: { id: true, name: true } } },
          })
        : [],
      want('chapters')
        ? this.prisma.chapter.findMany({
            where: { name: like },
            take: 15,
            select: { id: true, name: true, subject: { select: { id: true, name: true } } },
          })
        : [],
      want('lessons')
        ? this.prisma.lesson.findMany({
            where: {
              isPublished: true,
              OR: [{ title: like }, { description: like }],
            },
            take: 20,
            select: {
              id: true, title: true, isFreePreview: true,
              chapter: { select: { id: true, name: true, subject: { select: { id: true, name: true } } } },
            },
          })
        : [],
      want('tests')
        ? this.prisma.assessment.findMany({
            where: { isPublished: true, title: like },
            take: 15,
            select: { id: true, title: true, type: true, subject: { select: { id: true, name: true } } },
          })
        : [],
    ]);

    return {
      query,
      counts: {
        subjects: subjects.length,
        chapters: chapters.length,
        lessons: lessons.length,
        tests: tests.length,
      },
      subjects,
      chapters,
      lessons,
      tests,
    };
  }
}
