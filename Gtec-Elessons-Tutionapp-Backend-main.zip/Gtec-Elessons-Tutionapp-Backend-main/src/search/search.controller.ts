import { Controller, Get, Query } from '@nestjs/common';
import { Public } from '../common/decorators/public.decorator';
import { SearchService } from './search.service';

@Controller('search')
export class SearchController {
  constructor(private svc: SearchService) {}

  @Public()
  @Get()
  search(@Query('q') q: string, @Query('type') type?: string) {
    return this.svc.search(q, type);
  }
}
