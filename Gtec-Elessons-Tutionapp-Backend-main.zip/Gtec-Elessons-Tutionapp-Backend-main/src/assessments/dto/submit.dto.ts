import { IsObject } from 'class-validator';

export class SubmitAttemptDto {
  // { questionId: selectedOptionId }
  @IsObject()
  answers: Record<string, string>;
}
