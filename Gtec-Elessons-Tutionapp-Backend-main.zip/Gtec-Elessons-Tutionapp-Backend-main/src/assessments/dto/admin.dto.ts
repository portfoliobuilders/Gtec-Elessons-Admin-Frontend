import {
  IsArray, IsEnum, IsInt, IsNumber, IsOptional, IsString, Min, ValidateNested, IsBoolean,
} from 'class-validator';
import { Type } from 'class-transformer';
import { AssessmentType } from '@prisma/client';

export class CreateAssessmentDto {
  @IsEnum(AssessmentType)
  type: AssessmentType;
  @IsString() title: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() gradeId?: string;
  @IsOptional() @IsString() subjectId?: string;
  @IsOptional() @IsString() chapterId?: string;
  @IsOptional() @IsInt() @Min(1) durationMinutes?: number;
  @IsOptional() @IsInt() passPercent?: number;
  @IsOptional() @IsNumber() negativeMarking?: number;
  @IsOptional() @IsBoolean() shuffleQuestions?: boolean;
  @IsOptional() @IsBoolean() isPublished?: boolean;
}

class OptionDto {
  @IsString() id: string;
  @IsString() text: string;
}

export class AddQuestionDto {
  @IsString() text: string;
  @IsArray() @ValidateNested({ each: true }) @Type(() => OptionDto)
  options: OptionDto[];
  @IsString() correctOptionId: string;
  @IsOptional() @IsString() explanation?: string;
  @IsOptional() @IsInt() @Min(1) marks?: number;
  @IsOptional() @IsInt() order?: number;
}
