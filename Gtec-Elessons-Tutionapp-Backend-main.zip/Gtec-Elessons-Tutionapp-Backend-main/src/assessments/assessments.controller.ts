import {
  Body, Controller, Get, Param, Patch, Post, Query, UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { AssessmentsService } from './assessments.service';
import { SubmitAttemptDto } from './dto/submit.dto';
import { CreateAssessmentDto, AddQuestionDto } from './dto/admin.dto';

@UseGuards(JwtAuthGuard)
@Controller()
export class AssessmentsController {
  constructor(private svc: AssessmentsService) {}

  // ---- Student ----
  @Get('assessments')
  list(
    @CurrentUser() user: AuthUser,
    @Query('subjectId') subjectId?: string,
    @Query('chapterId') chapterId?: string,
    @Query('type') type?: string,
  ) {
    return this.svc.list(user.id, { subjectId, chapterId, type });
  }

  @Get('assessments/:id')
  get(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.getForAttempt(user.id, id);
  }

  @Post('assessments/:id/submit')
  submit(
    @CurrentUser() user: AuthUser,
    @Param('id') id: string,
    @Body() dto: SubmitAttemptDto,
  ) {
    return this.svc.submit(user.id, id, dto.answers);
  }

  @Get('me/attempts')
  attempts(@CurrentUser() user: AuthUser) {
    return this.svc.myAttempts(user.id);
  }

  // ---- Admin ----
  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Get('admin/assessments')
  adminList(@CurrentUser() user: AuthUser) {
    return this.svc.adminList(user);
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/assessments')
  create(@CurrentUser() user: AuthUser, @Body() dto: CreateAssessmentDto) {
    return this.svc.create(dto, user);
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/grades/:gradeId/assessments')
  createGradeAssessment(@CurrentUser() user: AuthUser, @Param('gradeId') gradeId: string, @Body() dto: CreateAssessmentDto) {
    return this.svc.create({ ...dto, gradeId }, user);
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/subjects/:subjectId/assessments')
  createSubjectAssessment(@CurrentUser() user: AuthUser, @Param('subjectId') subjectId: string, @Body() dto: CreateAssessmentDto) {
    return this.svc.create({ ...dto, subjectId }, user);
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/chapters/:chapterId/assessments')
  createChapterAssessment(@CurrentUser() user: AuthUser, @Param('chapterId') chapterId: string, @Body() dto: CreateAssessmentDto) {
    return this.svc.create({ ...dto, chapterId }, user);
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/assessments/:id/questions')
  addQuestion(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() dto: AddQuestionDto) {
    return this.svc.addQuestion(id, dto, user);
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Patch('admin/assessments/:id/publish')
  publish(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() body: { isPublished: boolean }) {
    return this.svc.publish(id, body?.isPublished ?? true, user);
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Get('admin/assessments/:id')
  adminGet(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.adminGet(id, user);
  }
}
