import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AccessService } from '../access/access.service';

interface Requester {
  id: string;
  role: string;
}

@Injectable()
export class AssessmentsService {
  constructor(
    private prisma: PrismaService,
    private access: AccessService,
  ) {}

  // TEACHER may only view/manage assessments tied to a subject they teach;
  // ADMIN/SUPER_ADMIN are unrestricted. Grade-wide assessments (no subjectId)
  // have no single teacher owner, so TEACHER is denied on those too.
  private async assertAssessmentOwnership(assessmentId: string, requester?: Requester) {
    const assessment = await this.prisma.assessment.findUnique({
      where: { id: assessmentId },
      select: { subject: { select: { teacherId: true } } },
    });
    if (!assessment) throw new NotFoundException('Assessment not found');
    if (requester?.role === 'TEACHER' && assessment.subject?.teacherId !== requester.id) {
      throw new ForbiddenException('You can only manage assessments for subjects you teach');
    }
  }

  private async assertAccess(userId: string, assessmentId: string) {
    const a = await this.prisma.assessment.findUnique({
      where: { id: assessmentId },
      select: { gradeId: true, subjectId: true, chapterId: true, isPublished: true },
    });
    if (!a || !a.isPublished) throw new NotFoundException('Assessment not found');
    const ok = await this.access.canAccessScope(userId, a);
    if (!ok) throw new ForbiddenException('You have not purchased access to this test');
  }

  // ---- Student: list ----
  async list(userId: string, filter: { subjectId?: string; chapterId?: string; type?: string }) {
    const items = await this.prisma.assessment.findMany({
      where: {
        isPublished: true,
        ...(filter.subjectId ? { subjectId: filter.subjectId } : {}),
        ...(filter.chapterId ? { chapterId: filter.chapterId } : {}),
        ...(filter.type ? { type: filter.type as any } : {}),
      },
      include: { _count: { select: { questions: true } } },
      orderBy: { createdAt: 'desc' },
    });

    // annotate with access + best score, keep answers hidden
    const results: any[] = [];
    for (const a of items) {
      const hasAccess = await this.access.canAccessScope(userId, a);
      const best = await this.prisma.assessmentAttempt.findFirst({
        where: { userId, assessmentId: a.id, status: 'SUBMITTED' },
        orderBy: { score: 'desc' },
        select: { score: true, totalMarks: true },
      });
      results.push({
        id: a.id,
        type: a.type,
        title: a.title,
        durationMinutes: a.durationMinutes,
        questionCount: a._count.questions,
        hasAccess,
        bestScore: best?.score ?? null,
        totalMarks: best?.totalMarks ?? null,
      });
    }
    return results;
  }

  // ---- Student: get test to attempt (no correct answers) ----
  async getForAttempt(userId: string, assessmentId: string) {
    await this.assertAccess(userId, assessmentId);
    const a = await this.prisma.assessment.findUnique({
      where: { id: assessmentId },
      include: { questions: { orderBy: { order: 'asc' } } },
    });
    if (!a) throw new NotFoundException('Assessment not found');

    let questions = a.questions;
    if (a.shuffleQuestions) {
      questions = [...questions];
      for (let i = questions.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [questions[i], questions[j]] = [questions[j], questions[i]];
      }
    }

    return {
      id: a.id,
      type: a.type,
      title: a.title,
      description: a.description,
      durationMinutes: a.durationMinutes,
      negativeMarking: a.negativeMarking ?? 0,
      totalMarks: questions.reduce((s, q) => s + q.marks, 0),
      questions: questions.map((q) => ({
        id: q.id,
        text: q.text,
        options: q.options,
        marks: q.marks,
      })),
    };
  }

  // ---- Student: submit + auto-grade ----
  async submit(userId: string, assessmentId: string, answers: Record<string, string>) {
    await this.assertAccess(userId, assessmentId);
    const assessment = await this.prisma.assessment.findUnique({ where: { id: assessmentId } });
    if (!assessment) throw new NotFoundException('Assessment not found');
    const questions = await this.prisma.question.findMany({ where: { assessmentId } });
    if (questions.length === 0) throw new BadRequestException('This test has no questions');

    const negPerWrong = assessment.negativeMarking ?? 0;
    let score = 0;
    let correctCount = 0;
    const totalMarks = questions.reduce((s, q) => s + q.marks, 0);
    const review = questions.map((q) => {
      const given = answers?.[q.id];
      const isCorrect = given === q.correctOptionId;
      if (isCorrect) {
        score += q.marks;
        correctCount++;
      } else if (given && negPerWrong > 0) {
        score -= negPerWrong;
      }
      return {
        questionId: q.id,
        yourAnswer: given ?? null,
        correctOptionId: q.correctOptionId,
        isCorrect,
        marks: q.marks,
        explanation: q.explanation ?? null,
      };
    });
    score = Math.max(0, Math.round(score * 100) / 100);

    const attempt = await this.prisma.assessmentAttempt.create({
      data: {
        userId,
        assessmentId,
        answers: answers ?? {},
        score,
        totalMarks,
        correctCount,
        status: 'SUBMITTED',
        submittedAt: new Date(),
      },
    });

    const percent = totalMarks > 0 ? Math.round((score / totalMarks) * 100) : 0;
    return {
      attemptId: attempt.id,
      score,
      totalMarks,
      correctCount,
      questionCount: questions.length,
      percent,
      review,
    };
  }

  // ---- Student: attempt history ----
  async myAttempts(userId: string) {
    return this.prisma.assessmentAttempt.findMany({
      where: { userId, status: 'SUBMITTED' },
      orderBy: { submittedAt: 'desc' },
      include: { assessment: { select: { title: true, type: true } } },
    });
  }

  // ---- Admin: Assessment Engine ----
  // TEACHER sees only assessments tied to a subject they teach;
  // ADMIN/SUPER_ADMIN gets the full unfiltered list, as before.
  async adminList(requester?: Requester) {
    const teacherId = requester?.role === 'TEACHER' ? requester.id : undefined;
    return this.prisma.assessment.findMany({
      where: teacherId ? { subject: { teacherId } } : undefined,
      orderBy: { createdAt: 'desc' },
      include: {
        _count: { select: { questions: true } },
        grade: { select: { name: true } },
        subject: { select: { name: true } },
        chapter: { select: { name: true } },
      },
    });
  }

  async create(dto: any, requester?: Requester) {
    if (requester?.role === 'TEACHER') {
      if (!dto.subjectId) throw new ForbiddenException('subjectId is required for a teacher-created assessment');
      const subject = await this.prisma.subject.findUnique({ where: { id: dto.subjectId }, select: { teacherId: true } });
      if (subject?.teacherId !== requester.id) {
        throw new ForbiddenException('You can only create assessments for subjects you teach');
      }
    }
    return this.prisma.assessment.create({ data: dto });
  }

  async addQuestion(assessmentId: string, dto: any, requester?: Requester) {
    await this.assertAssessmentOwnership(assessmentId, requester);
    return this.prisma.question.create({
      data: {
        assessmentId,
        text: dto.text,
        options: dto.options,
        correctOptionId: dto.correctOptionId,
        explanation: dto.explanation,
        marks: dto.marks ?? 1,
        order: dto.order ?? 0,
      },
    });
  }

  async publish(assessmentId: string, isPublished: boolean, requester?: Requester) {
    await this.assertAssessmentOwnership(assessmentId, requester);
    return this.prisma.assessment.update({
      where: { id: assessmentId },
      data: { isPublished },
    });
  }

  async adminGet(assessmentId: string, requester?: Requester) {
    await this.assertAssessmentOwnership(assessmentId, requester);
    const a = await this.prisma.assessment.findUnique({
      where: { id: assessmentId },
      include: { questions: { orderBy: { order: 'asc' } } },
    });
    if (!a) throw new NotFoundException('Assessment not found');
    return a; // full detail incl. correct answers (admin/owning-teacher only)
  }
}
