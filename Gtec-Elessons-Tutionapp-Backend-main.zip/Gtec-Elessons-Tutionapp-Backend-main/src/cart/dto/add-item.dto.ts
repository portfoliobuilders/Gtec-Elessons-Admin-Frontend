import { IsString, IsNotEmpty, IsOptional } from 'class-validator';

export class AddItemDto {
  // Either productId or subjectId is required (checked in CartService) —
  // subjectId lets the app add a subject's product straight from the
  // subject screen without first looking up its underlying product id.
  @IsOptional()
  @IsString()
  @IsNotEmpty()
  productId?: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  subjectId?: string;
}
