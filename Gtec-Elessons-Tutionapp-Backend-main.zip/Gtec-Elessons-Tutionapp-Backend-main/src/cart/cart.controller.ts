import { Body, Controller, Delete, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { CartService } from './cart.service';
import { AddItemDto } from './dto/add-item.dto';

@UseGuards(JwtAuthGuard)
@Controller('cart')
export class CartController {
  constructor(private cart: CartService) {}

  @Get()
  view(@CurrentUser() user: AuthUser, @Query('currency') currency?: string) {
    return this.cart.view(user.id, currency);
  }

  // Alias: the cart view already returns the full price breakdown.
  @Get('quote')
  quote(@CurrentUser() user: AuthUser, @Query('currency') currency?: string) {
    return this.cart.view(user.id, currency);
  }

  @Post('items')
  add(@CurrentUser() user: AuthUser, @Body() dto: AddItemDto) {
    return this.cart.addItem(user.id, dto);
  }

  @Delete('items/:productId')
  remove(@CurrentUser() user: AuthUser, @Param('productId') productId: string) {
    return this.cart.removeItem(user.id, productId);
  }

  @Delete()
  clear(@CurrentUser() user: AuthUser) {
    return this.cart.clear(user.id);
  }
}
