import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PricingService } from '../pricing/pricing.service';
import { AccessService } from '../access/access.service';

@Injectable()
export class CartService {
  constructor(
    private prisma: PrismaService,
    private pricing: PricingService,
    private access: AccessService,
  ) {}

  private async getOrCreateCart(userId: string) {
    return this.prisma.cart.upsert({
      where: { userId },
      update: {},
      create: { userId },
    });
  }

  async view(userId: string, currency?: string) {
    const quote = await this.pricing.quoteForCart(userId, currency);
    return quote;
  }

  async addItem(userId: string, dto: { productId?: string; subjectId?: string }) {
    const productId = dto.productId ?? (await this.resolveSubjectProductId(dto.subjectId));
    const product = await this.prisma.product.findUnique({ where: { id: productId } });
    if (!product || !product.isActive) throw new NotFoundException('Product not found');

    // Don't let the user buy something they already own.
    const owned = await this.userOwnsProduct(userId, product);
    if (owned) throw new ConflictException('You already have access to this');

    const cart = await this.getOrCreateCart(userId);
    try {
      await this.prisma.cartItem.create({ data: { cartId: cart.id, productId } });
    } catch {
      throw new BadRequestException('Item already in cart');
    }
    return this.view(userId);
  }

  private async resolveSubjectProductId(subjectId?: string): Promise<string> {
    if (!subjectId) throw new BadRequestException('productId or subjectId is required');
    const product = await this.prisma.product.findFirst({
      where: { subjectId, type: 'SUBJECT', isActive: true },
    });
    if (!product) throw new NotFoundException('No purchasable product found for this subject');
    return product.id;
  }

  async removeItem(userId: string, productId: string) {
    const cart = await this.prisma.cart.findUnique({ where: { userId } });
    if (cart) {
      await this.prisma.cartItem
        .deleteMany({ where: { cartId: cart.id, productId } })
        .catch(() => undefined);
    }
    return this.view(userId);
  }

  async clear(userId: string) {
    const cart = await this.prisma.cart.findUnique({ where: { userId } });
    if (cart) await this.prisma.cartItem.deleteMany({ where: { cartId: cart.id } });
    return this.view(userId);
  }

  // Checks whether an active enrollment already covers this product's scope —
  // including coverage from a broader enrollment (e.g. a Full Bundle already
  // covers every subject/chapter in that grade).
  //
  // format-aware: access.canAccessScope() matches on scope alone, regardless
  // of format — so without this split, a student who already owns "Grade 8
  // — Recorded" (RECORDED) would be reported as already owning "Grade 8 —
  // Recorded + Mentor" (LIVE_AND_RECORDED) for the same grade too, and get
  // blocked (409) from ever buying the upgrade. RECORDED is still checked
  // via canAccessScope (LIVE_AND_RECORDED is a superset — it covers a
  // RECORDED purchase). LIVE_AND_RECORDED is checked via hasLiveAccess,
  // which only matches an existing LIVE_AND_RECORDED enrollment — so an
  // existing RECORDED-only enrollment no longer falsely blocks the upgrade.
  private async userOwnsProduct(
    userId: string,
    product: { type: string; format: string; gradeId: string | null; subjectId: string | null; chapterId: string | null },
  ): Promise<boolean> {
    if (product.type === 'MENTORSHIP') {
      const scopes = await this.access.getAccessScopes(userId);
      return !!product.gradeId && scopes.grades.includes(product.gradeId);
    }
    if (product.format === 'LIVE_AND_RECORDED') {
      return this.access.hasLiveAccess(userId, {
        gradeId: product.gradeId ?? undefined,
        subjectId: product.subjectId ?? undefined,
        chapterId: product.chapterId ?? undefined,
      });
    }
    return this.access.canAccessScope(userId, {
      gradeId: product.gradeId,
      subjectId: product.subjectId,
      chapterId: product.chapterId,
    });
  }
}
