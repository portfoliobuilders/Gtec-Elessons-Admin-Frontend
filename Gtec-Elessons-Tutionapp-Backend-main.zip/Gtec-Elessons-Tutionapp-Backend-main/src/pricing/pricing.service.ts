import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CurrencyService } from '../regions/currency.service';
import { SettingsService } from '../settings/settings.service';
import { roundMoney } from '../common/money/money.util';

export interface QuoteLine {
  productId: string;
  title: string;
  // Business-currency decimal (e.g. 12000 for ₹12,000) — see Phase 5B report.
  amount: number;
  /** @deprecated legacy "amount × 100" bookkeeping unit, kept only because
   * Order/OrderItem's schema still stores prices this way. Not a
   * payment-gateway minor unit — see src/common/money. */
  priceCents: number;
}
export interface Quote {
  region: string;
  currency: string;
  symbol: string;
  lines: QuoteLine[];
  /** @deprecated legacy "amount × 100" bookkeeping — see QuoteLine.priceCents */
  subtotalCents: number;
  /** @deprecated */
  discountCents: number; // 0 for now (bundles/coupons are Phase 2)
  /** @deprecated */
  taxCents: number;
  /** @deprecated */
  totalCents: number;
  // Business-currency decimals — the exact amount to charge, in `currency`.
  // This is what PaymentsService feeds to the Razorpay-boundary conversion
  // (src/common/money) to get the gateway's minor-unit amount. Never derive
  // the gateway amount from the *Cents fields above — those are rounded to
  // 2dp bookkeeping and lossy for 3-decimal currencies (KWD/BHD/OMR).
  subtotalAmount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
}

@Injectable()
export class PricingService {
  constructor(
    private prisma: PrismaService,
    private currency: CurrencyService,
    private settings: SettingsService,
  ) { }

  // Resolve the price for a product in the given region/currency:
  //   1. an exact ProductPrice row for that region+currency (admin-set, takes priority), else
  //   2. the INR base price converted live to the target currency.
  // Returns the plain business-currency decimal amount (e.g. 800 for AED
  // 800) — never a payment-gateway minor unit.
  private async resolvePrice(
    prices: { region: string; currency: string; amount: unknown }[],
    region: string,
    currency: string,
  ): Promise<number | null> {
    const exact = prices.find((p) => p.region === region && p.currency === currency);
    if (exact) return Number(exact.amount);

    const baseInr = prices.find((p) => p.region === 'IN' && p.currency === 'INR');
    if (!baseInr) return null;
    const baseAmount = Number(baseInr.amount);
    if (currency === 'INR') return baseAmount;

    // CurrencyService's live-FX conversion still works in its own legacy
    // "amount × 100" convention internally (an unrelated display subsystem,
    // untouched by Phase 5B — see report). Bridge into/out of that
    // convention right here rather than changing CurrencyService's contract.
    const convertedCents = await this.currency.convertFromINR(Math.round(baseAmount * 100), currency);
    return convertedCents / 100;
  }

  // Build a full price breakdown for the user's current cart.
  // `currencyOverride` lets the app quote in whatever currency the user picked
  // on the pre-login region screen, regardless of their saved profile.
  async quoteForCart(userId: string, currencyOverride?: string): Promise<Quote> {
    const profile = await this.prisma.studentProfile.findUnique({ where: { userId } });
    const currency = (currencyOverride || profile?.currency || await this.settings.defaultCurrency()).toUpperCase();
    const region = profile?.region ?? (currency === 'INR' ? 'IN' : 'INTL');

    const cart = await this.prisma.cart.findUnique({
      where: { userId },
      include: { items: { include: { product: { include: { prices: true } } } } },
    });

    const lines: QuoteLine[] = [];
    for (const item of cart?.items ?? []) {
      const amount = await this.resolvePrice(item.product.prices, region, currency);
      if (amount == null) continue; // skip products with no price in this currency
      lines.push({
        productId: item.productId,
        title: item.product.title,
        amount,
        priceCents: Math.round(amount * 100),
      });
    }

    const subtotalAmount = lines.reduce((sum, l) => sum + l.amount, 0);
    const discountAmount = 0;
    const taxableAmount = subtotalAmount - discountAmount;
    // GST is temporarily disabled. Keep the calculation available for a later
    // re-enable without applying the gst_percent setting today.
    // const gstPercent = await this.settings.gstPercent();
    // const taxAmount = currency === 'INR' ? roundMoney((taxableAmount * gstPercent) / 100, currency) : 0;
    const taxAmount = 0;
    const totalAmount = roundMoney(taxableAmount + taxAmount, currency);

    const subtotalCents = Math.round(subtotalAmount * 100);
    const discountCents = 0;
    const taxCents = Math.round(taxAmount * 100);
    const totalCents = subtotalCents - discountCents + taxCents;

    return {
      region,
      currency,
      symbol: await this.currency.symbolFor(currency),
      lines,
      subtotalCents,
      discountCents,
      taxCents,
      totalCents,
      subtotalAmount,
      discountAmount,
      taxAmount,
      totalAmount,
    };
  }
}
