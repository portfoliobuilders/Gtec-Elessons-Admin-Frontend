import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { LiveService } from './live.service';
import { LiveController } from './live.controller';
import { LiveChatGateway } from './live-chat.gateway';

@Module({
  imports: [JwtModule.register({})],
  controllers: [LiveController],
  providers: [LiveService, LiveChatGateway],
})
export class LiveModule {}
