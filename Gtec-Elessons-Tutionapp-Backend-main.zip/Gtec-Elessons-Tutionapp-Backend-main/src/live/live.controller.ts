import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { LiveService } from './live.service';
import { CreateLiveClassDto, ChatMessageDto } from './dto/live.dto';

@UseGuards(JwtAuthGuard)
@Controller()
export class LiveController {
  constructor(private svc: LiveService) {}

  // ---- Student ----
  @Get('live-classes')
  upcoming(@CurrentUser() user: AuthUser) {
    return this.svc.upcoming(user.id);
  }

  @Post('live-classes/:id/reminder')
  reminderOn(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.setReminder(user.id, id, true);
  }

  @Post('live-classes/:id/reminder/off')
  reminderOff(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.setReminder(user.id, id, false);
  }

  @Get('live-classes/:id/join')
  join(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.join(user.id, id);
  }

  @Get('live-classes/:id/chat')
  chat(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.recentMessages(user.id, id);
  }

  @Post('live-classes/:id/chat')
  postChat(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() dto: ChatMessageDto) {
    return this.svc.postMessage(user.id, id, dto.message);
  }

  // ---- Admin / Teacher ----
  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/live-classes')
  create(@Body() dto: CreateLiveClassDto) {
    return this.svc.create(dto);
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/subjects/:subjectId/live-classes')
  createSubjectLiveClass(@Param('subjectId') subjectId: string, @Body() dto: CreateLiveClassDto) {
    return this.svc.create({ ...dto, subjectId });
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/grades/:gradeId/live-classes')
  createGradeLiveClass(@Param('gradeId') gradeId: string, @Body() dto: CreateLiveClassDto) {
    return this.svc.create({ ...dto, gradeId });
  }

  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
  @Post('admin/live-classes/:id/status')
  status(@Param('id') id: string, @Body() body: { status: 'SCHEDULED' | 'LIVE' | 'ENDED' | 'CANCELLED' }) {
    return this.svc.setStatus(id, body.status);
  }
}
