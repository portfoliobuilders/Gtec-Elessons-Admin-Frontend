import {
  Injectable, NotFoundException, ForbiddenException, BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AccessService } from '../access/access.service';
import { parseYouTubeId } from '../common/utils/youtube.util';

@Injectable()
export class LiveService {
  constructor(
    private prisma: PrismaService,
    private access: AccessService,
  ) {}

  // Requires a LIVE_AND_RECORDED enrollment covering the class's scope.
  private async assertLiveAccess(userId: string, live: { gradeId: string | null; subjectId: string | null }) {
    const ok = await this.access.hasLiveAccess(userId, {
      gradeId: live.gradeId ?? undefined,
      subjectId: live.subjectId ?? undefined,
    });
    if (!ok) throw new ForbiddenException('Live classes need the Live + Recorded plan for this course');
  }

  // ---- Student: schedule ----
  async upcoming(userId: string) {
    const items = await this.prisma.liveClass.findMany({
      where: { status: { in: ['SCHEDULED', 'LIVE'] } },
      orderBy: { startsAt: 'asc' },
      include: {
        subject: { select: { name: true } },
        grade: { select: { name: true } },
        reminders: { where: { userId }, select: { id: true } },
      },
    });
    const out: any[] = [];
    for (const lc of items) {
      const hasLive = await this.access.hasLiveAccess(userId, {
        gradeId: lc.gradeId ?? undefined,
        subjectId: lc.subjectId ?? undefined,
      });
      out.push({
        id: lc.id,
        title: lc.title,
        subject: lc.subject?.name ?? lc.grade?.name ?? null,
        mentorName: lc.mentorName,
        startsAt: lc.startsAt,
        status: lc.status,
        watchingCount: lc.watchingCount,
        reminderSet: lc.reminders.length > 0,
        hasLiveAccess: hasLive,
      });
    }
    return out;
  }

  async setReminder(userId: string, liveClassId: string, on: boolean) {
    const lc = await this.prisma.liveClass.findUnique({ where: { id: liveClassId } });
    if (!lc) throw new NotFoundException('Live class not found');
    if (on) {
      await this.prisma.liveClassReminder
        .create({ data: { liveClassId, userId } })
        .catch(() => undefined); // ignore duplicate
    } else {
      await this.prisma.liveClassReminder.deleteMany({ where: { liveClassId, userId } });
    }
    return { reminderSet: on };
  }

  // ---- Student: join a live room ----
  async join(userId: string, liveClassId: string) {
    const lc = await this.prisma.liveClass.findUnique({ where: { id: liveClassId } });
    if (!lc) throw new NotFoundException('Live class not found');
    await this.assertLiveAccess(userId, { gradeId: lc.gradeId, subjectId: lc.subjectId });
    if (lc.status !== 'LIVE') throw new BadRequestException('This class is not live right now');

    return {
      id: lc.id,
      title: lc.title,
      mentorName: lc.mentorName,
      youtubeId: lc.youtubeId,
      embedUrl: lc.youtubeId ? `https://www.youtube.com/embed/${lc.youtubeId}?autoplay=1` : null,
      watchingCount: lc.watchingCount,
    };
  }

  async recentMessages(userId: string, liveClassId: string) {
    const lc = await this.prisma.liveClass.findUnique({ where: { id: liveClassId } });
    if (!lc) throw new NotFoundException('Live class not found');
    await this.assertLiveAccess(userId, { gradeId: lc.gradeId, subjectId: lc.subjectId });
    return this.prisma.liveChatMessage.findMany({
      where: { liveClassId },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: { user: { select: { name: true } } },
    });
  }

  async postMessage(userId: string, liveClassId: string, message: string) {
    const lc = await this.prisma.liveClass.findUnique({ where: { id: liveClassId } });
    if (!lc) throw new NotFoundException('Live class not found');
    await this.assertLiveAccess(userId, { gradeId: lc.gradeId, subjectId: lc.subjectId });
    if (lc.status !== 'LIVE') throw new BadRequestException('Chat is only open during the live class');
    return this.prisma.liveChatMessage.create({ data: { liveClassId, userId, message } });
  }

  // ---- Admin/Teacher ----
  async create(dto: any) {
    return this.prisma.liveClass.create({
      data: {
        title: dto.title,
        description: dto.description,
        gradeId: dto.gradeId ?? null,
        subjectId: dto.subjectId ?? null,
        mentorName: dto.mentorName,
        youtubeUrl: dto.youtubeUrl ?? null,
        youtubeId: parseYouTubeId(dto.youtubeUrl),
        startsAt: new Date(dto.startsAt),
        endsAt: dto.endsAt ? new Date(dto.endsAt) : null,
      },
    });
  }

  async setStatus(liveClassId: string, status: 'SCHEDULED' | 'LIVE' | 'ENDED' | 'CANCELLED') {
    return this.prisma.liveClass.update({ where: { id: liveClassId }, data: { status } });
  }
}
