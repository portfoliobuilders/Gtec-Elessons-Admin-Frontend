import { IsDateString, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class CreateLiveClassDto {
  @IsString() title: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() gradeId?: string;
  @IsOptional() @IsString() subjectId?: string;
  @IsString() mentorName: string;
  @IsOptional() @IsString() youtubeUrl?: string;
  @IsDateString() startsAt: string;
  @IsOptional() @IsDateString() endsAt?: string;
}

export class ChatMessageDto {
  @IsString() @MinLength(1) @MaxLength(500) message: string;
}
