import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { LiveService } from './live.service';

interface AuthedSocket extends Socket {
  data: { userId: string; role: string };
}

@WebSocketGateway({ namespace: '/live', cors: { origin: true, credentials: true } })
export class LiveChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;

  constructor(
    private jwt: JwtService,
    private live: LiveService,
  ) {}

  async handleConnection(client: AuthedSocket) {
    try {
      const token = client.handshake.auth?.token || client.handshake.query?.token;
      if (!token) throw new Error('No token provided');
      const payload = await this.jwt.verifyAsync(String(token), { secret: process.env.JWT_ACCESS_SECRET });
      client.data = { userId: payload.sub, role: payload.role };
    } catch {
      client.emit('error', { message: 'Authentication failed' });
      client.disconnect(true);
    }
  }

  handleDisconnect() {}

  // Access-gating (enrollment + LIVE-status checks) is enforced inside
  // LiveService.recentMessages/postMessage — reused as-is, not duplicated here.
  @SubscribeMessage('join')
  async onJoin(@ConnectedSocket() client: AuthedSocket, @MessageBody() body: { liveClassId: string }) {
    try {
      const messages = await this.live.recentMessages(client.data.userId, body.liveClassId);
      client.join(body.liveClassId);
      client.emit('history', messages.reverse());
    } catch (e: any) {
      client.emit('error', { message: e.message ?? 'Could not join chat' });
    }
  }

  @SubscribeMessage('message')
  async onMessage(@ConnectedSocket() client: AuthedSocket, @MessageBody() body: { liveClassId: string; message: string }) {
    try {
      const created = await this.live.postMessage(client.data.userId, body.liveClassId, body.message);
      this.server.to(body.liveClassId).emit('message', created);
    } catch (e: any) {
      client.emit('error', { message: e.message ?? 'Could not send message' });
    }
  }
}
