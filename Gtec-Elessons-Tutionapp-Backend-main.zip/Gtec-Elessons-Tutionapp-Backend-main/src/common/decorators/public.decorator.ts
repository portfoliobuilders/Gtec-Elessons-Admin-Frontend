import { SetMetadata } from '@nestjs/common';

export const IS_PUBLIC_KEY = 'isPublic';
// Mark a route as not requiring a JWT (e.g. catalog browsing, auth endpoints).
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
