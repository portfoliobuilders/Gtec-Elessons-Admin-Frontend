// Keep the legacy helper for the primary/base price, but add a richer
// multi-price representation so admin responses can expose all configured
// regional prices without relying on array order.
//
// Phase 5B: `amount`/`compareAt` are the canonical business-currency values
// (e.g. 12000 for ₹12,000). `amountCents`/`compareAtCents` are kept
// alongside them only for backward compatibility with clients (admin panel,
// Flutter) that haven't migrated off the old minor-unit fields yet — see the
// Phase 5B report §10-11. New code should read `amount`, not `amountCents`.
import { Prisma } from '@prisma/client';

export interface FlatPrice {
  productId: string;
  amount: number;
  region: string;
  currency: string;
  compareAt?: number;
  /** @deprecated use `amount` */
  amountCents: number;
  /** @deprecated use `compareAt` */
  compareAtCents?: number;
  displayPrice?: number;
}

export interface MultiFlatPrice {
  productId: string;
  price?: FlatPrice;
  prices: FlatPrice[];
}

interface PriceLike {
  region: string;
  currency: string;
  amount: Prisma.Decimal;
  compareAt: Prisma.Decimal | null;
}

interface ProductLike {
  id: string;
  displayPrice?: number;
  prices: PriceLike[];
}

function buildFlatPrice(productId: string, price: PriceLike, displayPrice?: number): FlatPrice {
  const amount = Number(price.amount);
  const compareAt = price.compareAt != null ? Number(price.compareAt) : undefined;
  return {
    productId,
    amount,
    region: price.region,
    currency: price.currency,
    ...(compareAt !== undefined ? { compareAt } : {}),
    amountCents: Math.round(amount * 100),
    ...(compareAt !== undefined ? { compareAtCents: Math.round(compareAt * 100) } : {}),
    ...(displayPrice !== undefined ? { displayPrice } : {}),
  };
}

export function toFlatPrice(product: ProductLike | null | undefined): FlatPrice | undefined {
  const price = product ? pickPrimaryPrice(product.prices) : undefined;
  if (!product || !price) return undefined;
  return buildFlatPrice(product.id, price, product.displayPrice);
}

export function toMultiFlatPrice(product: ProductLike | null | undefined): MultiFlatPrice | undefined {
  if (!product) return undefined;
  const prices = product.prices.map((price) => buildFlatPrice(product.id, price, product.displayPrice));
  if (prices.length === 0) return undefined;
  const primary = pickPrimaryPrice(product.prices);
  return {
    productId: product.id,
    ...(primary ? { price: buildFlatPrice(product.id, primary, product.displayPrice) } : {}),
    prices,
  };
}

function pickPrimaryPrice(prices: PriceLike[]) {
  return prices.find((p) => p.region === 'IN' && p.currency === 'INR') ?? prices[0];
}

// ---- Multiple product variants per scope (e.g. RECORDED vs LIVE_AND_RECORDED
// for the same grade/subject/chapter) ----
//
// toFlatPrice/toMultiFlatPrice above intentionally collapse a scope's
// products down to a single `products[0]` for the legacy `price`/`prices`
// response fields — kept as-is so existing clients don't break. This is the
// richer view: every active product for the scope, each with its own
// id/type/format/title/accessDays and its own flattened price list, so a
// caller can actually tell "Grade 8 — Recorded" apart from "Grade 8 —
// Recorded + Mentor" instead of only ever seeing whichever came first.
export interface ProductVariant {
  id: string;
  type: string;
  format: string;
  title: string;
  accessDays: number;
  isActive: boolean;
  price?: FlatPrice;
  prices: FlatPrice[];
}

interface ProductVariantLike {
  id: string;
  type: string;
  format: string;
  title: string;
  accessDays: number;
  isActive: boolean;
  displayPrice?: number;
  prices: PriceLike[];
}

export function toProductVariants(products: ProductVariantLike[] | null | undefined): ProductVariant[] {
  if (!products || products.length === 0) return [];
  return products.map((p) => {
    const primary = pickPrimaryPrice(p.prices);
    return {
      id: p.id,
      type: p.type,
      format: p.format,
      title: p.title,
      accessDays: p.accessDays,
      isActive: p.isActive,
      ...(primary ? { price: buildFlatPrice(p.id, primary, p.displayPrice) } : {}),
      prices: p.prices.map((price) => buildFlatPrice(p.id, price, p.displayPrice)),
    };
  });
}
