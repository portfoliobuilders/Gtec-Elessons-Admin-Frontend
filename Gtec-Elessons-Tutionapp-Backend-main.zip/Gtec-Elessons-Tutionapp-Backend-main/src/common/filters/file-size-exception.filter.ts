import { ArgumentsHost, BadRequestException, Catch, ExceptionFilter, HttpStatus, PayloadTooLargeException } from '@nestjs/common';
import { Response } from 'express';
import { MAX_UPLOAD_FILE_SIZE_MB } from '../utils/upload-limits';

// multer's fileSize limit (see ../utils/upload-limits.ts) surfaces through
// @nestjs/platform-express's FileInterceptor as a PayloadTooLargeException
// whose message is always the generic "File too large" — it never states
// the actual limit. Rewritten here as a 400 with the real number, matching
// how every other validation failure in this API responds
// (BadRequestException), instead of a bare, unexplained 413.
@Catch(PayloadTooLargeException)
export class FileSizeExceptionFilter implements ExceptionFilter {
  catch(_exception: PayloadTooLargeException, host: ArgumentsHost) {
    const response = host.switchToHttp().getResponse<Response>();
    const body = new BadRequestException(
      `File too large. Maximum allowed size is ${MAX_UPLOAD_FILE_SIZE_MB}MB.`,
    ).getResponse();
    response.status(HttpStatus.BAD_REQUEST).json(body);
  }
}
