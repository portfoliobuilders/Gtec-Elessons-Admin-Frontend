import { BadRequestException } from '@nestjs/common';

// Resolves the canonical business-currency `amount`/`compareAt` from pricing
// input that may carry either the canonical field or the deprecated
// `*Cents` minor-unit field (Phase 5B backward compatibility — see report
// §11). Supplying both for the same value is rejected with 400 rather than
// silently picking one.
//
// The deprecated amountCents/compareAtCents fields are interpreted using the
// "value × 100" convention this API always used historically, for every
// currency (this backend never actually stored true gateway minor units —
// see report §1/§6), so amountCents=1200000 still resolves to amount=12000.

export function resolveAmount(input: {
  amount?: number;
  amountCents?: number;
}): number | undefined {
  if (input.amount !== undefined && input.amountCents !== undefined) {
    throw new BadRequestException(
      "Provide either 'amount' or the deprecated 'amountCents', not both.",
    );
  }
  if (input.amount !== undefined) return input.amount;
  if (input.amountCents !== undefined) return input.amountCents / 100;
  return undefined;
}

export function resolveCompareAt(input: {
  compareAt?: number;
  compareAtCents?: number;
}): number | undefined {
  if (input.compareAt !== undefined && input.compareAtCents !== undefined) {
    throw new BadRequestException(
      "Provide either 'compareAt' or the deprecated 'compareAtCents', not both.",
    );
  }
  if (input.compareAt !== undefined) return input.compareAt;
  if (input.compareAtCents !== undefined) return input.compareAtCents / 100;
  return undefined;
}
