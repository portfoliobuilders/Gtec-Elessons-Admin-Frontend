// The ONE place currency minor-unit/decimal-place conventions live for this
// app (Phase 5B). Business/admin code — catalog, pricing, admin, curriculum,
// orders — works entirely in plain business-currency decimals (12000 for
// ₹12,000, 65 for KWD 65) and never needs this. Only the payment-provider
// boundary (PaymentsService.createRazorpayOrder) converts a business amount
// into the gateway's smallest-unit integer, via toGatewayMinorUnits() below.
// Do not reintroduce a scattered `amount * 100` anywhere else.

// ISO 4217 minor units: most currencies use 2 decimal places (100 minor
// units per major unit). The Gulf "three-decimal" currencies use 3 (1000
// minor units per major unit — e.g. 1 KWD = 1000 fils).
const THREE_DECIMAL_CURRENCIES = new Set(['KWD', 'BHD', 'OMR']);
const DEFAULT_DECIMAL_PLACES = 2;

export function decimalPlacesFor(currency: string): number {
  return THREE_DECIMAL_CURRENCIES.has(currency.toUpperCase())
    ? 3
    : DEFAULT_DECIMAL_PLACES;
}

// Rounds a business-currency decimal amount to that currency's conventional
// precision (2dp for INR/AED/USD/QAR/SAR, 3dp for KWD/BHD/OMR). Plain
// sensible rounding for display/storage — NOT a payment-gateway conversion.
export function roundMoney(amount: number, currency: string): number {
  const factor = 10 ** decimalPlacesFor(currency);
  return Math.round((amount + Number.EPSILON) * factor) / factor;
}

// Converts a business-currency decimal amount (e.g. 12000 for ₹12,000, 800
// for AED 800, 65 for KWD 65) into the smallest-unit integer a payment
// gateway expects (paise, fils, ...). This is the only currency-aware
// minor-unit conversion in the app — see Phase 5B report §7-8. The frontend
// never supplies this value; it is always resolved server-side from the
// Product/ProductPrice the customer is actually buying.
export function toGatewayMinorUnits(amount: number, currency: string): number {
  const factor = 10 ** decimalPlacesFor(currency);
  return Math.round((amount + Number.EPSILON) * factor);
}
