import { BadRequestException } from '@nestjs/common';

// Single source of truth for turning admin-supplied input — a bare YouTube
// video id or a full YouTube URL — into the canonical 11-character id this
// backend stores. Used by lesson videos, grade/subject/chapter trailers, and
// live classes; do not duplicate this regex/parsing elsewhere.
const BARE_ID_RE = /^[A-Za-z0-9_-]{11}$/;

// Supports:
//   xvT1jH8B9AM                                        (bare id)
//   https://youtu.be/xvT1jH8B9AM
//   https://youtu.be/xvT1jH8B9AM?si=...                (any query string)
//   https://www.youtube.com/watch?v=xvT1jH8B9AM         (any param order)
//   https://www.youtube.com/embed/xvT1jH8B9AM
//   https://www.youtube.com/shorts/xvT1jH8B9AM
//   https://www.youtube.com/live/xvT1jH8B9AM
// Returns null for anything else — arbitrary non-YouTube URLs are never
// accepted as valid, even if they happen to end in an 11-char segment.
export function parseYouTubeId(value?: string): string | null {
  if (!value) return null;
  const trimmed = value.trim();
  if (BARE_ID_RE.test(trimmed)) return trimmed;

  try {
    const url = new URL(trimmed);
    if (url.hostname === 'youtu.be') {
      const id = url.pathname.slice(1);
      return BARE_ID_RE.test(id) ? id : null;
    }
    if (url.hostname.includes('youtube.com')) {
      const v = url.searchParams.get('v');
      if (v && BARE_ID_RE.test(v)) return v;
      const match = url.pathname.match(/(?:embed|shorts|live)\/([A-Za-z0-9_-]{11})/);
      if (match) return match[1];
    }
  } catch {
    // not a parseable URL — fall through to null
  }
  return null;
}

const ERROR_MESSAGE = 'youtubeId must be a valid YouTube video ID or YouTube URL';

// parseYouTubeId(), but throws the standard 400 instead of returning null —
// for the admin endpoints (lesson video, trailers) that must reject bad
// input rather than silently storing it.
export function resolveYoutubeId(value?: string): string {
  const id = parseYouTubeId(value);
  if (!id) throw new BadRequestException(ERROR_MESSAGE);
  return id;
}
