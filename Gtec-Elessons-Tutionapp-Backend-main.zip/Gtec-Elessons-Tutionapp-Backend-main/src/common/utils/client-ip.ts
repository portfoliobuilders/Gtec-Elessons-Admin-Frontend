import { Request } from 'express';

// Resolves the caller's real IP for geolocation. We read X-Forwarded-For
// ourselves rather than relying on Express's `trust proxy` (not configured in
// main.ts) — the header's first entry is the original client, appended to by
// each proxy hop. Falls back to the direct socket peer when the header is
// absent (e.g. local dev with no reverse proxy in front).
export function getClientIp(req: Request): string | undefined {
  const xff = req.headers['x-forwarded-for'];
  const first = Array.isArray(xff) ? xff[0] : xff?.split(',')[0];
  const raw = first?.trim() || req.ip || req.socket?.remoteAddress;
  if (!raw) return undefined;
  // IPv4-mapped IPv6 (e.g. "::ffff:127.0.0.1") — strip the prefix so geoip
  // lookups see the plain IPv4 form.
  return raw.startsWith('::ffff:') ? raw.slice(7) : raw;
}
