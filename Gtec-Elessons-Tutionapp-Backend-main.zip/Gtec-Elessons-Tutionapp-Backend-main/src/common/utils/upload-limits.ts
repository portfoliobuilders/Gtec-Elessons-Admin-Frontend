// Single source of truth for the max upload size enforced by multer's
// `limits.fileSize` on every file-upload route: avatar/KYC in
// ../../users/upload.config.ts and grade/subject/chapter icons in
// ../../admin/upload.config.ts. Bump MAX_UPLOAD_FILE_SIZE_MB to change the
// limit everywhere at once.
//
// See also filters/file-size-exception.filter.ts, which turns multer's
// generic "File too large" response into a message stating this number.
export const MAX_UPLOAD_FILE_SIZE_MB = 15;
export const MAX_UPLOAD_FILE_SIZE_BYTES = MAX_UPLOAD_FILE_SIZE_MB * 1024 * 1024;
