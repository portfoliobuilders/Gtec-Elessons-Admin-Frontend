import { Injectable } from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';

// Tracks by the request body's `email` when present — keeps forgot-password
// spam scoped to the targeted account instead of everyone sharing an IP/NAT.
// Falls back to the caller's IP for bodies with no email (e.g. reset-password,
// which only carries a token + newPassword).
@Injectable()
export class EmailOrIpThrottlerGuard extends ThrottlerGuard {
  protected async getTracker(req: Record<string, any>): Promise<string> {
    const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : undefined;
    return email || req.ip;
  }
}
