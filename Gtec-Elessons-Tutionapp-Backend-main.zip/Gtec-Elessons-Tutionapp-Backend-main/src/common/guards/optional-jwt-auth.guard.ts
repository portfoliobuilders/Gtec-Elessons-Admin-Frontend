import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

// Like JwtAuthGuard but never rejects: a valid token populates req.user,
// a missing or invalid one just leaves req.user undefined instead of 401ing.
// For routes that serve a smaller preview to logged-out callers.
@Injectable()
export class OptionalJwtAuthGuard extends AuthGuard('jwt') {
  handleRequest(_err: any, user: any) {
    return user || undefined;
  }
}
