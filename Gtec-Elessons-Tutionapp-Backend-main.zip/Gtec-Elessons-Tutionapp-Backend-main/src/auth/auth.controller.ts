import { Body, Controller, Post, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { AuthService } from './auth.service';
import { Public } from '../common/decorators/public.decorator';
import { EmailOrIpThrottlerGuard } from '../common/guards/email-throttler.guard';
import { GoogleLoginDto } from './dto/google-login.dto';
import { RefreshDto } from './dto/refresh.dto';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { RequestOtpDto, VerifyOtpDto } from './dto/otp.dto';
import { ForgotPasswordDto, ResetPasswordDto } from './dto/password.dto';
import { AppleLoginDto } from './dto/apple-login.dto';
import { VerifyEmailDto } from './dto/verify-email.dto';

@Controller('auth')
export class AuthController {
  constructor(private auth: AuthService) {}

  @Public() @Post('register')
  register(@Body() dto: RegisterDto) {
    return this.auth.register(dto);
  }

  @Public() @Post('register-teacher')
  registerTeacher(@Body() dto: RegisterDto) {
    return this.auth.registerTeacher(dto);
  }

  @Public() @Post('login')
  login(@Body() dto: LoginDto) {
    return this.auth.login(dto);
  }

  // Max 3 requests per email per 15 minutes — same shape as forgot-password,
  // prevents spamming a target's inbox with fresh codes.
  @Public()
  @UseGuards(EmailOrIpThrottlerGuard)
  @Throttle({ default: { limit: 3, ttl: 15 * 60 * 1000 } })
  @Post('otp/request')
  requestOtp(@Body() dto: RequestOtpDto) {
    return this.auth.requestOtp(dto.email);
  }

  @Public() @Post('otp/verify')
  verifyOtp(@Body() dto: VerifyOtpDto) {
    return this.auth.verifyOtp(dto.email, dto.code);
  }

  // Max 3 requests per email per 15 minutes — prevents spamming a target's
  // inbox with fresh reset links/tokens.
  @Public()
  @UseGuards(EmailOrIpThrottlerGuard)
  @Throttle({ default: { limit: 3, ttl: 15 * 60 * 1000 } })
  @Post('forgot-password')
  forgot(@Body() dto: ForgotPasswordDto) {
    return this.auth.forgotPassword(dto.email);
  }

  // The token is a 32-byte random value (unguessable), so this is basic
  // per-IP abuse protection rather than brute-force defense.
  @Public()
  @UseGuards(EmailOrIpThrottlerGuard)
  @Throttle({ default: { limit: 10, ttl: 15 * 60 * 1000 } })
  @Post('reset-password')
  reset(@Body() dto: ResetPasswordDto) {
    return this.auth.resetPassword(dto.token, dto.newPassword);
  }

  @Public() @Post('resend-verification')
  resendVerification(@Body() body: { email: string }) {
    return this.auth.resendVerification(body.email);
  }

  @Public() @Post('verify-email')
  verifyEmail(@Body() dto: VerifyEmailDto) {
    return this.auth.verifyEmail(dto.token);
  }

  @Public() @Post('google')
  google(@Body() dto: GoogleLoginDto) {
    return this.auth.loginWithGoogle(dto.idToken);
  }

  @Public() @Post('apple')
  apple(@Body() dto: AppleLoginDto) {
    return this.auth.loginWithApple(dto.identityToken);
  }

  @Public() @Post('dev-login')
  devLogin(@Body() body: { email?: string }) {
    return this.auth.devLogin(body?.email ?? 'test@gtec.dev');
  }

  @Public() @Post('refresh')
  refresh(@Body() dto: RefreshDto) {
    return this.auth.refresh(dto.refreshToken);
  }

  @Public() @Post('logout')
  logout(@Body() dto: RefreshDto) {
    return this.auth.logout(dto.refreshToken);
  }
}
