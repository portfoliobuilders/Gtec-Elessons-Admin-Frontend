import { IsString, IsNotEmpty } from 'class-validator';

export class GoogleLoginDto {
  // Flutter signs in with Google on-device and sends the resulting ID token.
  @IsString()
  @IsNotEmpty()
  idToken: string;
}
