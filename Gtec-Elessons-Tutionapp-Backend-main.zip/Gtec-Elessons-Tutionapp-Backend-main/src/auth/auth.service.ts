import {
  Injectable,
  Logger,
  UnauthorizedException,
  ForbiddenException,
  ConflictException,
  BadRequestException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { OAuth2Client } from 'google-auth-library';
import { createHash, randomBytes, randomInt } from 'crypto';
import * as bcrypt from 'bcryptjs';
import appleSignin from 'apple-signin-auth';
import { PrismaService } from '../prisma/prisma.service';
import { User } from '@prisma/client';
import { MailService } from '../mail/mail.service';

@Injectable()
export class AuthService {
  private google = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
    private mail: MailService,
  ) {}

  // ---------- Google ----------
  async loginWithGoogle(idToken: string) {
    let payload;
    try {
      const ticket = await this.google.verifyIdToken({
        idToken,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      payload = ticket.getPayload();
    } catch (err) {
      // The client only ever sees a generic 401 — but google-auth-library's
      // Error.message is where the actual reason lives (e.g. "Wrong recipient,
      // payload audience != required audience", "Token used too late", "Wrong
      // number of segments in token"). Log it so a real failing login is
      // diagnosable server-side instead of collapsing into one opaque message.
      this.logger.warn(`Google token verification failed: ${this.formatError(err)}`);
      throw new UnauthorizedException('Invalid Google token');
    }
    if (!payload?.sub) throw new UnauthorizedException('Invalid Google token');

    const user = await this.prisma.user.upsert({
      where: { googleId: payload.sub },
      update: {
        name: payload.name ?? undefined,
        avatarUrl: payload.picture ?? undefined,
      },
      create: {
        googleId: payload.sub,
        email: payload.email ?? null,
        name: payload.name ?? null,
        avatarUrl: payload.picture ?? null,
        studentProfile: { create: {} },
      },
      include: { studentProfile: true },
    });
    if (user.status === 'SUSPENDED') throw new ForbiddenException('Account suspended');
    return this.session(user);
  }

  // ---------- Dev login ----------
  // Dev-login is always @Public() — no role is required to call it.
  // It finds an existing user by email (preserving whatever role they already
  // have) or creates a brand-new dev account. When creating, the role is
  // inferred from the email prefix so that admin@gtec.dev → SUPER_ADMIN,
  // teacher@gtec.dev → TEACHER, and everything else → STUDENT.
  async devLogin(email: string) {
    if (process.env.ALLOW_DEV_LOGIN !== 'true') {
      throw new UnauthorizedException('Dev login disabled');
    }

    // Try to find the existing user first — preserves their real role.
    const existing = await this.prisma.user.findUnique({
      where: { email },
      include: { studentProfile: true },
    });
    if (existing) {
      if (existing.status === 'SUSPENDED') throw new ForbiddenException('Account suspended');
      return this.session(existing);
    }

    // Brand-new dev account — infer role from email prefix.
    const prefix = email.split('@')[0].toLowerCase();
    const role =
      prefix === 'admin' || prefix === 'super_admin' || prefix === 'superadmin'
        ? 'SUPER_ADMIN' as const
        : prefix === 'teacher'
          ? 'TEACHER' as const
          : 'STUDENT' as const;

    const user = await this.prisma.user.create({
      data: {
        email,
        name: `Dev ${role.charAt(0) + role.slice(1).toLowerCase()}`,
        googleId: `dev-${email}`,
        role,
        ...(role === 'STUDENT'
          ? { studentProfile: { create: { region: 'IN', currency: 'INR', board: 'CBSE', onboarded: true } } }
          : {}),
      },
      include: { studentProfile: true },
    });
    return this.session(user);
  }

  // ---------- Email + password ----------
  async register(dto: { name: string; email: string; password: string; phone?: string }) {
    return this.createAccount(dto, 'STUDENT');
  }

  // Public self-service teacher signup — a dedicated endpoint that can only
  // ever hardcode role: TEACHER, so a client can never reach ADMIN/SUPER_ADMIN
  // through it (unlike a generic `role` field on the shared register call).
  async registerTeacher(dto: { name: string; email: string; password: string; phone?: string }) {
    return this.createAccount(dto, 'TEACHER');
  }

  private async createAccount(
    dto: { name: string; email: string; password: string; phone?: string },
    role: 'STUDENT' | 'TEACHER',
  ) {
    const existing = await this.prisma.user.findFirst({
      where: { OR: [{ email: dto.email }, ...(dto.phone ? [{ phone: dto.phone }] : [])] },
    });
    if (existing) throw new ConflictException('Email or phone already registered');

    const passwordHash = await bcrypt.hash(dto.password, 10);
    const user = await this.prisma.user.create({
      data: {
        name: dto.name,
        email: dto.email,
        phone: dto.phone ?? null,
        passwordHash,
        role,
        ...(role === 'STUDENT' ? { studentProfile: { create: {} } } : {}),
      },
      include: { studentProfile: true },
    });
    const verification = await this.sendVerificationEmail(user.id, dto.email);
    const session = await this.session(user);
    return { ...session, ...(verification.devVerifyToken ? { devVerifyToken: verification.devVerifyToken } : {}) };
  }

  async login(dto: { email: string; password: string }) {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email },
      include: { studentProfile: true },
    });
    if (!user || !user.passwordHash) throw new UnauthorizedException('Invalid credentials');
    const ok = await bcrypt.compare(dto.password, user.passwordHash);
    if (!ok) throw new UnauthorizedException('Invalid credentials');
    if (user.status === 'SUSPENDED') throw new ForbiddenException('Account suspended');
    return this.session(user);
  }

  // ---------- Email OTP (login) ----------
  // Resend/brute-force protection is split across two layers:
  //  - request: EmailOrIpThrottlerGuard + @Throttle on the controller route
  //    caps this at 3 requests per email per 15 minutes (429 once exceeded).
  //  - verify: attempts is counted per-OTP-row below; hitting 5 wrong
  //    guesses marks the row consumed so it can never succeed, even with
  //    the right code — the caller must request a fresh one.
  async requestOtp(email: string) {
    const code = String(randomInt(100000, 1000000));
    await this.prisma.emailOtp.create({
      data: { email, codeHash: this.hash(code), expiresAt: new Date(Date.now() + 5 * 60 * 1000) },
    });
    const delivered = await this.mail.sendMail({
      to: email,
      subject: 'Your G-TEC login code',
      html: `
        <p>Hello,</p>
        <p>Your G-TEC login code is:</p>
        <p style="font-size: 28px; font-weight: bold; letter-spacing: 6px;">${code}</p>
        <p>This code expires in 5 minutes. If you didn't request this, you can safely ignore this email.</p>
      `,
    });
    if (!delivered) {
      this.logger.warn(`OTP email failed to send to ${email}`);
    }
    const dev = process.env.ALLOW_DEV_LOGIN === 'true';
    return { sent: true, ...(dev ? { devOtp: code } : {}) };
  }

  async verifyOtp(email: string, code: string) {
    const otp = await this.prisma.emailOtp.findFirst({
      where: { email, consumed: false },
      orderBy: { createdAt: 'desc' },
    });
    if (!otp) throw new BadRequestException('No pending code — request a new one');
    if (otp.expiresAt < new Date()) throw new BadRequestException('Code expired');
    if (otp.attempts >= 5) {
      // 5 wrong guesses already recorded — invalidate the row outright (not
      // just "still over the cap") so it can never be consumed, even if the
      // correct code is supplied on this call.
      await this.prisma.emailOtp.update({ where: { id: otp.id }, data: { consumed: true } });
      throw new BadRequestException('Too many attempts — request a new code');
    }
    if (this.hash(code) !== otp.codeHash) {
      await this.prisma.emailOtp.update({ where: { id: otp.id }, data: { attempts: otp.attempts + 1 } });
      throw new BadRequestException('Incorrect code');
    }
    await this.prisma.emailOtp.update({ where: { id: otp.id }, data: { consumed: true } });

    const user = await this.prisma.user.upsert({
      where: { email },
      update: { emailVerified: true },
      create: { email, emailVerified: true, studentProfile: { create: {} } },
      include: { studentProfile: true },
    });
    return this.session(user);
  }

  // ---------- Password reset ----------
  async forgotPassword(email: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });
    // Always respond the same way so we don't reveal which emails exist.
    if (user) {
      const token = randomBytes(32).toString('hex');
      await this.prisma.passwordResetToken.create({
        data: { userId: user.id, tokenHash: this.hash(token), expiresAt: new Date(Date.now() + 60 * 60 * 1000) },
      });
      const baseUrl = (process.env.APP_BASE_URL ?? 'http://localhost:3000').replace(/\/+$/, '');
      const link = `${baseUrl}/reset-password?token=${token}`;
      const delivered = await this.mail.sendMail({
        to: email,
        subject: 'Reset your G-TEC password',
        html: `
          <p>Hello${user.name ? ` ${user.name}` : ''},</p>
          <p>Click the link below to reset your G-TEC password. This link expires in 1 hour and can only be used once.</p>
          <p><a href="${link}">${link}</a></p>
          <p>If you didn't request this, you can safely ignore this email.</p>
        `,
      });
      if (!delivered) {
        // Don't let delivery failure leak into the response (would reveal the
        // email exists) — just log it server-side for debugging.
        this.logger.warn(`Password reset email failed to send for user ${user.id}`);
      }
      const dev = process.env.ALLOW_DEV_LOGIN === 'true';
      return { sent: true, ...(dev ? { devResetToken: token } : {}) };
    }
    return { sent: true };
  }

  async resetPassword(token: string, newPassword: string) {
    const rec = await this.prisma.passwordResetToken.findUnique({
      where: { tokenHash: this.hash(token) },
    });
    if (!rec || rec.used || rec.expiresAt < new Date()) {
      throw new BadRequestException('Invalid or expired reset token');
    }
    const passwordHash = await bcrypt.hash(newPassword, 10);
    await this.prisma.$transaction([
      this.prisma.user.update({ where: { id: rec.userId }, data: { passwordHash } }),
      this.prisma.passwordResetToken.update({ where: { id: rec.id }, data: { used: true } }),
    ]);
    return { success: true };
  }

  // ---------- Email verification ----------
  // A separate, secondary verification path (token + link) alongside the
  // primary email-OTP flow above — the app itself verifies registration via
  // requestOtp/verifyOtp, not this. Kept isolated on purpose: this is only
  // for whoever still calls resend-verification/verify-email directly.
  // The link lands on a page main.ts serves itself (GET /verify-email) —
  // there's no separate web frontend project for this route to point at.
  private async sendVerificationEmail(userId: string, email: string) {
    const token = randomBytes(32).toString('hex');
    await this.prisma.emailVerificationToken.create({
      data: { userId, tokenHash: this.hash(token), expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) },
    });
    const baseUrl = (process.env.APP_BASE_URL ?? 'http://localhost:3000').replace(/\/+$/, '');
    const link = `${baseUrl}/verify-email?token=${token}`;
    const delivered = await this.mail.sendMail({
      to: email,
      subject: 'Verify your G-TEC email',
      html: `
        <p>Hello,</p>
        <p>Click the link below to verify your G-TEC email address. This link expires in 24 hours and can only be used once.</p>
        <p><a href="${link}">${link}</a></p>
        <p>If you didn't create a G-TEC account, you can safely ignore this email.</p>
      `,
    });
    if (!delivered) {
      this.logger.warn(`Verification email failed to send to ${email}`);
    }
    const dev = process.env.ALLOW_DEV_LOGIN === 'true';
    return { sent: true, ...(dev ? { devVerifyToken: token } : {}) };
  }

  async resendVerification(email: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });
    // Always respond the same way so we don't reveal which emails exist.
    if (user && !user.emailVerified) {
      return this.sendVerificationEmail(user.id, email);
    }
    return { sent: true };
  }

  async verifyEmail(token: string) {
    const rec = await this.prisma.emailVerificationToken.findUnique({
      where: { tokenHash: this.hash(token) },
    });
    if (!rec || rec.used || rec.expiresAt < new Date()) {
      throw new BadRequestException('Invalid or expired verification link');
    }
    await this.prisma.$transaction([
      this.prisma.user.update({ where: { id: rec.userId }, data: { emailVerified: true } }),
      this.prisma.emailVerificationToken.update({ where: { id: rec.id }, data: { used: true } }),
    ]);
    return { success: true };
  }

  // ---------- Apple ----------
  async loginWithApple(identityToken: string) {
    if (!process.env.APPLE_CLIENT_ID) {
      throw new UnauthorizedException('Apple sign-in not configured');
    }
    let sub: string;
    let email: string | undefined;
    try {
      const data = await appleSignin.verifyIdToken(identityToken, {
        audience: process.env.APPLE_CLIENT_ID,
        ignoreExpiration: false,
      });
      sub = data.sub;
      email = data.email;
    } catch {
      throw new UnauthorizedException('Invalid Apple token');
    }
    const user = await this.prisma.user.upsert({
      where: { appleId: sub },
      update: {},
      create: { appleId: sub, email: email ?? null, studentProfile: { create: {} } },
      include: { studentProfile: true },
    });
    return this.session(user);
  }

  // ---------- Tokens ----------
  async refresh(refreshToken: string) {
    const tokenHash = this.hash(refreshToken);
    const stored = await this.prisma.refreshToken.findUnique({
      where: { tokenHash },
      include: { user: true },
    });
    if (!stored || stored.revoked || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid refresh token');
    }
    await this.prisma.refreshToken.update({ where: { id: stored.id }, data: { revoked: true } });
    return this.issueTokens(stored.user);
  }

  async logout(refreshToken: string) {
    const tokenHash = this.hash(refreshToken);
    await this.prisma.refreshToken
      .updateMany({ where: { tokenHash }, data: { revoked: true } })
      .catch(() => undefined);
    return { success: true };
  }

  // Build the standard { tokens, user } response.
  private async session(user: any) {
    const tokens = await this.issueTokens(user);
    return {
      ...tokens,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        avatarUrl: user.avatarUrl,
        role: user.role,
        onboarded: user.studentProfile?.onboarded ?? false,
      },
    };
  }

  private async issueTokens(user: User) {
    const accessToken = await this.jwt.signAsync(
      { sub: user.id, role: user.role },
      {
        secret: process.env.JWT_ACCESS_SECRET,
        expiresIn: process.env.JWT_ACCESS_TTL ?? '15m',
      },
    );

    const refreshToken = randomBytes(48).toString('hex');
    const ttlDays = 30;
    await this.prisma.refreshToken.create({
      data: {
        userId: user.id,
        tokenHash: this.hash(refreshToken),
        expiresAt: new Date(Date.now() + ttlDays * 24 * 60 * 60 * 1000),
      },
    });

    return { accessToken, refreshToken };
  }

  private hash(token: string) {
    return createHash('sha256').update(token).digest('hex');
  }

  // google-auth-library throws real Error instances (message carries the
  // actual reason, e.g. audience/expiry mismatches) — but format defensively
  // in case a lower-level (e.g. network) failure surfaces a plain object
  // instead, same reasoning as PaymentsService.formatError() for Razorpay.
  private formatError(err: unknown): string {
    if (err instanceof Error) return err.stack ?? err.message;
    try {
      return JSON.stringify(err);
    } catch {
      return String(err);
    }
  }
}
