import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { BatchesService } from './batches.service';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
@Controller('admin')
export class BatchesController {
  constructor(private svc: BatchesService) {}

  @Get('batches')
  list(@Query('subjectId') subjectId?: string, @Query('teacherId') teacherId?: string) {
    return this.svc.list(subjectId, teacherId);
  }

  @Post('subjects/:subjectId/batches')
  createSubjectBatch(
    @Param('subjectId') subjectId: string,
    @Body() d: { name: string; gradeId?: string; teacherId?: string; schedule?: string },
  ) {
    return this.svc.create({ ...d, subjectId });
  }

  @Patch('batches/:id')
  update(@Param('id') id: string, @Body() d: any) {
    return this.svc.update(id, d);
  }

  @Post('batches/:batchId/students/:studentId')
  addStudentNested(@Param('batchId') batchId: string, @Param('studentId') studentId: string) {
    return this.svc.addStudent(batchId, studentId);
  }

  @Post('batches/:id/students')
  addStudent(@Param('id') id: string, @Body() body: { studentId: string }) {
    return this.svc.addStudent(id, body.studentId);
  }

  @Delete('batches/:id/students/:studentId')
  removeStudent(@Param('id') id: string, @Param('studentId') studentId: string) {
    return this.svc.removeStudent(id, studentId);
  }
}
