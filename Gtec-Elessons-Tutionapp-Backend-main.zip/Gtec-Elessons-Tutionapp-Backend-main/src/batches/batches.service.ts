import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class BatchesService {
  constructor(private prisma: PrismaService) {}

  list(subjectId?: string, teacherId?: string) {
    return this.prisma.batch.findMany({
      where: { ...(subjectId ? { subjectId } : {}), ...(teacherId ? { teacherId } : {}) },
      orderBy: { createdAt: 'asc' },
      include: {
        grade: { select: { name: true } },
        subject: { select: { name: true } },
        teacher: { select: { name: true } },
        _count: { select: { enrollments: true } },
      },
    });
  }

  async create(d: { name: string; gradeId?: string; subjectId: string; teacherId?: string; schedule?: string }) {
    let gradeId = d.gradeId;
    if (!gradeId && d.subjectId) {
      const subject = await this.prisma.subject.findUnique({ where: { id: d.subjectId }, select: { gradeId: true } });
      if (!subject) throw new NotFoundException('Subject not found');
      gradeId = subject.gradeId;
    }
    if (!gradeId || !d.subjectId) {
      throw new BadRequestException('gradeId and subjectId are required to create a batch');
    }
    return this.prisma.batch.create({
      data: {
        name: d.name,
        gradeId,
        subjectId: d.subjectId,
        teacherId: d.teacherId ?? null,
        schedule: d.schedule ?? null,
      },
    });
  }

  update(id: string, d: any) {
    return this.prisma.batch.update({ where: { id }, data: d });
  }

  async addStudent(batchId: string, studentId: string) {
    const batch = await this.prisma.batch.findUnique({ where: { id: batchId } });
    if (!batch) throw new NotFoundException('Batch not found');
    try {
      return await this.prisma.batchEnrollment.create({ data: { batchId, studentId } });
    } catch {
      throw new BadRequestException('Student already in this batch');
    }
  }

  async removeStudent(batchId: string, studentId: string) {
    await this.prisma.batchEnrollment.deleteMany({ where: { batchId, studentId } });
    return { batchId, studentId, removed: true };
  }
}
