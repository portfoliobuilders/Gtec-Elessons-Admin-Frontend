import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

// Flat key/value config store (GST%, default currency, ...). Single source of
// truth for anything that used to be a process.env fallback — every reader
// (pricing, payments, ...) goes through here so they can't drift apart.
@Injectable()
export class SettingsService {
  constructor(private prisma: PrismaService) {}

  list() {
    return this.prisma.setting.findMany({ orderBy: { key: 'asc' } });
  }

  async get(key: string): Promise<string | null> {
    const row = await this.prisma.setting.findUnique({ where: { key } });
    return row?.value ?? null;
  }

  upsert(key: string, value: string) {
    return this.prisma.setting.upsert({
      where: { key },
      update: { value },
      create: { key, value },
    });
  }

  async gstPercent(): Promise<number> {
    const value = await this.get('gst_percent');
    return Number(value ?? '18');
  }

  async defaultCurrency(): Promise<string> {
    const value = await this.get('default_currency');
    return value ?? 'INR';
  }
}
