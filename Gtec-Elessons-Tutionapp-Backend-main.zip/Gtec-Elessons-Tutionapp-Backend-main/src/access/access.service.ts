import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AccessService {
  constructor(private prisma: PrismaService) {}

  /**
   * Core access rule. A user may access a lesson if:
   *   - the lesson is a free preview, OR
   *   - they hold an ACTIVE, non-expired enrollment whose scope covers it,
   *     resolved by walking lesson -> chapter -> subject -> grade:
   *       FULL_CLASS enrollment matching the grade, OR
   *       SUBJECT    enrollment matching the subject, OR
   *       MODULE     enrollment matching the chapter.
   * Reuse this everywhere access is gated: playback, downloads, assessments.
   */
  async canAccessLesson(userId: string, lessonId: string): Promise<boolean> {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      select: {
        isFreePreview: true,
        isPublished: true,
        chapterId: true,
        chapter: { select: { subjectId: true, subject: { select: { gradeId: true } } } },
      },
    });
    if (!lesson || !lesson.isPublished) return false;
    if (lesson.isFreePreview) return true;

    const chapterId = lesson.chapterId;
    const subjectId = lesson.chapter.subjectId;
    const gradeId = lesson.chapter.subject.gradeId;

    const match = await this.prisma.enrollment.findFirst({
      where: {
        userId,
        status: 'ACTIVE',
        OR: [
          { scopeType: 'FULL_CLASS', gradeId },
          { scopeType: 'SUBJECT', subjectId },
          { scopeType: 'MODULE', chapterId },
        ],
        AND: [{ OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] }],
      },
      select: { id: true },
    });

    return !!match;
  }

  /** Returns the set of gradeIds/subjectIds/chapterIds the user currently has access to. */
  async getAccessScopes(userId: string) {
    const enrollments = await this.prisma.enrollment.findMany({
      where: {
        userId,
        status: 'ACTIVE',
        OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
      },
      select: { scopeType: true, gradeId: true, subjectId: true, chapterId: true },
    });
    return {
      grades: enrollments.filter((e) => e.gradeId).map((e) => e.gradeId!),
      subjects: enrollments.filter((e) => e.subjectId).map((e) => e.subjectId!),
      chapters: enrollments.filter((e) => e.chapterId).map((e) => e.chapterId!),
    };
  }

  /**
   * Generic scope access check used by assessments (and future modules).
   * Grants if the user's enrollments cover the given grade/subject/chapter,
   * walking upward (grade covers its subjects; subject covers its chapters).
   */
  async canAccessScope(
    userId: string,
    scope: { gradeId?: string | null; subjectId?: string | null; chapterId?: string | null },
  ): Promise<boolean> {
    const scopes = await this.getAccessScopes(userId);

    if (scope.gradeId && scopes.grades.includes(scope.gradeId)) return true;

    if (scope.subjectId) {
      if (scopes.subjects.includes(scope.subjectId)) return true;
      const subj = await this.prisma.subject.findUnique({
        where: { id: scope.subjectId },
        select: { gradeId: true },
      });
      if (subj && scopes.grades.includes(subj.gradeId)) return true;
    }

    if (scope.chapterId) {
      if (scopes.chapters.includes(scope.chapterId)) return true;
      const ch = await this.prisma.chapter.findUnique({
        where: { id: scope.chapterId },
        select: { subjectId: true, subject: { select: { gradeId: true } } },
      });
      if (ch) {
        if (scopes.subjects.includes(ch.subjectId)) return true;
        if (scopes.grades.includes(ch.subject.gradeId)) return true;
      }
    }

    return false;
  }

  /**
   * Returns true if the user holds a LIVE_AND_RECORDED enrollment covering the
   * given scope. Used to gate live class join links and schedules.
   */
  async hasLiveAccess(
    userId: string,
    scope: { gradeId?: string; subjectId?: string; chapterId?: string },
  ): Promise<boolean> {
    const conditions: any[] = [];
    if (scope.gradeId) conditions.push({ scopeType: 'FULL_CLASS', gradeId: scope.gradeId });
    if (scope.subjectId) conditions.push({ scopeType: 'SUBJECT', subjectId: scope.subjectId });
    if (scope.chapterId) conditions.push({ scopeType: 'MODULE', chapterId: scope.chapterId });
    if (!conditions.length) return false;

    const match = await this.prisma.enrollment.findFirst({
      where: {
        userId,
        format: 'LIVE_AND_RECORDED',
        status: 'ACTIVE',
        OR: conditions,
        AND: [{ OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] }],
      },
      select: { id: true },
    });
    return !!match;
  }
}
