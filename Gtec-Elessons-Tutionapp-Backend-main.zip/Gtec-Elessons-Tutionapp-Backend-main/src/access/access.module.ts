import { Global, Module } from '@nestjs/common';
import { AccessService } from './access.service';
import { LessonAccessGuard } from './access.guard';

@Global()
@Module({
  providers: [AccessService, LessonAccessGuard],
  exports: [AccessService, LessonAccessGuard],
})
export class AccessModule {}
