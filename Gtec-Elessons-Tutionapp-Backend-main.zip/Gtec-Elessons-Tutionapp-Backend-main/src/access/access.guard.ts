import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';
import { AccessService } from './access.service';

// Guards routes that include a :lessonId param (e.g. playback).
@Injectable()
export class LessonAccessGuard implements CanActivate {
  constructor(private access: AccessService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest();
    const userId = req.user?.id;
    const lessonId = req.params?.lessonId ?? req.params?.id;
    if (!userId || !lessonId) throw new ForbiddenException('Access denied');

    const ok = await this.access.canAccessLesson(userId, lessonId);
    if (!ok) throw new ForbiddenException('You have not purchased this lesson');
    return true;
  }
}
