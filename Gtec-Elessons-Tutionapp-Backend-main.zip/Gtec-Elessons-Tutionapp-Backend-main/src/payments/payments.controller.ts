import {
  Body,
  Controller,
  Post,
  Req,
  UseGuards,
} from '@nestjs/common';
import { Request } from 'express';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Public } from '../common/decorators/public.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { PaymentsService } from './payments.service';
import { CheckoutDto } from './dto/checkout.dto';

@Controller()
export class PaymentsController {
  constructor(private payments: PaymentsService) {}

  // Student starts checkout from their cart. Returns a Razorpay order ID and
  // key that the Flutter frontend uses to open the Razorpay payment sheet.
  // Optional billing details are saved for next-time auto-fill and
  // snapshotted onto the order.
  @UseGuards(JwtAuthGuard)
  @Post('checkout')
  checkout(@CurrentUser() user: AuthUser, @Body() dto: CheckoutDto) {
    return this.payments.createCheckout(user.id, dto);
  }

  // Admin/server-side: creates a Razorpay order for a specific subject
  // on behalf of a student (by ID or email). Used for manual enrollment flows.
  // ADMIN/SUPER_ADMIN only — this acts on behalf of an arbitrary student, so
  // it must not be reachable without auth.
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN')
  @Post('razorpay/subject-order')
  createSubjectOrder(
    @Body()
    body: {
      studentId?: string;
      studentEmail?: string;
      subjectId: string;
      currency?: string;
    },
  ) {
    return this.payments.createSubjectOrder(body);
  }

  // Razorpay webhook — must be @Public() so JWT guard is bypassed.
  // Razorpay sends the raw body with an X-Razorpay-Signature header; we verify it here.
  // Register this URL in the Razorpay Dashboard → Webhooks.
  @Public()
  @Post('razorpay/webhook')
  razorpayWebhook(@Req() req: Request) {
    return this.payments.handleRazorpayWebhook(req as any);
  }
}
