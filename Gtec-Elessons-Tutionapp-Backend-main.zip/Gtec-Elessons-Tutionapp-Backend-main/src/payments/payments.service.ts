import {
  Injectable,
  BadRequestException,
  NotFoundException,
  InternalServerErrorException,
  Logger,
  RawBodyRequest,
} from '@nestjs/common';
import { randomInt } from 'crypto';
import { Request } from 'express';
import { PrismaService } from '../prisma/prisma.service';
import { PricingService } from '../pricing/pricing.service';
import { RazorpayService } from './razorpay.service';
import { NotificationsService } from '../notifications/notifications.service';
import { SettingsService } from '../settings/settings.service';
import { CheckoutDto } from './dto/checkout.dto';
import { roundMoney, toGatewayMinorUnits } from '../common/money/money.util';

@Injectable()
export class PaymentsService {
  private readonly logger = new Logger(PaymentsService.name);

  constructor(
    private prisma: PrismaService,
    private pricing: PricingService,
    private razorpay: RazorpayService,
    private notifications: NotificationsService,
    private settings: SettingsService,
  ) {}

  // Create a Razorpay order from the user's cart.
  async createCheckout(userId: string, details?: CheckoutDto) {
    // Persist checkout details for next-time auto-fill (name/phone on user,
    // address on the student profile) before building the order.
    if (details) { 
      const userFields: any = {};
      if (details.name !== undefined) userFields.name = details.name;
      if (details.phone !== undefined) {
        const existingPhoneUser = await this.prisma.user.findFirst({
          where: { phone: details.phone, id: { not: userId } },
          select: { id: true },
        });
        if (existingPhoneUser) {
          this.logger.warn(
            `Phone number ${details.phone} is already registered to user ${existingPhoneUser.id}. Skipping user profile phone update.`,
          );
        } else {
          userFields.phone = details.phone;
        }
      }
      if (Object.keys(userFields).length) {
        await this.prisma.user.update({ where: { id: userId }, data: userFields });
      }

      const profileFields: any = {};
      for (const f of ['addressLine', 'city', 'state', 'pincode'] as const) {
        if (details[f] !== undefined) profileFields[f] = details[f];
      }
      if (Object.keys(profileFields).length) {
        await this.prisma.studentProfile.upsert({
          where: { userId },
          update: profileFields,
          create: { userId, ...profileFields },
        });
      }
    }

    const quote = await this.pricing.quoteForCart(userId, details?.currency);
    if (quote.lines.length === 0) throw new BadRequestException('Cart is empty');

    // Recompute server-side, then persist a PENDING order with its items.
    const orderNumber = await this.generateOrderNumber();
    const order = await this.prisma.order.create({
      data: {
        orderNumber,
        userId,
        region: quote.region,
        currency: quote.currency,
        subtotalCents: quote.subtotalCents,
        discountCents: quote.discountCents,
        taxCents: quote.taxCents,
        totalCents: quote.totalCents,
        status: 'PENDING',
        billingName: details?.name ?? null,
        billingPhone: details?.phone ?? null,
        billingAddress: details?.addressLine ?? null,
        billingCity: details?.city ?? null,
        billingState: details?.state ?? null,
        billingPincode: details?.pincode ?? null,
        items: {
          create: quote.lines.map((l) => ({
            productId: l.productId,
            titleSnapshot: l.title,
            priceCents: l.priceCents,
          })),
        },
      },
    });

    return this.createRazorpayOrder(order.id, quote.totalAmount, quote.currency, {
      userId,
      orderNumber: order.orderNumber,
      source: 'cart',
    });
  }

  async createSubjectOrder(dto: {
    studentId?: string;
    studentEmail?: string;
    subjectId: string;
    currency?: string;
  }) {
    if (!dto.studentId && !dto.studentEmail) {
      throw new BadRequestException('studentId or studentEmail is required');
    }

    const student = await this.prisma.user.findFirst({
      where: {
        ...(dto.studentId ? { id: dto.studentId } : { email: dto.studentEmail }),
        role: 'STUDENT',
      },
      include: { studentProfile: true },
    });
    if (!student) throw new NotFoundException('Student not found');

    const subject = await this.prisma.subject.findUnique({
      where: { id: dto.subjectId },
      select: { id: true, name: true },
    });
    if (!subject) throw new NotFoundException('Subject not found');

    const product = await this.prisma.product.findFirst({
      where: { type: 'SUBJECT', subjectId: subject.id, isActive: true },
      include: { prices: true },
      orderBy: { accessDays: 'desc' },
    });
    if (!product) throw new NotFoundException('Active subject product not found');

    const currency = (
      dto.currency ||
      student.studentProfile?.currency ||
      (await this.settings.defaultCurrency())
    ).toUpperCase();
    const region =
      student.studentProfile?.region ?? (currency === 'INR' ? 'IN' : 'INTL');
    const price =
      product.prices.find((p) => p.region === region && p.currency === currency) ??
      product.prices.find((p) => p.region === 'IN' && p.currency === 'INR');
    if (!price) throw new NotFoundException('Subject price not found');

    // Business-currency decimal amount (e.g. 800 for AED 800) — never a
    // payment-gateway minor unit. See src/common/money.
    const subtotalAmount = Number(price.amount);
    const discountAmount = 0;
    const taxAmount =
      currency === 'INR'
        ? roundMoney((subtotalAmount * (await this.settings.gstPercent())) / 100, currency)
        : 0;
    const totalAmount = roundMoney(subtotalAmount - discountAmount + taxAmount, currency);

    // Legacy "amount × 100" bookkeeping — Order/OrderItem's schema is
    // untouched by Phase 5B (see report); this is not the gateway amount.
    const subtotalCents = Math.round(subtotalAmount * 100);
    const discountCents = 0;
    const taxCents = Math.round(taxAmount * 100);
    const totalCents = subtotalCents - discountCents + taxCents;
    const orderNumber = await this.generateOrderNumber();

    const order = await this.prisma.order.create({
      data: {
        orderNumber,
        userId: student.id,
        region,
        currency,
        subtotalCents,
        discountCents,
        taxCents,
        totalCents,
        status: 'PENDING',
        items: {
          create: {
            productId: product.id,
            titleSnapshot: product.title,
            priceCents: subtotalCents,
          },
        },
      },
    });

    return this.createRazorpayOrder(order.id, totalAmount, currency, {
      userId: student.id,
      subjectId: subject.id,
      orderNumber,
      source: 'subject',
    });
  }

  // Called once Razorpay confirms payment — from payment.captured or
  // order.paid, whichever arrives (possibly both, for the same payment).
  // Idempotent: the status=PENDING guard inside the transaction below is an
  // atomic compare-and-set, so if both events (or a retry) race each other
  // in, only the first one to commit performs fulfillment; the other is a
  // clean no-op. No duplicate Enrollments, no duplicate cart-clear/notify.
  async fulfillOrder(orderId: string, razorpayPaymentId?: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { items: { include: { product: true } } },
    });
    if (!order) {
      this.logger.error(`[Fulfillment] orderId=${orderId} not found — cannot fulfill`);
      return;
    }
    if (order.status !== 'PENDING') {
      this.logger.log(
        `[Fulfillment] orderId=${order.id} status=${order.status} (not PENDING) — idempotent no-op`,
      );
      return;
    }

    const now = new Date();

    const fulfilled = await this.prisma.$transaction(async (tx) => {
      // Atomic claim: only proceed if still PENDING. Guards against
      // payment.captured and order.paid (or a webhook retry) both reaching
      // here for the same order.
      const claim = await tx.order.updateMany({
        where: { id: order.id, status: 'PENDING' },
        data: { status: 'PAID', razorpayPaymentId: razorpayPaymentId ?? null },
      });
      if (claim.count === 0) return false;

      this.logger.log(`[Fulfillment] orderId=${order.id} status=PENDING -> PAID`);

      for (const item of order.items) {
        const p = item.product;
        const expiresAt = new Date(now.getTime() + p.accessDays * 24 * 60 * 60 * 1000);
        await tx.enrollment.create({
          data: {
            userId: order.userId,
            productId: p.id,
            scopeType: p.type,
            format: p.format,
            gradeId: p.gradeId,
            subjectId: p.subjectId,
            chapterId: p.chapterId,
            status: 'ACTIVE',
            startsAt: now,
            expiresAt,
            orderItemId: item.id,
          },
        });
        this.logger.log(
          `[Enrollment] orderItemId=${item.id} productId=${p.id} userId=${order.userId} scopeType=${p.type}`,
        );
      }

      // Empty the cart now that it's purchased.
      const cart = await tx.cart.findUnique({ where: { userId: order.userId } });
      if (cart) {
        await tx.cartItem.deleteMany({ where: { cartId: cart.id } });
        this.logger.log(`[Cart] cleared for userId=${order.userId}`);
      }

      return true;
    });

    if (!fulfilled) {
      this.logger.log(
        `[Fulfillment] orderId=${order.id} already fulfilled by a concurrent request — skipping duplicate notification`,
      );
      return;
    }

    await this.notifications.pushFromTemplate(order.userId, 'PAYMENT_SUCCESS', {
      orderNumber: order.orderNumber,
    });
  }

  // Admin-triggered refund: marks the order REFUNDED and revokes enrollments.
  // Idempotent-safe: only a PAID order can be refunded.
  // Actual Razorpay refund must be initiated from the Razorpay dashboard or
  // via a separate admin action using the razorpayPaymentId stored on the order.
  async refundOrder(orderId: string, reason?: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true },
    });
    if (!order) throw new NotFoundException('Order not found');
    if (order.status !== 'PAID') {
      throw new BadRequestException(
        `Only a PAID order can be refunded (current status: ${order.status})`,
      );
    }

    // Trigger Razorpay refund if a payment ID is recorded on the order.
    if (order.razorpayPaymentId) {
      try {
        await this.razorpay.client.payments.refund(order.razorpayPaymentId, {
          speed: 'normal',
          notes: { reason: reason ?? 'requested_by_customer' },
        });
        this.logger.log(
          `Razorpay refund initiated for payment ${order.razorpayPaymentId}`,
        );
      } catch (err) {
        const detail = this.formatError(err);
        this.logger.error(`Razorpay refund failed for order ${orderId}: ${detail}`);
        throw new BadRequestException(`Razorpay refund failed: ${detail}`);
      }
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.order.update({ where: { id: order.id }, data: { status: 'REFUNDED' } });
      const orderItemIds = order.items.map((i) => i.id);
      await tx.enrollment.updateMany({
        where: { orderItemId: { in: orderItemIds }, status: 'ACTIVE' },
        data: { status: 'CANCELLED' },
      });
    });

    await this.notifications.pushFromTemplate(order.userId, 'PAYMENT_REFUND', {
      orderNumber: order.orderNumber,
      reasonSuffix: reason ? `: ${reason}` : '.',
    });

    return this.prisma.order.findUnique({ where: { id: order.id }, include: { items: true } });
  }

  // Handles incoming Razorpay webhook events. Verifies signature, then
  // resolves + fulfills the associated order for payment.captured and
  // order.paid (Razorpay may send either or both for the same successful
  // payment; fulfillOrder() is idempotent so this never double-fulfills).
  async handleRazorpayWebhook(req: RawBodyRequest<Request>) {
    const sig = req.headers['x-razorpay-signature'] as string;
    const rawBody = req.rawBody as Buffer;

    if (!this.razorpay.verifyWebhookSignature(rawBody.toString(), sig)) {
      this.logger.error('Razorpay webhook signature verification failed');
      throw new BadRequestException('Webhook signature verification failed');
    }

    const event = JSON.parse(rawBody.toString());
    const payment = event.payload?.payment?.entity;
    const rzpOrderEntity = event.payload?.order?.entity;

    this.logger.log(
      `[Razorpay Webhook] event=${event.event} paymentId=${payment?.id ?? '-'} razorpayOrderId=${payment?.order_id ?? rzpOrderEntity?.id ?? '-'}`,
    );

    if (event.event !== 'payment.captured' && event.event !== 'order.paid') {
      return { received: true };
    }

    if (!payment) {
      this.logger.warn(`[Razorpay Webhook] ${event.event} received without a payment entity — nothing to fulfill`);
      return { received: true };
    }
    if (payment.status && payment.status !== 'captured') {
      this.logger.warn(
        `[Razorpay Webhook] ${event.event} paymentId=${payment.id} status=${payment.status} (not captured) — skipping`,
      );
      return { received: true };
    }

    // Primary lookup: the Razorpay order id is set on our Order row at
    // checkout time (see createRazorpayOrder below) and is always present on
    // a payment made against an order — unlike notes, it isn't dependent on
    // the client re-passing anything at Checkout time.
    const razorpayOrderId: string | undefined = payment.order_id ?? rzpOrderEntity?.id;
    const notesOrderId: string | undefined = payment.notes?.internalOrderId;

    let order = razorpayOrderId
      ? await this.prisma.order.findUnique({ where: { razorpayOrderId } })
      : null;
    let resolvedVia: 'razorpayOrderId' | 'notes' | 'none' = order ? 'razorpayOrderId' : 'none';

    // Fallback only: notes are client/gateway-config dependent and not
    // guaranteed to be populated on the payment entity.
    if (!order && notesOrderId) {
      order = await this.prisma.order.findUnique({ where: { id: notesOrderId } });
      resolvedVia = order ? 'notes' : 'none';
    }

    this.logger.log(
      `[Order Resolution] razorpayOrderId=${razorpayOrderId ?? '-'} internalOrderId=${notesOrderId ?? '-'} resolvedVia=${resolvedVia} orderStatus=${order?.status ?? 'NOT_FOUND'}`,
    );

    if (!order) {
      this.logger.error(
        `[Razorpay Webhook] Could not resolve internal Order for event=${event.event} paymentId=${payment.id} razorpayOrderId=${razorpayOrderId ?? '-'} internalOrderId(notes)=${notesOrderId ?? '-'}. Fulfillment NOT performed.`,
      );
      // Non-2xx so Razorpay retries (bounded, with backoff) rather than the
      // payment being silently acknowledged as handled when it wasn't. Safe
      // to retry: fulfillOrder() hasn't run, so there's nothing to duplicate.
      throw new InternalServerErrorException(
        'Order not found for Razorpay payment/order id — will retry',
      );
    }

    await this.fulfillOrder(order.id, payment.id);
    return { received: true };
  }

  // The payment-provider boundary (Phase 5B report §7-8): the ONLY place in
  // the app that converts a business-currency decimal amount (e.g. 12000 for
  // ₹12,000, 65 for KWD 65) into the smallest-unit integer Razorpay expects
  // (paise, fils, ...). Callers always pass the plain business amount —
  // resolved server-side from Product/ProductPrice, never from client input
  // (see PaymentsService.createCheckout / createSubjectOrder).
  private async createRazorpayOrder(
    orderId: string,
    businessAmount: number,
    currency: string,
    metadata: Record<string, string>,
  ) {
    const gatewayAmount = toGatewayMinorUnits(businessAmount, currency);
    const keyId = process.env.RAZORPAY_KEY_ID ?? '';
    const keyPrefix = keyId.substring(0, keyId.indexOf('_') + 1);
    const keyLast4 = keyId.substring(Math.max(0, keyId.length - 4));
    this.logger.log(
      `[${new Date().toISOString()}] [Razorpay] Creating order with key: ${keyPrefix}...${keyLast4} | internalOrderId=${orderId} businessAmount=${businessAmount} ${currency} gatewayAmount=${gatewayAmount}`,
    );

    let rzpOrder: any;
    try {
      rzpOrder = await this.razorpay.client.orders.create({
        amount: gatewayAmount, // smallest-unit integer for `currency` — see src/common/money
        currency: currency.toUpperCase(),
        receipt: orderId,
        notes: { ...metadata, internalOrderId: orderId },
      });
    } catch (err) {
      this.logger.error(
        `[Razorpay] Order creation failed for internalOrder ${orderId}: ${this.formatError(err)}`,
      );
      throw new BadRequestException('Could not start payment. Please try again.');
    }

    this.logger.log(
      `[Razorpay] Order created: rzpOrderId=${rzpOrder.id} amount=${rzpOrder.amount} currency=${rzpOrder.currency}`,
    );

    // Store the Razorpay order ID on our internal order so the webhook can look it up.
    await this.prisma.order.update({
      where: { id: orderId },
      data: { razorpayOrderId: rzpOrder.id },
    });

    return {
      razorpayOrderId: rzpOrder.id,
      razorpayKeyId: process.env.RAZORPAY_KEY_ID,
      internalOrderId: orderId,
      orderNumber: metadata.orderNumber,
      amount: rzpOrder.amount,
      currency: rzpOrder.currency,
      description:
        metadata.source === 'cart' ? `Order ${metadata.orderNumber}` : 'Subject enrollment',
    };
  }

  // Razorpay SDK errors are plain objects (e.g. { statusCode, error: {...} }),
  // not Error instances — template-literal-interpolating them (`${err}`) just
  // prints "[object Object]". This serializes either shape into something
  // actually readable in the logs.
  private formatError(err: unknown): string {
    if (err instanceof Error) return err.stack ?? err.message;
    try {
      return JSON.stringify(err);
    } catch {
      return String(err);
    }
  }

  private async generateOrderNumber(): Promise<string> {
    const year = new Date().getFullYear();
    for (let i = 0; i < 5; i++) {
      const candidate = `GT-${year}-${randomInt(10000, 99999)}`;
      const existing = await this.prisma.order.findUnique({
        where: { orderNumber: candidate },
        select: { id: true },
      });
      if (!existing) return candidate;
    }
    // Extremely unlikely fallback
    return `GT-${year}-${Date.now()}`;
  }
}
