import { Injectable, Logger } from '@nestjs/common';
import Razorpay from 'razorpay';
import * as crypto from 'crypto';

@Injectable()
export class RazorpayService {
  private readonly logger = new Logger(RazorpayService.name);
  public readonly client: Razorpay;

  constructor() {
    const keyId = process.env.RAZORPAY_KEY_ID ?? '';
    const keySecret = process.env.RAZORPAY_KEY_SECRET ?? '';
    if (!keyId || !keySecret) {
      this.logger.warn(
        'RAZORPAY_KEY_ID or RAZORPAY_KEY_SECRET is not set — payment calls will fail.',
      );
    }
    // Log Razorpay key identity at startup
    const keyPrefix = keyId.substring(0, keyId.indexOf('_') + 1);
    const keyLast4 = keyId.substring(Math.max(0, keyId.length - 4));
    this.logger.log(
      `[${new Date().toISOString()}] RazorpayService initialized with key: ${keyPrefix}...${keyLast4}`,
    );
    this.client = new Razorpay({ key_id: keyId, key_secret: keySecret });
  }

  /**
   * Verify Razorpay webhook signature.
   * https://razorpay.com/docs/webhooks/validate-test/
   */
  verifyWebhookSignature(body: string, signature: string): boolean {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET ?? '';
    const expected = crypto
      .createHmac('sha256', secret)
      .update(body)
      .digest('hex');
    return expected === signature;
  }
}
