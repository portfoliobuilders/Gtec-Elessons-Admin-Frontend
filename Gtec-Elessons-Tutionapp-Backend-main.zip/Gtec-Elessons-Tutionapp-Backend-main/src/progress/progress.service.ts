import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AccessService } from '../access/access.service';

@Injectable()
export class ProgressService {
  constructor(
    private prisma: PrismaService,
    private access: AccessService,
  ) {}

  // Upsert progress for one lesson (access already enforced by the guard).
  async update(userId: string, lessonId: string, watchedSeconds: number, completed?: boolean) {
    return this.prisma.lessonProgress.upsert({
      where: { userId_lessonId: { userId, lessonId } },
      update: {
        watchedSeconds,
        ...(completed !== undefined ? { completed } : {}),
        lastWatchedAt: new Date(),
      },
      create: {
        userId,
        lessonId,
        watchedSeconds,
        completed: completed ?? false,
      },
    });
  }

  // Resolve which subjects the user can learn, and the lessons accessible within each.
  private async accessibleSubjectsWithLessons(userId: string) {
    const scopes = await this.access.getAccessScopes(userId);

    // Subjects reachable via a full-grade or subject-level enrollment (whole subject),
    // plus subjects reached only via a chapter (module) enrollment (partial).
    // Ordered by curriculum order (Grade.order, then Subject.order) — same
    // ordering CatalogService.listSubjects() uses — so the response is already
    // grouped by grade without the client needing to sort.
    const subjects = await this.prisma.subject.findMany({
      where: {
        OR: [
          { id: { in: scopes.subjects } },
          { gradeId: { in: scopes.grades } },
          { chapters: { some: { id: { in: scopes.chapters } } } },
        ],
      },
      orderBy: [{ grade: { order: 'asc' } }, { order: 'asc' }],
      include: {
        grade: { select: { id: true, name: true, board: true, order: true } },
        chapters: {
          include: {
            lessons: { where: { isPublished: true }, select: { id: true } },
          },
        },
      },
    });

    return subjects.map((subject) => {
      const fullSubject =
        scopes.subjects.includes(subject.id) || scopes.grades.includes(subject.gradeId);

      // If only module access, count just the accessible chapters' lessons.
      const lessonIds: string[] = [];
      for (const ch of subject.chapters) {
        if (fullSubject || scopes.chapters.includes(ch.id)) {
          lessonIds.push(...ch.lessons.map((l) => l.id));
        }
      }
      return {
        id: subject.id,
        name: subject.name,
        code: subject.code,
        order: subject.order,
        // Subject.gradeId is a required (non-nullable) relation in the schema,
        // so `grade` is always populated here — never fabricated from name/code.
        grade: subject.grade,
        lessonIds,
      };
    });
  }

  // "My Learnings" list with per-course progress %.
  async myLearnings(userId: string, status?: 'in_progress' | 'completed') {
    const subjects = await this.accessibleSubjectsWithLessons(userId);
    const allLessonIds = subjects.flatMap((s) => s.lessonIds);

    const progress = await this.prisma.lessonProgress.findMany({
      where: { userId, lessonId: { in: allLessonIds } },
      select: { lessonId: true, completed: true },
    });
    const completedSet = new Set(progress.filter((p) => p.completed).map((p) => p.lessonId));

    let courses = subjects.map((s) => {
      const total = s.lessonIds.length;
      const done = s.lessonIds.filter((id) => completedSet.has(id)).length;
      const percent = total > 0 ? Math.round((done / total) * 100) : 0;
      return {
        subjectId: s.id,
        name: s.name,
        code: s.code,
        grade: s.grade,
        subjectOrder: s.order,
        completedLessons: done,
        totalLessons: total,
        percent,
        isComplete: total > 0 && done === total,
      };
    });

    if (status === 'in_progress') courses = courses.filter((c) => !c.isComplete);
    if (status === 'completed') courses = courses.filter((c) => c.isComplete);

    return courses;
  }

  // "Continue Learning" — the most recently watched, not-yet-complete lesson.
  async continueLearning(userId: string) {
    const last = await this.prisma.lessonProgress.findFirst({
      where: { userId, completed: false },
      orderBy: { lastWatchedAt: 'desc' },
      include: {
        lesson: {
          include: { chapter: { include: { subject: true } } },
        },
      },
    });
    if (!last) return null;

    return {
      lessonId: last.lessonId,
      title: last.lesson.title,
      subject: last.lesson.chapter.subject.name,
      chapter: last.lesson.chapter.name,
      watchedSeconds: last.watchedSeconds,
      durationSeconds: last.lesson.durationSeconds,
    };
  }

  // Profile screen: course count, average progress %, and current day streak.
  async stats(userId: string) {
    const courses = await this.myLearnings(userId);
    const count = courses.length;
    const avgProgress = count
      ? Math.round(courses.reduce((sum, c) => sum + c.percent, 0) / count)
      : 0;
    const dayStreak = await this.computeStreak(userId);
    return { courses: count, avgProgress, dayStreak };
  }

  // Consecutive days (ending today or yesterday) with any watch activity.
  private async computeStreak(userId: string): Promise<number> {
    const rows = await this.prisma.lessonProgress.findMany({
      where: { userId },
      select: { lastWatchedAt: true },
    });
    if (rows.length === 0) return 0;

    const days = new Set(rows.map((r) => r.lastWatchedAt.toISOString().slice(0, 10)));
    const dayMs = 24 * 60 * 60 * 1000;
    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - dayMs).toISOString().slice(0, 10);
    if (!days.has(today) && !days.has(yesterday)) return 0;

    let cursor = days.has(today) ? new Date() : new Date(Date.now() - dayMs);
    let streak = 0;
    while (days.has(cursor.toISOString().slice(0, 10))) {
      streak++;
      cursor = new Date(cursor.getTime() - dayMs);
    }
    return streak;
  }

}
