import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { LessonAccessGuard } from '../access/access.guard';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { ProgressService } from './progress.service';
import { UpdateProgressDto } from './dto/update-progress.dto';

@UseGuards(JwtAuthGuard)
@Controller()
export class ProgressController {
  constructor(private progress: ProgressService) {}

  // Report watch progress. LessonAccessGuard ensures the user owns this lesson.
  @UseGuards(LessonAccessGuard)
  @Post('lessons/:lessonId/progress')
  update(
    @CurrentUser() user: AuthUser,
    @Param('lessonId') lessonId: string,
    @Body() dto: UpdateProgressDto,
  ) {
    return this.progress.update(user.id, lessonId, dto.watchedSeconds, dto.completed);
  }

  @Get('me/learnings')
  learnings(
    @CurrentUser() user: AuthUser,
    @Query('status') status?: 'in_progress' | 'completed',
  ) {
    return this.progress.myLearnings(user.id, status);
  }

  @Get('me/continue')
  continue(@CurrentUser() user: AuthUser) {
    return this.progress.continueLearning(user.id);
  }

  @Get('me/stats')
  stats(@CurrentUser() user: AuthUser) {
    return this.progress.stats(user.id);
  }
}
