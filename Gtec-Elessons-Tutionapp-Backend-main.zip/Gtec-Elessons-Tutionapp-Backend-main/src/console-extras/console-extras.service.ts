import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

interface Requester {
  id: string;
  role: string;
}

@Injectable()
export class ConsoleExtrasService {
  constructor(private prisma: PrismaService) {}

  async teamRoster() {
    const staff = await this.prisma.user.findMany({
      where: { role: { in: ['ADMIN', 'SUPER_ADMIN', 'TEACHER'] } },
      orderBy: { createdAt: 'asc' },
      select: {
        id: true, name: true, email: true, phone: true, role: true, status: true, createdAt: true,
        subjectsTaught: { select: { name: true, grade: { select: { name: true } } } },
      },
    });
    return staff.map((s) => ({
      ...s,
      scope: s.subjectsTaught.length
        ? s.subjectsTaught.map((sub) => `${sub.name}${sub.grade ? ` (${sub.grade.name})` : ''}`).join(', ')
        : null,
    }));
  }

  async teacherSummary(teacherId: string) {
    const weekStart = new Date();
    weekStart.setHours(0, 0, 0, 0);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);

    const [subjects, liveThisWeek, toGrade, openDoubts] = await Promise.all([
      this.prisma.subject.findMany({ where: { teacherId }, select: { id: true } }),
      this.prisma.liveClass.count({ where: { subject: { teacherId }, startsAt: { gte: weekStart, lt: weekEnd } } }),
      this.prisma.assignmentSubmission.count({ where: { status: 'SUBMITTED', assignment: { subject: { teacherId } } } }),
      this.prisma.doubt.count({ where: { teacherId, answeredAt: null } }),
    ]);

    const subjectIds = subjects.map((s) => s.id);
    const myStudents = subjectIds.length
      ? await this.prisma.enrollment.count({ where: { subjectId: { in: subjectIds }, status: 'ACTIVE' } })
      : 0;

    return { myStudents, liveThisWeek, toGrade, openDoubts };
  }

  async broadcastHistory(limit = 30) {
    const rows = await this.prisma.notification.groupBy({
      by: ['title', 'body', 'createdAt'],
      where: { type: 'BROADCAST' },
      _count: { id: true },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
    return rows.map((r) => ({ title: r.title, body: r.body, sentAt: r.createdAt, recipientCount: r._count.id }));
  }

  // ---- My Classes (batches) ----

  async myClasses(teacherId: string) {
    const batches = await this.prisma.batch.findMany({
      where: { teacherId },
      orderBy: { createdAt: 'asc' },
      include: {
        grade: { select: { name: true } },
        subject: { select: { name: true } },
        _count: { select: { enrollments: true } },
      },
    });
    return batches.map((b) => ({
      id: b.id,
      grade: b.grade.name,
      subject: b.subject.name,
      batchName: b.name,
      schedule: b.schedule,
      isActive: b.isActive,
      studentCount: b._count.enrollments,
    }));
  }

  private async assertBatchAccess(batchId: string, requester: Requester) {
    const batch = await this.prisma.batch.findUnique({
      where: { id: batchId },
      include: { grade: { select: { name: true } }, subject: { select: { id: true, name: true } } },
    });
    if (!batch) throw new NotFoundException('Batch not found');
    if (requester.role === 'TEACHER' && batch.teacherId !== requester.id) {
      throw new ForbiddenException('Not your batch');
    }
    return batch;
  }

  async batchDetail(batchId: string, requester: Requester) {
    const batch = await this.assertBatchAccess(batchId, requester);

    const enrollments = await this.prisma.batchEnrollment.findMany({
      where: { batchId },
      orderBy: { createdAt: 'asc' },
      include: { student: { select: { id: true, name: true, email: true } } },
    });

    const roster = await Promise.all(
      enrollments.map(async (e) => {
        const [attendanceTotal, attendancePresent, scoreAgg, lastProgress] = await Promise.all([
          this.prisma.attendanceRecord.count({ where: { batchId, studentId: e.studentId } }),
          this.prisma.attendanceRecord.count({ where: { batchId, studentId: e.studentId, present: true } }),
          this.prisma.assessmentAttempt.aggregate({
            where: { userId: e.studentId, status: 'SUBMITTED', assessment: { subjectId: batch.subjectId } },
            _avg: { score: true },
          }),
          this.prisma.lessonProgress.findFirst({
            where: { userId: e.studentId, lesson: { chapter: { subjectId: batch.subjectId } } },
            orderBy: { lastWatchedAt: 'desc' },
            select: { lastWatchedAt: true },
          }),
        ]);
        return {
          studentId: e.studentId,
          name: e.student.name,
          email: e.student.email,
          attendancePercent: attendanceTotal > 0 ? Math.round((attendancePresent / attendanceTotal) * 100) : null,
          avgScore: scoreAgg._avg.score != null ? Math.round(scoreAgg._avg.score) : null,
          lastActiveAt: lastProgress?.lastWatchedAt ?? null,
        };
      }),
    );

    return {
      id: batch.id,
      grade: batch.grade.name,
      subject: batch.subject.name,
      batchName: batch.name,
      schedule: batch.schedule,
      studentCount: enrollments.length,
      roster,
    };
  }

  async markAttendance(
    batchId: string,
    date: string,
    records: { studentId: string; present: boolean }[],
    requester: Requester,
  ) {
    await this.assertBatchAccess(batchId, requester);
    const day = new Date(date);
    await this.prisma.$transaction(
      records.map((r) =>
        this.prisma.attendanceRecord.upsert({
          where: { batchId_studentId_date: { batchId, studentId: r.studentId, date: day } },
          update: { present: r.present, markedAt: new Date() },
          create: { batchId, studentId: r.studentId, date: day, present: r.present },
        }),
      ),
    );
    return { batchId, date, marked: records.length };
  }

  // ---- Study materials library ----

  async materials(teacherId: string) {
    const resources = await this.prisma.resource.findMany({
      where: {
        OR: [
          { lesson: { chapter: { subject: { teacherId } } } },
          { chapter: { subject: { teacherId } } },
        ],
      },
      orderBy: { id: 'desc' },
      include: {
        lesson: { select: { chapter: { select: { name: true, subject: { select: { name: true } } } } } },
        chapter: { select: { name: true, subject: { select: { name: true } } } },
      },
    });
    return resources.map((r) => {
      const chapter = r.lesson?.chapter ?? r.chapter;
      return {
        id: r.id,
        title: r.title,
        type: r.type,
        chapter: chapter?.name ?? null,
        subject: chapter?.subject?.name ?? null,
        downloadCount: r.downloadCount,
        isDownloadable: r.isDownloadable,
      };
    });
  }

  async leads(take = 50, skip = 0) {
    const where = { role: 'STUDENT' as const, orders: { none: { status: 'PAID' as const } } };
    const [total, students] = await Promise.all([
      this.prisma.user.count({ where }),
      this.prisma.user.findMany({
        where, take, skip, orderBy: { createdAt: 'desc' },
        select: {
          id: true, name: true, email: true, phone: true, createdAt: true,
          studentProfile: { select: { grade: { select: { name: true } } } },
          cart: { select: { items: { select: { id: true } } } },
        },
      }),
    ]);
    return {
      total,
      leads: students.map((s) => ({
        id: s.id, name: s.name, email: s.email, phone: s.phone,
        grade: s.studentProfile?.grade?.name ?? null, signedUpAt: s.createdAt,
        hasItemsInCart: (s.cart?.items.length ?? 0) > 0,
        temperature: (s.cart?.items.length ?? 0) > 0 ? 'warm' : 'cold',
      })),
    };
  }
}
