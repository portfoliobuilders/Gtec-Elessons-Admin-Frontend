import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { ConsoleExtrasService } from './console-extras.service';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN', 'TEACHER')
@Controller('admin')
export class ConsoleExtrasController {
  constructor(private svc: ConsoleExtrasService) {}

  // Staff directory (names/emails/phone numbers of every ADMIN/TEACHER) — an
  // HR/ops concern, not a teaching-console feature. Every sibling "Business"
  // route (orders, reviews, broadcast, insights, team-invites) is already
  // ADMIN/SUPER_ADMIN-only; this one alone was left open to TEACHER by
  // inheriting the controller's permissive class-level guard.
  @Roles('ADMIN', 'SUPER_ADMIN')
  @Get('team-roster') roster() { return this.svc.teamRoster(); }

  // teacherId is a client-supplied query param — a TEACHER caller must never be
  // able to override it to view another teacher's data. Only ADMIN/SUPER_ADMIN
  // may target an arbitrary teacher; TEACHER is always pinned to their own JWT id.
  @Get('teacher-console/summary')
  teacherSummary(@CurrentUser() user: AuthUser, @Query('teacherId') teacherId?: string) {
    return this.svc.teacherSummary(user.role === 'TEACHER' ? user.id : teacherId || user.id);
  }

  // Same pattern as team-roster above: POST /admin/broadcast (sending one) is
  // already ADMIN/SUPER_ADMIN-only — the read history should match.
  @Roles('ADMIN', 'SUPER_ADMIN')
  @Get('broadcast-history')
  broadcastHistory(@Query('limit') limit?: string) { return this.svc.broadcastHistory(limit ? +limit : 30); }

  // Sales/marketing prospect data (signed-up-but-unpaid students) — no
  // teaching-console use case. Same oversight as team-roster above.
  @Roles('ADMIN', 'SUPER_ADMIN')
  @Get('leads')
  leads(@Query('take') take?: string, @Query('skip') skip?: string) {
    return this.svc.leads(take ? +take : 50, skip ? +skip : 0);
  }

  @Get('teacher-console/my-classes')
  myClasses(@CurrentUser() user: AuthUser, @Query('teacherId') teacherId?: string) {
    return this.svc.myClasses(user.role === 'TEACHER' ? user.id : teacherId || user.id);
  }

  @Get('teacher-console/batches/:id')
  batchDetail(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.batchDetail(id, user);
  }

  @Post('teacher-console/batches/:id/attendance')
  markAttendance(
    @CurrentUser() user: AuthUser,
    @Param('id') id: string,
    @Body() body: { date: string; records: { studentId: string; present: boolean }[] },
  ) {
    return this.svc.markAttendance(id, body.date, body.records, user);
  }

  @Get('teacher-console/materials')
  materials(@CurrentUser() user: AuthUser, @Query('teacherId') teacherId?: string) {
    return this.svc.materials(user.role === 'TEACHER' ? user.id : teacherId || user.id);
  }
}
