import { Module } from '@nestjs/common';
import { ConsoleExtrasService } from './console-extras.service';
import { ConsoleExtrasController } from './console-extras.controller';

@Module({ controllers: [ConsoleExtrasController], providers: [ConsoleExtrasService] })
export class ConsoleExtrasModule {}
