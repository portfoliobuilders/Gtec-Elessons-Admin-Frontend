import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import * as express from 'express';
import { join } from 'path';
import { networkInterfaces } from 'os';
import { AppModule } from './app.module';
import { AuthService } from './auth/auth.service';
import { FileSizeExceptionFilter } from './common/filters/file-size-exception.filter';

function lanAddresses(): string[] {
  return Object.values(networkInterfaces())
    .flat()
    .filter((i): i is NonNullable<typeof i> => !!i && i.family === 'IPv4' && !i.internal)
    .map((i) => i.address);
}

function allowedOrigins(): string[] {
  const configured =
    process.env.APP_ORIGINS ?? process.env.FRONTEND_URL ?? process.env.APP_BASE_URL;
  if (configured) {
    return configured
      .split(',')
      .map((origin) => origin.trim())
      .filter(Boolean);
  }

  return [
    'http://localhost:3000',
    'http://localhost:3001',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:3001',
  ];
}

function isDevelopmentOrigin(origin: string): boolean {
  if (process.env.NODE_ENV === 'production') return false;

  try {
    const { hostname } = new URL(origin);
    return (
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname.startsWith('192.168.') ||
      hostname.startsWith('10.') ||
      /^172\.(1[6-9]|2\d|3[0-1])\./.test(hostname)
    );
  } catch {
    return false;
  }
}

async function bootstrap() {
  // rawBody:true lets the Razorpay webhook handler read req.rawBody for HMAC signature verification.
  const app = await NestFactory.create(AppModule, { rawBody: true });

  // Serves uploaded avatar/KYC files — a local-disk stopgap (see uploads.service.ts)
  // until a real object store (S3/R2/Supabase) is wired in.
  app.use('/uploads', express.static(join(process.cwd(), 'uploads')));

  app.setGlobalPrefix('api');
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );
  // Rewrites the oversized-upload response (avatar/KYC/grade-subject-chapter
  // photos — see upload.config.ts in users/ and admin/) from multer's bare
  // 413 "File too large" into a 400 that states the actual limit.
  app.useGlobalFilters(new FileSizeExceptionFilter());
  const origins = allowedOrigins();
  app.enableCors({
    credentials: true,
    origin(origin, callback) {
      if (!origin || origins.includes(origin) || isDevelopmentOrigin(origin)) {
        callback(null, true);
        return;
      }
      callback(null, false);
    },
  });

  // So hitting the bare host doesn't 404 — send visitors to the API docs.
  app.getHttpAdapter().get('/', (_req, res) => res.redirect('/api/docs'));

  // Landing page for the email-verification link sent by AuthService.
  // sendVerificationEmail() builds `${APP_BASE_URL}/verify-email?token=...`
  // — there's no separate web frontend project that owns this route, so the
  // backend serves it directly rather than pointing the link at a page that
  // doesn't exist. Consumes the token via the same verifyEmail() the
  // POST /api/auth/verify-email API uses, then shows a plain result page.
  app.getHttpAdapter().get('/verify-email', async (req: any, res: any) => {
    const token = typeof req.query?.token === 'string' ? req.query.token : '';
    let ok = false;
    if (token) {
      try {
        await app.get(AuthService).verifyEmail(token);
        ok = true;
      } catch {
        ok = false;
      }
    }
    res
      .status(ok ? 200 : 400)
      .type('html')
      .send(`<!doctype html>
<html><head><meta charset="utf-8"><title>G-TEC — Email Verification</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#f6f7f9;color:#1a1a1a}
.card{background:#fff;padding:2rem 2.5rem;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.08);text-align:center;max-width:360px}
h1{font-size:1.25rem;margin:0 0 .5rem}
p{color:#555;margin:0}
.icon{font-size:2.5rem;margin-bottom:.5rem}
</style></head>
<body><div class="card">
<div class="icon">${ok ? '✅' : '⚠️'}</div>
<h1>${ok ? 'Email verified' : 'Link invalid or expired'}</h1>
<p>${ok ? 'You can return to the G-TEC app and continue.' : 'Please request a new verification email from the app.'}</p>
</div></body></html>`);
  });

  const config = new DocumentBuilder()
    .setTitle('G-TEC e-Lessons API')
    .setDescription('Backend API for the G-TEC app')
    .setVersion('1.0')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document, {
    swaggerOptions: { persistAuthorization: true },
  });

  const port = process.env.PORT ? Number(process.env.PORT) : 3000;
  await app.listen(port, '0.0.0.0');
  // eslint-disable-next-line no-console
  console.log(`G-TEC backend running on http://localhost:${port}/api`);
  for (const ip of lanAddresses()) {
    // eslint-disable-next-line no-console
    console.log(`  also reachable on the LAN at http://${ip}:${port}/api`);
  }
  // eslint-disable-next-line no-console
  console.log(`API docs at http://localhost:${port}/api/docs`);
}
bootstrap();
