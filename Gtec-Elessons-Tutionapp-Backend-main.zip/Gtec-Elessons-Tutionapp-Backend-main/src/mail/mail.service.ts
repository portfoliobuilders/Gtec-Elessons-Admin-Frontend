import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';

export interface MailOptions {
  to: string;
  subject: string;
  html: string;
}

// Singleton mail sender — the transporter is created once here (module-scoped
// provider, default Nest scope) and reused for every send, instead of being
// rebuilt per request.
//
// Transport: Gmail via Nodemailer's `service: 'gmail'` shorthand — the same
// working pattern used by the reference PortfolixLMS backend, in place of the
// previous generic host/port SMTP transport (which was pointed at Ethereal, a
// sandbox that only ever delivers to a preview inbox, never a real address).
//
// Credentials: SUPPORT_EMAIL / SUPPORT_EMAIL_PASSWORD (a Gmail address + its
// Google App Password — not the account's normal login password), falling
// back to SMTP_USER / SMTP_PASS if that's what's already set in the
// environment, so no .env rename is forced.
@Injectable()
export class MailService {
  private readonly logger = new Logger(MailService.name);
  private readonly transporter: nodemailer.Transporter | null;
  private readonly from: string;

  constructor() {
    // `||`, not `??` — an env var set to "" (as in .env.example / the
    // unfilled-in default) must fall through to the SMTP_* pair too, not be
    // treated as a deliberately-empty override.
    const user = process.env.SUPPORT_EMAIL || process.env.SMTP_USER;
    const pass = process.env.SUPPORT_EMAIL_PASSWORD || process.env.SMTP_PASS;

    // Gmail requires (and otherwise silently rewrites) the From header to
    // match the authenticated account, so default to that address rather
    // than an arbitrary no-reply@ domain Gmail won't send mail as.
    this.from = process.env.MAIL_FROM ?? (user ? `"G-TEC" <${user}>` : 'G-TEC <no-reply@gtec.dev>');

    if (!user || !pass) {
      this.logger.warn(
        'SMTP not configured (SUPPORT_EMAIL/SUPPORT_EMAIL_PASSWORD or SMTP_USER/SMTP_PASS) — emails will not be sent.',
      );
      this.transporter = null;
      return;
    }

    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user, pass },
    });
  }

  // Best-effort send — never throws. Callers must not let delivery failure
  // change what they tell the client (e.g. forgotPassword's anti-enumeration
  // response), so failures are logged here and reported back as `false`.
  async sendMail(options: MailOptions): Promise<boolean> {
    if (!this.transporter) return false;
    try {
      const info = await this.transporter.sendMail({ from: this.from, ...options });
      // No-op outside Ethereal test accounts — getTestMessageUrl() returns
      // false for real transports, so this is safe to leave in permanently.
      const previewUrl = nodemailer.getTestMessageUrl(info);
      if (previewUrl) this.logger.log(`Preview URL: ${previewUrl}`);
      return true;
    } catch (err) {
      this.logger.error(`Failed to send email to ${options.to}: ${err}`);
      return false;
    }
  }
}
