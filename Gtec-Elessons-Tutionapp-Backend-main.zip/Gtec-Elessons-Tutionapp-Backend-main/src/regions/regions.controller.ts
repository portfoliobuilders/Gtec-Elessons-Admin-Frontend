import { Controller, Get, Query } from '@nestjs/common';
import { Public } from '../common/decorators/public.decorator';
import { CurrencyService } from './currency.service';

@Controller('regions')
export class RegionsController {
  constructor(private currency: CurrencyService) {}

  // Public: shown as the country picker before login.
  @Public()
  @Get()
  countries() {
    return this.currency.countries();
  }

  // Utility: convert a single INR-cents amount into another currency.
  @Public()
  @Get('convert')
  convert(@Query('amountCents') amountCents: string, @Query('currency') currency: string) {
    return this.currency.convert(Number(amountCents || 0), currency || 'INR');
  }
}
