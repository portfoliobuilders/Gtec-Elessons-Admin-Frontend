import { Injectable, Logger } from '@nestjs/common';
import * as geoip from 'geoip-lite';
import { PrismaService } from '../prisma/prisma.service';

export interface Country {
  code: string;
  name: string;
  currency: string;
  symbol: string;
}

@Injectable()
export class CurrencyService {
  private readonly logger = new Logger(CurrencyService.name);
  private liveRates: Record<string, number> | null = null;
  private lastFetchedAt = 0;
  private readonly REFRESH_MS = 12 * 60 * 60 * 1000; // refresh at most every 12h

  constructor(private prisma: PrismaService) {}

  // DB-backed fallback — 1 INR expressed in the target currency. Replaces the
  // old hardcoded FALLBACK_RATES map; admin-editable via /admin/exchange-rates.
  private async fallbackRates(): Promise<Record<string, number>> {
    const rows = await this.prisma.exchangeRate.findMany();
    const rates: Record<string, number> = {};
    for (const r of rows) rates[r.currency] = r.rateToInr;
    return rates;
  }

  private async ratesFor(): Promise<Record<string, number>> {
    const stale = Date.now() - this.lastFetchedAt > this.REFRESH_MS;
    if (this.liveRates && !stale) return this.liveRates;

    try {
      const res = await fetch('https://open.er-api.com/v6/latest/INR');
      const data: any = await res.json();
      if (data?.result === 'success' && data.rates) {
        this.liveRates = data.rates;
        this.lastFetchedAt = Date.now();
        return this.liveRates!;
      }
      throw new Error('Unexpected FX API response');
    } catch (err) {
      this.logger.warn(`FX rate fetch failed, using DB fallback rates: ${err}`);
      return this.liveRates ?? this.fallbackRates();
    }
  }

  countries(): Promise<Country[]> {
    return this.prisma.country.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' },
      select: { code: true, name: true, currency: true, symbol: true },
    });
  }

  async symbolFor(currency: string): Promise<string> {
    const row = await this.prisma.country.findFirst({ where: { currency }, select: { symbol: true } });
    return row?.symbol ?? currency;
  }

  async convertFromINR(amountCentsINR: number, currency: string): Promise<number> {
    if (currency === 'INR') return amountCentsINR;
    const rates = await this.ratesFor();
    let rate = rates[currency];
    if (rate === undefined) {
      const fallback = await this.fallbackRates();
      rate = fallback[currency] ?? 1;
    }
    const majorUnits = (amountCentsINR / 100) * rate;
    return Math.round(majorUnits) * 100;
  }

  // Pre-login default currency: map the visitor's IP to a country (offline
  // MaxMind lookup via geoip-lite — no network call, no API key/rate limit),
  // then to that country's currency via the same Country table /regions
  // uses. Returns null (caller falls back to INR) whenever detection can't
  // produce a real answer: no IP, a private/loopback/reserved address (every
  // local-dev request — geoip-lite returns null for these, not an error), an
  // IP the DB has no geo data for, or a country we don't have configured.
  async currencyForIp(ip: string | undefined): Promise<string | null> {
    if (!ip) return null;
    const geo = geoip.lookup(ip);
    if (!geo?.country) return null;
    const countries = await this.countries();
    const match = countries.find((c) => c.code === geo.country);
    return match?.currency ?? null;
  }

  async convert(amountCentsINR: number, currency: string) {
    const code = currency.toUpperCase();
    const [amountCents, symbol] = await Promise.all([
      this.convertFromINR(amountCentsINR, code),
      this.symbolFor(code),
    ]);
    return {
      currency: code,
      symbol,
      amountCents,
      amount: amountCents / 100,
      display: `${symbol}${(amountCents / 100).toLocaleString()}`,
    };
  }
}
