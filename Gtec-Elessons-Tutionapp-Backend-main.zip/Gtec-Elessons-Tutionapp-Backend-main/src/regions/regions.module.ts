import { Global, Module } from '@nestjs/common';
import { CurrencyService } from './currency.service';
import { RegionsController } from './regions.controller';

@Global()
@Module({
  controllers: [RegionsController],
  providers: [CurrencyService],
  exports: [CurrencyService],
})
export class RegionsModule {}
