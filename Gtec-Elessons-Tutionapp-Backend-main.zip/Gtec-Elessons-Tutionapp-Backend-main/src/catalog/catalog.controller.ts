import { Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { Public } from '../common/decorators/public.decorator';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { OptionalJwtAuthGuard } from '../common/guards/optional-jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { getClientIp } from '../common/utils/client-ip';
import { CatalogService } from './catalog.service';

@Controller()
export class CatalogController {
  constructor(private catalog: CatalogService) {}

  // ── Public store/catalog tree ─────────────────────────────────────────────
  // Returns every active grade with its subjects, chapter counts, and pricing.
  // No auth required to browse — but OptionalJwtAuthGuard (not @Public()) so
  // that a bearer token, if sent, still populates req.user: a logged-in
  // caller's displayed currency must come from their StudentProfile, never
  // from IP, even browsing from a different country than their profile.
  // teacherId is stripped from the response.
  //
  // Currency precedence (resolved in CatalogService): explicit ?currency=
  // always wins > logged-in profile currency > IP-geolocated currency >
  // INR fallback (covers local dev, and any IP geolocation can't place).
  @UseGuards(OptionalJwtAuthGuard)
  @Get('store')
  storeCatalog(@Query('currency') currency: string | undefined, @Req() req: any) {
    return this.catalog.storeCatalog(currency, req.user?.id, getClientIp(req));
  }

  @Public()
  @Get('grades')
  grades(@Query('board') board?: string) {
    return this.catalog.listGrades(board);
  }

  @UseGuards(OptionalJwtAuthGuard)
  @Get('grades/:id')
  grade(@Param('id') id: string, @Query('currency') currency: string | undefined, @Req() req: any) {
    return this.catalog.getGrade(id, currency, req.user?.id, getClientIp(req));
  }

  // Flat subject list for pickers/dropdowns (e.g. the teacher app). Unlike the
  // other catalog reads this isn't public — a TEACHER is auto-scoped to their
  // own subjects (mirrors AdminCurriculumService.tree()); ADMIN/SUPER_ADMIN see
  // everything unless they pass ?teacherId=.
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Get('subjects')
  subjects(@CurrentUser() user: AuthUser, @Query('gradeId') gradeId?: string, @Query('teacherId') teacherId?: string) {
    return this.catalog.listSubjects(user, gradeId, teacherId);
  }

  @UseGuards(OptionalJwtAuthGuard)
  @Get('subjects/:id')
  subject(@Param('id') id: string, @Query('currency') currency: string | undefined, @Req() req: any) {
    return this.catalog.getSubject(id, currency, req.user?.id, getClientIp(req));
  }

  @UseGuards(OptionalJwtAuthGuard)
  @Get('chapters/:id')
  chapter(@Param('id') id: string, @Query('currency') currency: string | undefined, @Req() req: any) {
    return this.catalog.getChapter(id, currency, req.user?.id, getClientIp(req));
  }

  // Optional auth: works logged-out (preview only) or logged-in (gated fields).
  @UseGuards(OptionalJwtAuthGuard)
  @Get('lessons/:id')
  lesson(@Param('id') id: string, @Req() req: any) {
    return this.catalog.getLesson(id, req.user?.id);
  }

  @UseGuards(JwtAuthGuard)
  @Post('resources/:id/download')
  downloadResource(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.catalog.recordResourceDownload(id, user.id);
  }
}
