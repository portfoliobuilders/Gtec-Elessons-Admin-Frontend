import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AccessService } from '../access/access.service';
import { CurrencyService } from '../regions/currency.service';
import { toFlatPrice, toMultiFlatPrice, toProductVariants } from '../common/pricing/flatten-price';

interface Requester {
  id: string;
  role: string;
}

@Injectable()
export class CatalogService {
  constructor(
    private prisma: PrismaService,
    private access: AccessService,
    private currency: CurrencyService,
  ) { }

  // Adds a `displayPrice` (converted from the INR base) to each product —
  // lets the app show localized prices while browsing, before anything is
  // added to cart.
  //
  // CurrencyService still works in its own legacy "amount × 100" convention
  // internally (an unrelated live-FX display subsystem, untouched by Phase
  // 5B — see report). ProductPrice.amount is now the plain business decimal,
  // so it's converted into that convention right here, at the call site,
  // rather than changing CurrencyService's public contract.
  private async attachDisplayPrices(products: any[], currencyCode: string) {
    for (const product of products) {
      const inr = product.prices.find((p: any) => p.region === 'IN' && p.currency === 'INR');
      if (inr) product.displayPrice = await this.currency.convert(Math.round(Number(inr.amount) * 100), currencyCode);
    }
  }

  // Resolves which currency to display prices in, in priority order:
  //   1. an explicit ?currency= query param — always wins, manual override.
  //   2. a logged-in caller's StudentProfile.currency — never IP, so a
  //      traveling student still sees their home currency regardless of
  //      which country their current connection routes through.
  //   3. IP geolocation (anonymous callers only) — the visitor's presumed
  //      home currency before they've picked one or signed up.
  //   4. INR — final fallback when IP detection can't place the address at
  //      all (missing IP, private/loopback/reserved range — i.e. every
  //      local-dev request — or a country we don't have configured).
  private async resolveDisplayCurrency(explicit: string | undefined, userId: string | undefined, ip: string | undefined): Promise<string> {
    if (explicit) return explicit.toUpperCase();
    if (userId) {
      const profile = await this.prisma.studentProfile.findUnique({ where: { userId }, select: { currency: true } });
      if (profile?.currency) return profile.currency.toUpperCase();
    }
    const detected = await this.currency.currencyForIp(ip);
    return detected ?? 'INR';
  }

  async listGrades(board?: string) {
    const grades = await this.prisma.grade.findMany({
      where: { isActive: true, ...(board ? { board } : {}) },
      orderBy: { order: 'asc' },
      include: { products: { where: { isActive: true }, include: { prices: true } } },
    });
    return grades.map((g) => {
      const { products, ...rest } = g;
      const price = toFlatPrice(products[0]);
      return { ...rest, ...(price ? { price } : {}), products: toProductVariants(products) };
    });
  }

  // Public store/catalog tree — same shape as /admin/curriculum but:
  //   • no teacherId (admin-only field)
  //   • only active grades
  //   • products/prices included so the UI can show prices while browsing
  //   • no auth required (browsing before signup is normal e-commerce UX)
  async storeCatalog(currency?: string, userId?: string, ip?: string) {
    const grades = await this.prisma.grade.findMany({
      where: { isActive: true },
      orderBy: { order: 'asc' },
      include: {
        subjects: {
          orderBy: { order: 'asc' },
          include: {
            chapters: {
              orderBy: { order: 'asc' },
              include: {
                _count: { select: { lessons: true } },
                products: { where: { isActive: true }, include: { prices: true } },
              },
            },
            products: { where: { isActive: true }, include: { prices: true } },
          },
        },
        products: { where: { isActive: true }, include: { prices: true } },
      },
    });

    // Always attach display prices — currency is now always resolved to
    // something (explicit param, profile, IP-detected, or INR), not opt-in.
    const code = await this.resolveDisplayCurrency(currency, userId, ip);
    for (const grade of grades) {
      await this.attachDisplayPrices(grade.products, code);
      for (const subject of grade.subjects) {
        await this.attachDisplayPrices(subject.products, code);
        for (const chapter of subject.chapters) {
          await this.attachDisplayPrices(chapter.products, code);
        }
        // Strip teacherId — students/public must not see internal staff IDs
        (subject as any).teacherId = undefined;
      }
    }

    // Map to a clean, consumer-facing shape
    return grades.map((g) => {
      const gradePrice = toMultiFlatPrice(g.products[0]);
      return {
        id: g.id,
        name: g.name,
        board: g.board,
        syllabus: (g as any).syllabus,
        description: (g as any).description,
        trailerYoutubeId: (g as any).trailerYoutubeId,
        trailerThumbnailUrl: (g as any).trailerThumbnailUrl,
        iconUrl: (g as any).iconUrl ?? null,
        order: g.order,
        // `price`/`prices` (singular, from the first/default product) are
        // kept for existing clients. `products` is the full list of active
        // variants (e.g. Recorded vs Recorded + Mentor) a student can pick
        // between — added so the storefront isn't stuck always selling
        // whichever product happened to be products[0].
        ...(gradePrice?.price ? { price: gradePrice.price } : {}),
        ...(gradePrice ? { prices: gradePrice.prices } : {}),
        products: toProductVariants(g.products),
        subjects: g.subjects.map((s) => {
          const subjectPrice = toMultiFlatPrice(s.products[0]);
          return {
            id: s.id,
            name: s.name,
            code: s.code,
            description: (s as any).description,
            trailerYoutubeId: (s as any).trailerYoutubeId,
            trailerThumbnailUrl: (s as any).trailerThumbnailUrl,
            iconUrl: (s as any).iconUrl ?? null,
            order: s.order,
            gradeId: s.gradeId,
            chapterCount: s.chapters.length,
            lessonCount: s.chapters.reduce((acc, ch) => acc + ch._count.lessons, 0),
            chapters: s.chapters.map((ch) => {
              const chapterPrice = toMultiFlatPrice(ch.products[0]);
              return {
                id: ch.id,
                name: ch.name,
                description: (ch as any).description,
                trailerYoutubeId: (ch as any).trailerYoutubeId,
                trailerThumbnailUrl: (ch as any).trailerThumbnailUrl,
                iconUrl: (ch as any).iconUrl ?? null,
                order: ch.order,
                lessonCount: ch._count.lessons,
                ...(chapterPrice?.price ? { price: chapterPrice.price } : {}),
                ...(chapterPrice ? { prices: chapterPrice.prices } : {}),
                products: toProductVariants(ch.products),
              };
            }),
            ...(subjectPrice?.price ? { price: subjectPrice.price } : {}),
            ...(subjectPrice ? { prices: subjectPrice.prices } : {}),
            products: toProductVariants(s.products),
          };
        }),
      };
    });
  }

  async getGrade(id: string, currency?: string, userId?: string, ip?: string) {
    const grade = await this.prisma.grade.findUnique({
      where: { id },
      include: {
        subjects: {
          orderBy: { order: 'asc' },
          include: {
            _count: { select: { chapters: true } },
            products: { where: { isActive: true }, include: { prices: true } },
          },
        },
        products: { where: { isActive: true }, include: { prices: true } },
      },
    });
    if (!grade) throw new NotFoundException('Grade not found');
    const code = await this.resolveDisplayCurrency(currency, userId, ip);
    await this.attachDisplayPrices(grade.products, code);
    for (const subject of grade.subjects) {
      await this.attachDisplayPrices(subject.products, code);
    }
    const { products: gradeProducts, ...gradeRest } = grade;
    const gradePrice = toMultiFlatPrice(gradeProducts[0]);
    return {
      ...gradeRest,
      ...(gradePrice?.price ? { price: gradePrice.price } : {}),
      ...(gradePrice ? { prices: gradePrice.prices } : {}),
      products: toProductVariants(gradeProducts),
      subjects: grade.subjects.map((s) => {
        const { products: subjectProducts, ...subjectRest } = s;
        const subjectPrice = toMultiFlatPrice(subjectProducts[0]);
        return {
          ...subjectRest,
          ...(subjectPrice?.price ? { price: subjectPrice.price } : {}),
          ...(subjectPrice ? { prices: subjectPrice.prices } : {}),
          products: toProductVariants(subjectProducts),
        };
      }),
    };
  }

  // Flat, role-scoped subject list — powers pickers (e.g. the teacher app's
  // subject dropdown) that don't need the nested grade/chapter tree.
  // Mirrors AdminCurriculumService.tree()'s teacherId scoping.
  async listSubjects(requester: Requester, gradeId?: string, teacherId?: string) {
    const scopeTeacherId = requester.role === 'TEACHER' ? requester.id : teacherId;
    const subjects = await this.prisma.subject.findMany({
      where: {
        ...(gradeId ? { gradeId } : {}),
        ...(scopeTeacherId ? { teacherId: scopeTeacherId } : {}),
      },
      orderBy: [{ grade: { order: 'asc' } }, { order: 'asc' }],
      select: {
        id: true,
        name: true,
        code: true,
        gradeId: true,
        grade: { select: { name: true } },
        _count: { select: { chapters: true } },
        products: { where: { isActive: true }, include: { prices: true } },
      },
    });
    return subjects.map((s) => {
      const price = toMultiFlatPrice(s.products[0]);
      return {
        id: s.id,
        name: s.name,
        code: s.code,
        gradeId: s.gradeId,
        gradeName: s.grade.name,
        chapterCount: s._count.chapters,
        ...(price?.price ? { price: price.price } : {}),
        ...(price ? { prices: price.prices } : {}),
      };
    });
  }

  async getSubject(id: string, currency?: string, userId?: string, ip?: string) {
    const subject = await this.prisma.subject.findUnique({
      where: { id },
      include: {
        chapters: {
          orderBy: { order: 'asc' },
          include: { _count: { select: { lessons: true } } },
        },
        products: { where: { isActive: true }, include: { prices: true } },
      },
    });
    if (!subject) throw new NotFoundException('Subject not found');
    const code = await this.resolveDisplayCurrency(currency, userId, ip);
    await this.attachDisplayPrices(subject.products, code);
    const { teacherId: _tId, teacherName: _tName, products: subjectProducts, ...cleanSubject } = subject;
    const price = toMultiFlatPrice(subjectProducts[0]);
    return {
      ...cleanSubject,
      ...(price?.price ? { price: price.price } : {}),
      ...(price ? { prices: price.prices } : {}),
      products: toProductVariants(subjectProducts),
    };
  }

  async getChapter(id: string, currency?: string, userId?: string, ip?: string) {
    const chapter = await this.prisma.chapter.findUnique({
      where: { id },
      include: {
        lessons: {
          where: { isPublished: true },
          orderBy: { order: 'asc' },
          select: {
            id: true,
            title: true,
            durationSeconds: true,
            order: true,
            isFreePreview: true,
            thumbnailUrl: true,
          },
        },
        products: { where: { isActive: true }, include: { prices: true } },
      },
    });
    if (!chapter) throw new NotFoundException('Chapter not found');
    const code = await this.resolveDisplayCurrency(currency, userId, ip);
    await this.attachDisplayPrices(chapter.products, code);
    const { products: chapterProducts, ...cleanChapter } = chapter;
    const price = toMultiFlatPrice(chapterProducts[0]);
    return {
      ...cleanChapter,
      ...(price?.price ? { price: price.price } : {}),
      ...(price ? { prices: price.prices } : {}),
      products: toProductVariants(chapterProducts),
    };
  }

  // Lesson detail. Metadata is public; video identifiers are intentionally not
  // exposed here. Clients must call GET /lessons/:lessonId/video after opening
  // the lesson so access checks, no-store headers, rate limits, and auditing
  // all run in one place.
  async getLesson(lessonId: string, userId?: string) {
    const lesson = await this.prisma.lesson.findUnique({
      where: { id: lessonId },
      include: { resources: true },
    });
    if (!lesson || !lesson.isPublished) throw new NotFoundException('Lesson not found');

    const hasAccess = userId
      ? await this.access.canAccessLesson(userId, lessonId)
      : lesson.isFreePreview;

    return {
      id: lesson.id,
      title: lesson.title,
      description: lesson.description,
      durationSeconds: lesson.durationSeconds,
      thumbnailUrl: lesson.thumbnailUrl,
      isFreePreview: lesson.isFreePreview,
      hasAccess,
      resources: hasAccess ? lesson.resources : [],
      locked: !hasAccess,
    };
  }

  async recordResourceDownload(resourceId: string, userId: string) {
    const resource = await this.prisma.resource.findUnique({
      where: { id: resourceId },
      include: { lesson: { select: { chapterId: true } } },
    });
    if (!resource) throw new NotFoundException('Resource not found');
    if (!resource.isDownloadable) throw new BadRequestException('This resource is not downloadable');

    const chapterId = resource.chapterId ?? resource.lesson?.chapterId ?? null;
    const hasAccess = chapterId ? await this.access.canAccessScope(userId, { chapterId }) : false;
    if (!hasAccess) throw new ForbiddenException('You have not purchased access to this resource');

    return this.prisma.resource.update({
      where: { id: resourceId },
      data: { downloadCount: { increment: 1 } },
    });
  }
}
