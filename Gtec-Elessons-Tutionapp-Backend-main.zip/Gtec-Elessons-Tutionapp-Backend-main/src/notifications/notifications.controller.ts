import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { NotificationsService } from './notifications.service';

@UseGuards(JwtAuthGuard)
@Controller('me/notifications')
export class NotificationsController {
  constructor(private svc: NotificationsService) {}

  @Get()
  list(@CurrentUser() user: AuthUser, @Query('unread') unread?: string) {
    return this.svc.list(user.id, unread === 'true');
  }

  @Get('unread-count')
  count(@CurrentUser() user: AuthUser) {
    return this.svc.unreadCount(user.id);
  }

  @Patch(':id/read')
  read(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.markRead(user.id, id);
  }

  @Patch('read-all')
  readAll(@CurrentUser() user: AuthUser) {
    return this.svc.markAllRead(user.id);
  }

  // Registers this device for push notifications (call on login/app start).
  @Post('device-token')
  registerDevice(@CurrentUser() user: AuthUser, @Body() body: { token: string; platform?: string }) {
    return this.svc.registerDevice(user.id, body.token, body.platform);
  }

  // Call on logout so this device stops receiving pushes for this account.
  @Delete('device-token')
  unregisterDevice(@CurrentUser() user: AuthUser, @Body() body: { token: string }) {
    return this.svc.unregisterDevice(user.id, body.token);
  }
}
