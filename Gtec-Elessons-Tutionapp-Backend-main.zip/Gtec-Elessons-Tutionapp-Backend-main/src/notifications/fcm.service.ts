import { Injectable, Logger } from '@nestjs/common';
import { initializeApp, cert, getApps, App } from 'firebase-admin/app';
import { getMessaging } from 'firebase-admin/messaging';

@Injectable()
export class FcmService {
  private readonly logger = new Logger(FcmService.name);
  private app: App | null = null;
  private warnedOnce = false;

  private getApp(): App | null {
    if (this.app) return this.app;
    const projectId = process.env.FIREBASE_PROJECT_ID;
    const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
    const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
    if (!projectId || !clientEmail || !privateKey) {
      if (!this.warnedOnce) {
        this.logger.warn('Firebase credentials not set — push notifications are disabled (in-app notifications still work).');
        this.warnedOnce = true;
      }
      return null;
    }
    this.app = getApps()[0] ?? initializeApp({ credential: cert({ projectId, clientEmail, privateKey }) });
    return this.app;
  }

  // Best-effort: never throws. Returns the tokens that turned out to be dead
  // (unregistered/uninstalled) so the caller can clean them up.
  async sendToTokens(tokens: string[], title: string, body: string): Promise<string[]> {
    if (tokens.length === 0) return [];
    const app = this.getApp();
    if (!app) return [];

    const deadTokens: string[] = [];
    try {
      const res = await getMessaging(app).sendEachForMulticast({
        tokens,
        notification: { title, body },
      });
      res.responses.forEach((r, i) => {
        if (!r.success && (r.error?.code === 'messaging/registration-token-not-registered' || r.error?.code === 'messaging/invalid-registration-token')) {
          deadTokens.push(tokens[i]);
        }
      });
    } catch (err) {
      this.logger.warn(`FCM send failed: ${err}`);
    }
    return deadTokens;
  }
}
