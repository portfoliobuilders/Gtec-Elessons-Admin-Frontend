import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { FcmService } from './fcm.service';

@Injectable()
export class NotificationsService {
  constructor(
    private prisma: PrismaService,
    private fcm: FcmService,
  ) {}

  // Called by other modules (payments, doubts) to push a notification whose
  // copy comes from an admin-editable NotificationTemplate row, with
  // {{variable}} placeholders in title/body substituted from `vars`.
  async pushFromTemplate(userId: string, type: string, vars: Record<string, string>) {
    const template = await this.prisma.notificationTemplate.findUnique({ where: { type } });
    if (!template) throw new NotFoundException(`Notification template '${type}' not found`);

    const render = (text: string) => text.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] ?? '');
    return this.push(userId, type, render(template.title), render(template.body));
  }

  // Called by other modules (payments, doubts) to push a notification.
  // Writes the in-app row (always), then best-effort sends a phone push too —
  // a Firebase failure or missing config never blocks the in-app notification.
  async push(userId: string, type: string, title: string, body: string) {
    const notification = await this.prisma.notification.create({ data: { userId, type, title, body } });

    const devices = await this.prisma.deviceToken.findMany({ where: { userId }, select: { token: true } });
    if (devices.length > 0) {
      const deadTokens = await this.fcm.sendToTokens(devices.map((d) => d.token), title, body);
      if (deadTokens.length > 0) {
        await this.prisma.deviceToken.deleteMany({ where: { token: { in: deadTokens } } });
      }
    }

    return notification;
  }

  async registerDevice(userId: string, token: string, platform?: string) {
    await this.prisma.deviceToken.upsert({
      where: { token },
      update: { userId, platform },
      create: { userId, token, platform },
    });
    return { registered: true };
  }

  async unregisterDevice(userId: string, token: string) {
    const device = await this.prisma.deviceToken.findUnique({ where: { token } });
    if (!device) throw new NotFoundException('Device token not found');
    if (device.userId !== userId) throw new ForbiddenException('Device token does not belong to this user');

    await this.prisma.deviceToken.delete({ where: { token } });
    return { unregistered: true };
  }

  list(userId: string, unreadOnly = false) {
    return this.prisma.notification.findMany({
      where: { userId, ...(unreadOnly ? { read: false } : {}) },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }

  async markRead(userId: string, id: string) {
    await this.prisma.notification.updateMany({ where: { id, userId }, data: { read: true } });
    return { success: true };
  }

  async markAllRead(userId: string) {
    await this.prisma.notification.updateMany({ where: { userId, read: false }, data: { read: true } });
    return { success: true };
  }

  async unreadCount(userId: string) {
    const count = await this.prisma.notification.count({ where: { userId, read: false } });
    return { unread: count };
  }
}
