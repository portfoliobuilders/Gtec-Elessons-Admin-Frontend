import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { CatalogModule } from './catalog/catalog.module';
import { AccessModule } from './access/access.module';
import { PricingModule } from './pricing/pricing.module';
import { CartModule } from './cart/cart.module';
import { PaymentsModule } from './payments/payments.module';
import { ProgressModule } from './progress/progress.module';
import { VideoModule } from './video/video.module';
import { AssessmentsModule } from './assessments/assessments.module';
import { NotificationsModule } from './notifications/notifications.module';
import { DoubtsModule } from './doubts/doubts.module';
import { LiveModule } from './live/live.module';
import { AdminModule } from './admin/admin.module';
import { SearchModule } from './search/search.module';
import { RegionsModule } from './regions/regions.module';
import { ConsoleExtrasModule } from './console-extras/console-extras.module';
import { BatchesModule } from './batches/batches.module';
import { SettingsModule } from './settings/settings.module';
import { validateEnv } from './config/env.validation';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, validate: validateEnv }),
    PrismaModule,
    AuthModule,
    UsersModule,
    AccessModule,
    CatalogModule,
    PricingModule,
    CartModule,
    PaymentsModule,
    ProgressModule,
    VideoModule,
    AssessmentsModule,
    NotificationsModule,
    DoubtsModule,
    LiveModule,
    AdminModule,
    SearchModule,
    RegionsModule,
    ConsoleExtrasModule,
    BatchesModule,
    SettingsModule,
  ],
  controllers: [AppController],
})
export class AppModule {}
