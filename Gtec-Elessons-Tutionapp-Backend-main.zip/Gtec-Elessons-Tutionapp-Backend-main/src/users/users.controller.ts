import { Body, Controller, Get, Patch, Post, Query, UploadedFile, UseGuards, UseInterceptors, BadRequestException } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { UsersService } from './users.service';
import { OnboardingDto } from './dto/onboarding.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { SetRegionDto } from './dto/set-region.dto';
import { avatarUploadOptions, kycPhotoUploadOptions } from './upload.config';

@UseGuards(JwtAuthGuard)
@Controller('me')
export class UsersController {
  constructor(private users: UsersService) {}

  @Get()
  me(@CurrentUser() user: AuthUser) {
    return this.users.me(user.id);
  }

  @Get('users')
  listUsers(
    @Query('search') search?: string,
    @Query('role') role?: string,
    @Query('take') take?: string,
    @Query('skip') skip?: string,
  ) {
    return this.users.listUsers({
      search,
      role,
      take: take ? +take : undefined,
      skip: skip ? +skip : undefined,
    });
  }

  @Get('orders')
  orders(@CurrentUser() user: AuthUser) {
    return this.users.orders(user.id);
  }

  // Pre-fills the checkout form from whatever was saved on the last order.
  @Get('checkout-details')
  checkoutDetails(@CurrentUser() user: AuthUser) {
    return this.users.getCheckoutDetails(user.id);
  }

  @Patch('profile')
  updateProfile(@CurrentUser() user: AuthUser, @Body() dto: UpdateProfileDto) {
    return this.users.updateProfile(user.id, dto);
  }

  @Patch('onboarding')
  onboard(@CurrentUser() user: AuthUser, @Body() dto: OnboardingDto) {
    return this.users.onboard(user.id, dto);
  }

  // Persists the pre-login region/currency pick once the user is authenticated.
  @Patch('region')
  setRegion(@CurrentUser() user: AuthUser, @Body() dto: SetRegionDto) {
    return this.users.setRegion(user.id, dto.countryCode);
  }

  // Profile photo. Local-disk storage for now — see upload.config.ts.
  @Post('avatar')
  @UseInterceptors(FileInterceptor('file', avatarUploadOptions))
  async uploadAvatar(@CurrentUser() user: AuthUser, @UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('No file uploaded');
    const baseUrl = (process.env.APP_BASE_URL ?? 'http://localhost:3000').replace(/\/+$/, '');
    const url = `${baseUrl}/uploads/avatars/${file.filename}`;
    return this.users.updateProfile(user.id, { avatarUrl: url });
  }

  // KYC photo — same storage approach, separate folder/field on the profile.
  @Post('kyc-photo')
  @UseInterceptors(FileInterceptor('file', kycPhotoUploadOptions))
  async uploadKycPhoto(@CurrentUser() user: AuthUser, @UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('No file uploaded');
    const baseUrl = (process.env.APP_BASE_URL ?? 'http://localhost:3000').replace(/\/+$/, '');
    const url = `${baseUrl}/uploads/kyc/${file.filename}`;
    return this.users.updateProfile(user.id, { photoUrl: url });
  }
}
