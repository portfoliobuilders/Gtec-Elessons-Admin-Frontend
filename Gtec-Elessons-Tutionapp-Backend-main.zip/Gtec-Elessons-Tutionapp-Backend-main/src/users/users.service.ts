import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CurrencyService } from '../regions/currency.service';
import { OnboardingDto } from './dto/onboarding.dto';

@Injectable()
export class UsersService {
  constructor(
    private prisma: PrismaService,
    private currency: CurrencyService,
  ) {}

  async listUsers(filter: { search?: string; role?: string; take?: number; skip?: number } = {}) {
    const allowedRoles = ['STUDENT', 'TEACHER', 'ADMIN', 'SUPER_ADMIN'];
    const take = Number.isFinite(filter.take) ? Math.min(Math.max(filter.take!, 1), 100) : 50;
    const skip = Number.isFinite(filter.skip) ? Math.max(filter.skip!, 0) : 0;
    const role = filter.role?.toUpperCase();

    if (role && !allowedRoles.includes(role)) {
      throw new BadRequestException('Invalid role');
    }

    const where: any = {
      status: 'ACTIVE',
      ...(role ? { role } : {}),
    };
    if (filter.search) {
      where.OR = [
        { name: { contains: filter.search, mode: 'insensitive' } },
        { email: { contains: filter.search, mode: 'insensitive' } },
      ];
    }

    const [total, users] = await Promise.all([
      this.prisma.user.count({ where }),
      this.prisma.user.findMany({
        where,
        take,
        skip,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          name: true,
          email: true,
          avatarUrl: true,
          role: true,
          createdAt: true,
          studentProfile: {
            select: {
              board: true,
              grade: { select: { id: true, name: true } },
            },
          },
        },
      }),
    ]);

    return { total, users };
  }

  async me(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { studentProfile: { include: { grade: true } } },
    });
    if (!user) throw new NotFoundException('User not found');
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      avatarUrl: user.avatarUrl,
      role: user.role,
      profile: user.studentProfile,
    };
  }

  async onboard(userId: string, dto: OnboardingDto) {
    const grade = await this.prisma.grade.findUnique({ where: { id: dto.gradeId } });
    if (!grade) throw new NotFoundException('Grade not found');

    // Validate region against the real Country table, same as setRegion()
    // below — dto.region/dto.currency used to be written straight from
    // client input, unvalidated. That's how a ProductPrice ended up seeded
    // with the never-configured region "GCC" instead of the real country
    // code "AE". currency is now always resolved server-side from the
    // matched Country row (dto.currency is ignored), the same way `board`
    // is already pinned to 'CBSE' regardless of what the client sends.
    const countries = await this.currency.countries();
    const country = countries.find((c) => c.code === dto.region.toUpperCase());
    if (!country) throw new BadRequestException('Unsupported region code');

    if (dto.name) {
      await this.prisma.user.update({ where: { id: userId }, data: { name: dto.name } });
    }

    return this.prisma.studentProfile.upsert({
      where: { userId },
      update: {
        region: country.code,
        currency: country.currency,
        board: 'CBSE',
        gradeId: dto.gradeId,
        onboarded: true,
      },
      create: {
        userId,
        region: country.code,
        currency: country.currency,
        board: 'CBSE',
        gradeId: dto.gradeId,
        onboarded: true,
      },
    });
  }

  // Persists the country picked on the pre-login region screen so it sticks
  // across sessions — the app only needs to send the country code; the
  // matching currency is resolved server-side from the same list as /regions.
  async setRegion(userId: string, countryCode: string) {
    const countries = await this.currency.countries();
    const country = countries.find((c) => c.code === countryCode.toUpperCase());
    if (!country) throw new BadRequestException('Unsupported country code');

    await this.prisma.studentProfile.upsert({
      where: { userId },
      update: { region: country.code, currency: country.currency },
      create: { userId, region: country.code, currency: country.currency },
    });
    return this.me(userId);
  }

  // Pre-fills the checkout form from whatever was saved last time.
  async getCheckoutDetails(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { studentProfile: true },
    });
    const profile = user?.studentProfile;
    return {
      name: user?.name ?? null,
      phone: user?.phone ?? null,
      addressLine: profile?.addressLine ?? null,
      city: profile?.city ?? null,
      state: profile?.state ?? null,
      pincode: profile?.pincode ?? null,
    };
  }

  // Purchase history for the Profile screen.
  async orders(userId: string) {
    return this.prisma.order.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      include: { items: true },
    });
  }

  async updateProfile(userId: string, dto: any) {
    const userData: any = {};
    if (dto.name !== undefined) userData.name = dto.name;
    if (dto.phone !== undefined) userData.phone = dto.phone;
    if (dto.avatarUrl !== undefined) userData.avatarUrl = dto.avatarUrl;
    if (Object.keys(userData).length) {
      await this.prisma.user.update({ where: { id: userId }, data: userData });
    }

    const profileData: any = {};
    for (const f of ['photoUrl', 'gender', 'addressLine', 'city', 'state', 'pincode', 'parentName', 'parentPhone']) {
      if (dto[f] !== undefined) profileData[f] = dto[f];
    }
    if (dto.dob !== undefined) profileData.dob = new Date(dto.dob);

    const merged = await this.prisma.studentProfile.upsert({
      where: { userId },
      update: profileData,
      create: { userId, ...profileData },
    });
    const kycComplete = !!(merged.dob && merged.addressLine && merged.pincode && merged.parentPhone);
    if (kycComplete !== merged.kycComplete) {
      await this.prisma.studentProfile.update({ where: { userId }, data: { kycComplete } });
    }

    return this.me(userId);
  }

}
