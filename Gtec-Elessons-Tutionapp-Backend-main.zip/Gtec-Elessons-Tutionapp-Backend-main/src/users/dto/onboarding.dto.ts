import { IsOptional, IsString } from 'class-validator';

export class OnboardingDto {
  // Country code from GET /api/regions (e.g. "IN", "AE", "US") — no longer a
  // fixed enum since the region list is backend-driven and covers 20+ countries.
  // Validated server-side against the Country table in UsersService.onboard()
  // (mirrors setRegion()) — an unrecognized code is rejected with 400 rather
  // than written through as-is.
  @IsString()
  region: string;

  // Kept optional (rather than removed) so clients still sending this field
  // don't get rejected by the whitelist validator. The value is ignored — the
  // service always resolves currency server-side from the Country row
  // matching `region`, same treatment as `board` below.
  @IsOptional()
  @IsString()
  currency?: string;

  // G-TEC only offers CBSE — kept optional (rather than removed) so clients
  // still sending this field from before the board picker was dropped don't
  // get rejected by the whitelist validator. The value is ignored; the
  // service always saves 'CBSE'.
  @IsOptional()
  @IsString()
  board?: string;

  @IsString()
  gradeId: string;

  @IsOptional()
  @IsString()
  name?: string;
}
