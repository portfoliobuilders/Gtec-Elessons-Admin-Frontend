import { IsString, Length } from 'class-validator';

export class SetRegionDto {
  // Country code from GET /api/regions, e.g. "AE". The server resolves the
  // matching currency — the app never needs to know the mapping itself.
  @IsString()
  @Length(2, 2)
  countryCode: string;
}
