import { BadRequestException } from '@nestjs/common';
import { diskStorage } from 'multer';
import { extname, join } from 'path';
import { randomBytes } from 'crypto';
import { mkdirSync } from 'fs';
import { MAX_UPLOAD_FILE_SIZE_BYTES } from '../common/utils/upload-limits';

// Local-disk storage — a stopgap until a real object store (S3/R2/Supabase)
// replaces it. Swapping later only changes these two functions and the URL
// building in users.controller.ts; nothing else in the app needs to change.
const imageFileFilter = (_req: any, file: Express.Multer.File, cb: (error: Error | null, accept: boolean) => void) => {
  if (!/^image\/(jpeg|png|webp)$/.test(file.mimetype)) {
    return cb(new BadRequestException('Only JPEG, PNG, or WEBP images are allowed'), false);
  }
  cb(null, true);
};

function storageFor(subfolder: 'avatars' | 'kyc') {
  const uploadDir = join(process.cwd(), 'uploads', subfolder);
  mkdirSync(uploadDir, { recursive: true });
  return diskStorage({
    destination: uploadDir,
    filename: (req: any, file, cb) => {
      const userId = req.user?.id ?? 'unknown';
      const unique = randomBytes(8).toString('hex');
      cb(null, `${userId}-${unique}${extname(file.originalname)}`);
    },
  });
}

export const avatarUploadOptions = {
  storage: storageFor('avatars'),
  fileFilter: imageFileFilter,
  limits: { fileSize: MAX_UPLOAD_FILE_SIZE_BYTES },
};

export const kycPhotoUploadOptions = {
  storage: storageFor('kyc'),
  fileFilter: imageFileFilter,
  limits: { fileSize: MAX_UPLOAD_FILE_SIZE_BYTES },
};
