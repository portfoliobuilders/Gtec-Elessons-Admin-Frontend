import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';
import { DoubtsService } from './doubts.service';
import { AskDoubtDto, AnswerDoubtDto } from './dto/doubt.dto';

@UseGuards(JwtAuthGuard)
@Controller()
export class DoubtsController {
  constructor(private svc: DoubtsService) {}

  // ---- Student ----
  @Post('doubts')
  ask(@CurrentUser() user: AuthUser, @Body() dto: AskDoubtDto) {
    return this.svc.ask(user.id, dto.lessonId, dto.question);
  }

  @Get('me/doubts')
  mine(@CurrentUser() user: AuthUser) {
    return this.svc.myDoubts(user.id);
  }

  @Get('lessons/:lessonId/doubts')
  forLesson(@CurrentUser() user: AuthUser, @Param('lessonId') lessonId: string) {
    return this.svc.forLesson(user.id, lessonId);
  }

  @Post('doubts/:id/helpful')
  helpful(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.toggleHelpful(user.id, id);
  }

  // ---- Teacher / Admin ----
  @UseGuards(RolesGuard)
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Get('teacher/doubts')
  inbox(@CurrentUser() user: AuthUser, @Query('status') status?: 'OPEN' | 'ANSWERED') {
    return this.svc.teacherInbox(status, user);
  }

  @UseGuards(RolesGuard)
  @Roles('TEACHER', 'ADMIN', 'SUPER_ADMIN')
  @Post('teacher/doubts/:id/answer')
  answer(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() dto: AnswerDoubtDto) {
    return this.svc.answer(user, id, dto.answer);
  }
}
