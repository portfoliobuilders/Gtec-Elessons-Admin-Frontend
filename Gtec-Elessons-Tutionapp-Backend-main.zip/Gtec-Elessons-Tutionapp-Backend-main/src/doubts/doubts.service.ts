import {
  Injectable, NotFoundException, ForbiddenException, BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AccessService } from '../access/access.service';
import { NotificationsService } from '../notifications/notifications.service';

interface Requester {
  id: string;
  role: string;
}

@Injectable()
export class DoubtsService {
  constructor(
    private prisma: PrismaService,
    private access: AccessService,
    private notifications: NotificationsService,
  ) {}

  // Student asks a doubt on a lesson they have access to.
  async ask(userId: string, lessonId: string, question: string) {
    const ok = await this.access.canAccessLesson(userId, lessonId);
    if (!ok) throw new ForbiddenException('You have not purchased access to this lesson');
    return this.prisma.doubt.create({
      data: { studentId: userId, lessonId, question, status: 'OPEN' },
    });
  }

  myDoubts(userId: string) {
    return this.prisma.doubt.findMany({
      where: { studentId: userId },
      orderBy: { createdAt: 'desc' },
      include: {
        lesson: { select: { title: true } },
        teacher: { select: { name: true } },
        _count: { select: { helpful: true } },
      },
    });
  }

  // Answered doubts on a lesson, visible to any student with access (peer learning).
  async forLesson(userId: string, lessonId: string) {
    const ok = await this.access.canAccessLesson(userId, lessonId);
    if (!ok) throw new ForbiddenException('You have not purchased access to this lesson');
    return this.prisma.doubt.findMany({
      where: { lessonId, status: 'ANSWERED' },
      orderBy: { answeredAt: 'desc' },
      include: {
        student: { select: { name: true } },
        teacher: { select: { name: true } },
        _count: { select: { helpful: true } },
      },
    });
  }

  // Toggle a "helpful" vote (one per user per doubt).
  async toggleHelpful(userId: string, doubtId: string) {
    const existing = await this.prisma.doubtHelpful.findUnique({
      where: { doubtId_userId: { doubtId, userId } },
    });
    if (existing) {
      await this.prisma.doubtHelpful.delete({ where: { id: existing.id } });
    } else {
      await this.prisma.doubtHelpful.create({ data: { doubtId, userId } });
    }
    const count = await this.prisma.doubtHelpful.count({ where: { doubtId } });
    return { helpful: !existing, helpfulCount: count };
  }

  // ---- Teacher/Admin ----
  // TEACHER sees only doubts on lessons under a subject they teach;
  // ADMIN/SUPER_ADMIN gets the full unfiltered inbox, as before.
  teacherInbox(status?: 'OPEN' | 'ANSWERED', requester?: Requester) {
    const teacherId = requester?.role === 'TEACHER' ? requester.id : undefined;
    return this.prisma.doubt.findMany({
      where: {
        ...(status ? { status } : {}),
        ...(teacherId ? { lesson: { chapter: { subject: { teacherId } } } } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: {
        student: { select: { name: true, email: true } },
        lesson: {
          select: {
            title: true,
            chapter: { select: { name: true, subject: { select: { name: true } } } },
          },
        },
      },
    });
  }

  async answer(requester: Requester, doubtId: string, answer: string) {
    const doubt = await this.prisma.doubt.findUnique({
      where: { id: doubtId },
      include: { lesson: { select: { chapter: { select: { subject: { select: { teacherId: true } } } } } } },
    });
    if (!doubt) throw new NotFoundException('Doubt not found');
    if (doubt.status === 'ANSWERED') throw new BadRequestException('Already answered');
    if (requester.role === 'TEACHER' && doubt.lesson?.chapter.subject.teacherId !== requester.id) {
      throw new ForbiddenException('You can only answer doubts for subjects you teach');
    }

    const updated = await this.prisma.doubt.update({
      where: { id: doubtId },
      data: { answer, teacherId: requester.id, status: 'ANSWERED', answeredAt: new Date() },
    });

    // Notify the student their doubt was answered.
    const answerPreview = answer.length > 90 ? answer.slice(0, 90) + '…' : answer;
    await this.notifications.pushFromTemplate(doubt.studentId, 'DOUBT_ANSWERED', { answer: answerPreview });

    return updated;
  }
}
