import { IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class AskDoubtDto {
  @IsString() lessonId: string;
  @IsString() @MinLength(5) @MaxLength(1000) question: string;
}

export class AnswerDoubtDto {
  @IsString() @MinLength(2) @MaxLength(2000) answer: string;
}
