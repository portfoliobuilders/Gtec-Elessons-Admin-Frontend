## Admin Panel
The official admin panel lives at:
  C:\Users\parva\Downloads\gtec-admin-console-nextjs\gtec-admin-next

Stack: Next.js 16, React 19, Tailwind v4, TypeScript.
Runs on :3001 (backend runs on :3000 — don't let them collide).
Built by reading this backend's actual admin services directly — not
guessed. Verified end-to-end with Playwright: dev-login, dashboard, all
12 sidebar pages, assessment creation with negative marking/shuffle.

Any earlier admin panel builds (an HTML single-file version, or a Next.js
14 zip) are DEPRECATED — do not resurrect or merge from them. This is
the only one in use.

When adding backend features that the admin panel needs, update the
panel in the path above to match — don't let them drift again.

## API Reference
Full endpoint map (all 17 controllers, 169 routes, grouped by
Public/Optional-auth/Any-authenticated/Teacher-accessible/Admin-only
tier, organized by controller file, with search + tier filtering):
  https://claude.ai/code/artifact/5be2b2ad-2fbc-479e-9000-4cd2d61dc8e4

All routes are under the `/api` global prefix (set in `main.ts`). Keep
this updated when controllers change — it's the source both this repo
and the admin panel should check before assuming a route's shape. Last
rebuilt from source 2026-08-11 (was previously stale at 147 routes from
2026-07-15; the three access-bug flags from that rebuild are now fixed
in source — see the artifact's own Flags panel). One flag is still
open: `GET /api/me/users` has no role guard — any authenticated user,
including a plain student, can list/search every user in the system.
