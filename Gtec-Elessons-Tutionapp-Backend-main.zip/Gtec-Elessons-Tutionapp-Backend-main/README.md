# G-TEC e-Lessons — Backend (Day 1 scaffold)

NestJS + Prisma + PostgreSQL. This is the **Day 1** cut from the 3-day plan: Google auth, onboarding, catalog browsing, the 3-tier product model, and the **access-gating service** that decides whether a user can watch a given lesson. Cart/Stripe and Mux video are Day 2.

## Prerequisites
- Node 18+ and npm
- A PostgreSQL database (local Docker, Neon, or Supabase)
- A Google OAuth client ID (for verifying the ID token your Flutter app sends)

## Setup

```bash
cp .env.example .env          # then fill in DATABASE_URL, JWT secrets, GOOGLE_CLIENT_ID
npm install
npm run prisma:generate
npm run prisma:migrate        # creates the tables (name it e.g. "init")
npm run prisma:seed           # loads Class 10 CBSE content + 3-tier products
npm run start:dev             # http://localhost:3000/api
```

## What works today

| Method | Route | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/google` | public | Verify Google ID token → returns `{ accessToken, refreshToken, user }` |
| POST | `/api/auth/refresh` | public | Rotate tokens |
| POST | `/api/auth/logout` | public | Revoke a refresh token |
| GET  | `/api/me` | bearer | Current user + profile |
| PATCH| `/api/me/onboarding` | bearer | Save region/currency/board/grade |
| GET  | `/api/grades?board=CBSE` | public | List grades |
| GET  | `/api/grades/:id` | public | Grade + subjects + products |
| GET  | `/api/subjects/:id` | public | Subject + chapters + products |
| GET  | `/api/chapters/:id` | public | Chapter + lessons + products |
| GET  | `/api/lessons/:id` | bearer | Lesson detail — **`playbackId`/resources only if the user has access** |

The lesson endpoint returns `locked: true` and null playback when the user hasn't purchased coverage — that's the access gate working. The first lesson of Mathematics → Real Numbers is seeded as a **free preview** so you can test the unlocked path without buying anything.

## The piece that matters most
`src/access/access.service.ts` → `canAccessLesson(userId, lessonId)`. It walks lesson → chapter → subject → grade and checks for an ACTIVE, non-expired enrollment at any of the three tiers (FULL_CLASS / SUBJECT / MODULE). Reuse it for downloads and assessments later. To test gating before Stripe exists, insert an `Enrollment` row by hand (e.g. a SUBJECT enrollment for Science) and watch a Science lesson unlock.

## Day 2 (next)
- `cart` + `pricing` modules: add/remove items, `/cart/quote` (subtotal + flat 18% GST for now).
- `payments` module: Stripe Checkout session + `/webhooks/stripe` → grant one Enrollment per OrderItem (`expiresAt = now + accessDays`).
- `video` module: Mux direct-upload URL + signed playback token, swapped into the lesson endpoint behind `LessonAccessGuard`.

## Day 3
- `progress` (post progress + my-learnings list), end-to-end testing, then pull in promo codes or per-course progress %.

## Notes
- Single currency (INR) and flat GST are intentional for this build. The `ProductPrice` table already supports multi-currency — it's a data change later, not a migration.
- Deferred models (coupons, assessments, streaks, doubts, reviews, teacher/admin) are documented in the full plan and intentionally not in this schema yet.
