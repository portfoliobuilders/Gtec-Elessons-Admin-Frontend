// Focused tests for the shared YouTube id/URL parser (src/common/utils/youtube.util.ts)
// and the lesson-video / grade / subject / chapter trailer endpoints that use it.
//
// Part A: pure unit tests of parseYouTubeId() — no DB, no HTTP.
// Part B: HTTP integration tests against the real running app (localhost:3000),
// using a throwaway Grade -> Subject -> Chapter -> Lesson tree created and
// deleted by this script — real seed/production content is never touched.
//
// Run: npx ts-node scripts/verify_youtube_id_parsing.ts
// Requires: dev server running on :3000, ALLOW_DEV_LOGIN=true, an existing
// admin@gtec.dev SUPER_ADMIN account (dev-login only, no new user created).
import { parseYouTubeId } from '../src/common/utils/youtube.util';

const BASE = 'http://localhost:3000/api';
const ID = 'xvT1jH8B9AM';

let pass = 0;
let fail = 0;
function ok(desc: string, cond: boolean, detail?: unknown) {
  if (cond) { pass++; console.log(`  OK    ${desc}`); }
  else { fail++; console.error(`  FAIL  ${desc}`, detail !== undefined ? detail : ''); }
}

async function api(path: string, opts: { method?: string; body?: unknown; token?: string } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method: opts.method ?? 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(opts.token ? { Authorization: `Bearer ${opts.token}` } : {}),
    },
    ...(opts.body !== undefined ? { body: JSON.stringify(opts.body) } : {}),
  });
  const text = await res.text();
  let body: any;
  try { body = JSON.parse(text); } catch { body = text; }
  return { status: res.status, body };
}

async function main() {
  console.log('--- Part A: parseYouTubeId() unit tests (1-9) ---');
  ok('1. raw id', parseYouTubeId(ID) === ID);
  ok('2. youtu.be', parseYouTubeId(`https://youtu.be/${ID}`) === ID);
  ok('3. youtu.be + query (?si=...)', parseYouTubeId(`https://youtu.be/${ID}?si=vYM5DkFKHgxYiXDR`) === ID);
  ok('4. watch?v=', parseYouTubeId(`https://www.youtube.com/watch?v=${ID}`) === ID);
  ok('4b. watch?v= without www', parseYouTubeId(`https://youtube.com/watch?v=${ID}`) === ID);
  ok('5. embed/', parseYouTubeId(`https://www.youtube.com/embed/${ID}`) === ID);
  ok('6. shorts/', parseYouTubeId(`https://www.youtube.com/shorts/${ID}`) === ID);
  ok('7. live/', parseYouTubeId(`https://www.youtube.com/live/${ID}`) === ID);
  ok('8. invalid URL (non-YouTube host)', parseYouTubeId('https://example.com/video/123') === null);
  ok('8b. not-a-youtube-url', parseYouTubeId('not-a-youtube-url') === null);
  ok('8c. bare 5-digit not a URL', parseYouTubeId('12345') === null);
  ok('8d. youtu.be/invalid (wrong-length id)', parseYouTubeId('https://youtu.be/invalid') === null);
  ok('9. invalid id (12 chars)', parseYouTubeId('abcdefghijkl') === null);
  ok('9b. undefined input', parseYouTubeId(undefined) === null);

  console.log('\n--- Part B: HTTP integration tests (10-13) ---');
  const login = await api('/auth/dev-login', { method: 'POST', body: { email: 'admin@gtec.dev' } });
  ok('admin dev-login', login.status === 201 && login.body.user?.role === 'SUPER_ADMIN', login);
  const token = login.body.accessToken;

  const suffix = Date.now();
  let gradeId: string | undefined;
  let subjectId: string | undefined;
  let chapterId: string | undefined;
  let lessonId: string | undefined;

  try {
    // Throwaway tree.
    const gradeRes = await api('/admin/grades', { method: 'POST', token, body: { name: `YT util test grade ${suffix}` } });
    ok('create throwaway grade', gradeRes.status === 201, gradeRes);
    gradeId = gradeRes.body.id;

    const subjectRes = await api(`/admin/grades/${gradeId}/subjects`, { method: 'POST', token, body: { name: `YT util test subject ${suffix}` } });
    ok('create throwaway subject', subjectRes.status === 201, subjectRes);
    subjectId = subjectRes.body.id;

    const chapterRes = await api(`/admin/subjects/${subjectId}/chapters`, { method: 'POST', token, body: { name: `YT util test chapter ${suffix}` } });
    ok('create throwaway chapter', chapterRes.status === 201, chapterRes);
    chapterId = chapterRes.body.id;

    const lessonRes = await api(`/admin/chapters/${chapterId}/lessons`, { method: 'POST', token, body: { title: `YT util test lesson ${suffix}` } });
    ok('create throwaway lesson', lessonRes.status === 201, lessonRes);
    lessonId = lessonRes.body.id;

    // 10. Grade trailer: create with bare id, then update with a full URL.
    const gradeTrailer1 = await api(`/admin/grades/${gradeId}/trailer`, { method: 'POST', token, body: { youtubeId: ID } });
    ok('10a. grade trailer create (bare id)', gradeTrailer1.status === 201 && gradeTrailer1.body.youtubeId === ID, gradeTrailer1);
    const gradeTrailer2 = await api(`/admin/grades/${gradeId}/trailer`, { method: 'POST', token, body: { youtubeId: `https://youtu.be/${ID}?si=abc` } });
    ok('10b. grade trailer update (full URL)', gradeTrailer2.status === 201 && gradeTrailer2.body.youtubeId === ID, gradeTrailer2);

    // 11. Subject trailer: create with a watch URL, then update with a bare id.
    const subjectTrailer1 = await api(`/admin/subjects/${subjectId}/trailer`, { method: 'POST', token, body: { youtubeId: `https://www.youtube.com/watch?v=${ID}` } });
    ok('11a. subject trailer create (watch URL)', subjectTrailer1.status === 201 && subjectTrailer1.body.youtubeId === ID, subjectTrailer1);
    const subjectTrailer2 = await api(`/admin/subjects/${subjectId}/trailer`, { method: 'POST', token, body: { youtubeId: ID } });
    ok('11b. subject trailer update (bare id)', subjectTrailer2.status === 201 && subjectTrailer2.body.youtubeId === ID, subjectTrailer2);

    // 12. Chapter trailer: create with a shorts URL, then update with a live URL.
    const chapterTrailer1 = await api(`/admin/chapters/${chapterId}/trailer`, { method: 'POST', token, body: { youtubeId: `https://www.youtube.com/shorts/${ID}` } });
    ok('12a. chapter trailer create (shorts URL)', chapterTrailer1.status === 201 && chapterTrailer1.body.youtubeId === ID, chapterTrailer1);
    const chapterTrailer2 = await api(`/admin/chapters/${chapterId}/trailer`, { method: 'POST', token, body: { youtubeId: `https://www.youtube.com/live/${ID}` } });
    ok('12b. chapter trailer update (live URL)', chapterTrailer2.status === 201 && chapterTrailer2.body.youtubeId === ID, chapterTrailer2);

    // 13. Lesson video endpoint: bare id, then a youtu.be URL with query string.
    const video1 = await api(`/admin/lessons/${lessonId}/video`, { method: 'POST', token, body: { youtubeId: ID } });
    ok('13a. lesson video (bare id)', video1.status === 201 && video1.body.youtubeId === ID, video1);
    const video2 = await api(`/admin/lessons/${lessonId}/video`, { method: 'POST', token, body: { youtubeId: `https://youtu.be/${ID}?si=xyz` } });
    ok('13b. lesson video (youtu.be URL + query)', video2.status === 201 && video2.body.youtubeId === ID, video2);

    // Error path: invalid input -> 400 with the expected message, on the real endpoint.
    const badVideo = await api(`/admin/lessons/${lessonId}/video`, { method: 'POST', token, body: { youtubeId: 'https://example.com/video/123' } });
    ok('invalid input on lesson video -> 400', badVideo.status === 400 && /valid YouTube video ID or YouTube URL/.test(badVideo.body.message), badVideo);

    console.log(`\n${pass} passed, ${fail} failed`);
    if (fail > 0) process.exitCode = 1;
  } finally {
    console.log('\n--- cleanup ---');
    // deleteSubject cascades chapters/lessons/products; deleteGrade requires
    // no subjects left, so subject goes first.
    if (subjectId) {
      const del = await api(`/admin/subjects/${subjectId}`, { method: 'DELETE', token });
      console.log('deleted subject (cascades chapter+lesson):', del.status);
    }
    if (gradeId) {
      const del = await api(`/admin/grades/${gradeId}`, { method: 'DELETE', token });
      console.log('deleted grade:', del.status);
    }
  }
}

main().catch((e) => { console.error('Unhandled error:', e); process.exitCode = 1; });
