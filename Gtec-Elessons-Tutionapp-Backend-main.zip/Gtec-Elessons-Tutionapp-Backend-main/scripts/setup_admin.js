const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const user = await prisma.user.upsert({
    where: { email: 'admin@gtec.dev' },
    update: { role: 'ADMIN' },
    create: { email: 'admin@gtec.dev', name: 'Admin User', role: 'ADMIN' },
  });
  console.log('Admin user status:', user.email, user.role);
  await prisma.$disconnect();
}

main().catch(err => {
  console.error(err);
  prisma.$disconnect();
  
  process.exit(1);
});
