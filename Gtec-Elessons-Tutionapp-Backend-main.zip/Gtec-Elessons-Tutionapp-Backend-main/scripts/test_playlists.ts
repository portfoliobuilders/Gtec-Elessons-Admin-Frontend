import fetch from 'node-fetch';

const playlists = [
  'https://www.youtube.com/playlist?list=PLV4HVfstZAMw',
  'https://www.youtube.com/playlist?list=PLNsVNHOlyj6U',
  'https://www.youtube.com/playlist?list=PLAZIZ5WdedIY',
];

async function checkPlaylists() {
  for (const url of playlists) {
    try {
      const res = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
      });
      console.log(`URL: ${url}`);
      console.log(`Status: ${res.status} ${res.statusText}`);
      const text = await res.text();
      const is404 = text.includes('This playlist does not exist') || text.includes('Playlist unavailable') || res.status === 404;
      console.log(`Is 404 / Unavailable: ${is404}`);
      if (!is404) {
        // Extract video IDs if present
        const videoIdMatches = text.match(/\/watch\?v=([a-zA-Z0-9_-]{11})/g);
        console.log(`Found video matches:`, videoIdMatches?.slice(0, 5));
      }
    } catch (err: any) {
      console.log(`URL: ${url} -> Error: ${err.message}`);
    }
    console.log('---');
  }
}

checkPlaylists();
