const https = require('https');

https.get('https://www.youtube.com/watch?v=bwmBKf-7sYA', {
  headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
}, (res) => {
  let d = '';
  res.on('data', c => d += c);
  res.on('end', () => {
    const og = d.match(/<meta property="og:title" content="([^"]+)"/);
    const ch = d.match(/"ownerChannelName":"([^"]+)"/);
    const cat = d.match(/"category":"([^"]+)"/);
    console.log('Video ID: bwmBKf-7sYA');
    console.log('Title:', og ? og[1] : 'not found');
    console.log('Channel:', ch ? ch[1] : 'not found');
    console.log('Category:', cat ? cat[1] : 'not found');
  });
});
