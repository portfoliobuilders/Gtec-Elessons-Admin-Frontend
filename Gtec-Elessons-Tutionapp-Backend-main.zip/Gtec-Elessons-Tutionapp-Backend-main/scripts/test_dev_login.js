import http from 'http';

function makeRequest(email) {
  return new Promise((resolve) => {
    const data = JSON.stringify({ email });

    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/api/auth/dev-login',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
      }
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        resolve({
          email,
          status: res.statusCode,
          headers: res.headers,
          body
        });
      });
    });

    req.on('error', (e) => {
      resolve({ email, error: e.message });
    });

    req.write(data);
    req.end();
  });
}

async function run() {
  const result1 = await makeRequest('admin@gtec.dev');
  console.log('=== admin@gtec.dev ===');
  console.log('STATUS:', result1.status);
  console.log('BODY:', result1.body);

  const result2 = await makeRequest('teacher@gtec.dev');
  console.log('=== teacher@gtec.dev ===');
  console.log('STATUS:', result2.status);
  console.log('BODY:', result2.body);
}

run();
