import { PrismaClient, ProductType, ProductFormat } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('=== ACCOUNTANCY FIX: Moving from Plus One → Plus Two ===');
  console.log('Video bwmBKf-7sYA: "Accounting for Share Capital | Exercise 18 | Part 1"');
  console.log('→ Share Capital is Class 12 CBSE Accountancy — confirmed belongs in Plus Two.\n');

  // 1. Move subject from seed-grade-plus-one → seed-grade-plus-two
  const updatedSubject = await prisma.subject.update({
    where: { id: 'seed-subject-plus-one-accountancy' },
    data: {
      gradeId: 'seed-grade-plus-two',
      // Rename the id is not possible in Prisma, but we can note the logical name
      // We keep the id as-is; the gradeId is what determines the catalog placement
    }
  });
  console.log(`✅ Subject moved: ${updatedSubject.id} → gradeId: ${updatedSubject.gradeId}`);

  // 2. Move product to point to same subject (product still points to subjectId, unaffected)
  // Product already references subjectId, not gradeId, so no change needed for subject products
  const product = await prisma.product.findUnique({ where: { id: 'seed-product-plus-one-accountancy' } });
  if (product) {
    console.log(`✅ Product seed-product-plus-one-accountancy still points to subject ${product.subjectId} (correct — subject was moved)`);
  }

  // 3. Verify the final state of both grades
  console.log('\n=== VERIFICATION: Grade curriculum after fix ===');
  for (const gradeId of ['seed-grade-plus-one', 'seed-grade-plus-two']) {
    const grade = await prisma.grade.findUnique({
      where: { id: gradeId },
      include: {
        subjects: {
          include: {
            chapters: {
              include: {
                lessons: { select: { id: true, title: true, youtubeId: true } }
              }
            }
          },
          orderBy: { order: 'asc' }
        }
      }
    });
    if (!grade) continue;
    console.log(`\nGrade: "${grade.name}" (${grade.id})`);
    for (const sub of grade.subjects) {
      console.log(`  Subject: ${sub.name} [${sub.code ?? '—'}] (${sub.id})`);
      for (const ch of sub.chapters) {
        console.log(`    Chapter: "${ch.name}"`);
        for (const l of ch.lessons) {
          console.log(`      Lesson: "${l.title}" | youtubeId: ${l.youtubeId}`);
        }
      }
    }
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
