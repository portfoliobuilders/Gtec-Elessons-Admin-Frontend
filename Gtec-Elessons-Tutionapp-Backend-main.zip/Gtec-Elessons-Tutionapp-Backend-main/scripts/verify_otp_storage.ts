// Throwaway inspection script for the OTP fix verification — reads the
// EmailOtp row(s) directly to prove codeHash is not the plaintext code.
// Run: npx ts-node scripts/verify_otp_storage.ts <email>
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const email = process.argv[2];
  if (!email) throw new Error('Usage: ts-node scripts/verify_otp_storage.ts <email>');
  const rows = await prisma.emailOtp.findMany({
    where: { email },
    orderBy: { createdAt: 'desc' },
    take: 5,
  });
  console.log(JSON.stringify(rows, null, 2));
}

main().finally(() => prisma.$disconnect());
