import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const users = await prisma.user.findMany({
    where: {
      email: {
        in: ['teacher@gtec.dev', 'admin@gtec.dev', 'teststudent99@gmail.com']
      }
    },
    select: {
      id: true,
      email: true,
      role: true,
      status: true
    }
  });
  console.log('=== USERS ===');
  console.log(JSON.stringify(users, null, 2));
}

main()
  .then(() => prisma.$disconnect())
  .catch(e => {
    console.error(e);
    prisma.$disconnect();
    process.exit(1);
  });
