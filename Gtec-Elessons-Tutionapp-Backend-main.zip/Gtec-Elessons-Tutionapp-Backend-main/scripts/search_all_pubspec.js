const fs = require('fs');
const path = require('path');

const targetId = 'cmrxcvacv000fz7rscix9glj0';
const matches = [];

function search(dir, depth = 0) {
  if (depth > 6) return;
  try {
    const items = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of items) {
      if (item.name.startsWith('$') || item.name === 'Windows' || item.name === 'Program Files' || item.name === 'Program Files (x86)' || item.name === 'ProgramData' || item.name === '.git' || item.name === 'node_modules' || item.name === 'flutter' || item.name === 'AppData') continue;
      const p = path.join(dir, item.name);
      if (item.isFile()) {
        if (item.name.endsWith('.dart') || item.name.endsWith('.js') || item.name.endsWith('.ts') || item.name.endsWith('.json')) {
          try {
            const content = fs.readFileSync(p, 'utf8');
            if (content.includes(targetId) || content.includes('cmryistby000bej54gx5dzvj7') || content.includes('cmryj8lnn001tej54d1gzvdmj')) {
              matches.push(p);
            }
          } catch (e) {}
        }
      } else if (item.isDirectory()) {
        search(p, depth + 1);
      }
    }
  } catch (e) {}
}

console.log('Searching C:\\ for old lesson IDs in files...');
search('C:\\Users\\parva');
search('C:\\dev');
search('C:\\Apps');
search('C:\\StrapiProjects');
search('C:\\home');

console.log('Matches:', matches);
