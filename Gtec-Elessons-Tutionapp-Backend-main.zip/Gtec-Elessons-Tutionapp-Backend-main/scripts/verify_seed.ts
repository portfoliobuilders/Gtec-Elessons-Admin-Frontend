import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const student = await prisma.user.findUnique({
    where: { email: 'teststudent99@gmail.com' },
    select: { id: true },
  });
  if (!student) { console.log('STUDENT NOT FOUND'); return; }

  // 1. Enrollment still intact?
  const enrollments = await prisma.enrollment.findMany({
    where: { userId: student.id },
    select: { scopeType: true, status: true, gradeId: true, expiresAt: true },
  });
  console.log('=== ENROLLMENT ===');
  console.log(JSON.stringify(enrollments, null, 2));

  // 2. Subjects in Grade VIII
  const subjects = await prisma.subject.findMany({
    where: { grade: { name: 'Grade VIII' } },
    orderBy: { order: 'asc' },
    select: { id: true, name: true, code: true },
  });
  console.log('\n=== GRADE VIII SUBJECTS ===');
  console.log(JSON.stringify(subjects, null, 2));

  // 3. All lessons in Grade VIII (check no orphan "Types of Climate Zones" or old content)
  const lessons = await prisma.lesson.findMany({
    where: { chapter: { subject: { grade: { name: 'Grade VIII' } } } },
    select: {
      id: true, title: true, isFreePreview: true, isPublished: true,
      chapter: { select: { name: true, subject: { select: { name: true, code: true } } } },
    },
  });
  console.log('\n=== ALL GRADE VIII LESSONS ===');
  console.log(JSON.stringify(lessons, null, 2));

  // 4. Simulate /me/learnings
  const scopes = await (async () => {
    const e = await prisma.enrollment.findMany({
      where: { userId: student.id, status: 'ACTIVE', OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] },
      select: { scopeType: true, gradeId: true, subjectId: true, chapterId: true },
    });
    return {
      grades: e.filter(x => x.gradeId).map(x => x.gradeId!),
      subjects: e.filter(x => x.subjectId).map(x => x.subjectId!),
      chapters: e.filter(x => x.chapterId).map(x => x.chapterId!),
    };
  })();

  const accessibleSubjects = await prisma.subject.findMany({
    where: { OR: [{ id: { in: scopes.subjects } }, { gradeId: { in: scopes.grades } }, { chapters: { some: { id: { in: scopes.chapters } } } }] },
    include: { chapters: { include: { lessons: { where: { isPublished: true }, select: { id: true } } } } },
  });

  const allLessonIds = accessibleSubjects.flatMap(s => s.chapters.flatMap(c => c.lessons.map(l => l.id)));
  const progress = await prisma.lessonProgress.findMany({
    where: { userId: student.id, lessonId: { in: allLessonIds } },
    select: { lessonId: true, completed: true },
  });
  const completedSet = new Set(progress.filter(p => p.completed).map(p => p.lessonId));

  const result = accessibleSubjects.map(s => {
    const ids = s.chapters.flatMap(c => c.lessons.map(l => l.id));
    const total = ids.length;
    const done = ids.filter(id => completedSet.has(id)).length;
    return { subjectId: s.id, name: s.name, code: s.code, completedLessons: done, totalLessons: total, percent: total > 0 ? Math.round((done / total) * 100) : 0, isComplete: total > 0 && done === total };
  });

  console.log('\n=== SIMULATED GET /me/learnings ===');
  console.log(JSON.stringify(result, null, 2));

  // 5. hasAccess check per lesson
  console.log('\n=== hasAccess PER LESSON ===');
  for (const lesson of lessons) {
    let hasAccess = lesson.isFreePreview;
    if (!hasAccess) {
      // would need enrollment check, but all are isFreePreview here
    }
    // Also check enrollment-based access (FULL_CLASS on grade)
    const enrollmentAccess = scopes.grades.length > 0; // student has FULL_CLASS on grade VIII
    console.log(JSON.stringify({
      title: lesson.title,
      subject: lesson.chapter.subject.name,
      isFreePreview: lesson.isFreePreview,
      hasAccess: hasAccess || enrollmentAccess,
      locked: !(hasAccess || enrollmentAccess),
    }));
  }

  // 6. Confirm no orphan "Types of Climate Zones" lesson exists anywhere
  const orphan = await prisma.lesson.findFirst({ where: { title: 'Types of Climate Zones' } });
  console.log('\n=== ORPHAN CHECK: "Types of Climate Zones" ===');
  console.log(orphan ? `FOUND (id: ${orphan.id}) - BAD!` : 'Not found - GOOD');

  // Also check none of the old content exists
  const oldContent = await prisma.lesson.findFirst({ where: { title: { in: ['Introduction to Climate', 'The First Cities', 'What is an Algorithm'] } } });
  console.log('\n=== OLD CONTENT CHECK ===');
  console.log(oldContent ? `FOUND old lesson "${oldContent.title}" - BAD!` : 'No old lessons found - GOOD');
}

main().then(() => prisma.$disconnect()).catch(e => { console.error(e); prisma.$disconnect(); process.exit(1); });
