const fs = require('fs');
const path = require('path');

const found = [];

function search(dir, depth = 0) {
  if (depth > 5) return;
  try {
    const list = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of list) {
      if (item.name === 'node_modules' || item.name === '.git' || item.name === 'flutter' || item.name === 'AppData' || item.name === 'Library') continue;
      const p = path.join(dir, item.name);
      if (item.isFile() && (item.name.endsWith('.dart') || item.name === 'pubspec.yaml')) {
        found.push(p);
      } else if (item.isDirectory()) {
        search(p, depth + 1);
      }
    }
  } catch (e) {}
}

console.log('Searching C:\\Users\\parva ...');
search('C:\\Users\\parva');
console.log('Results (total ' + found.length + '):');
found.filter(f => !f.includes('flutter\\packages') && !f.includes('flutter\\dev')).forEach(f => console.log(' ->', f));
