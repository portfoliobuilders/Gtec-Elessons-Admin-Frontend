const fs = require('fs');
const path = require('path');

const targetStr = '/lessons/';
const matches = [];

function search(dir, depth = 0) {
  if (depth > 6) return;
  try {
    const items = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of items) {
      if (item.name.startsWith('$') || item.name === 'Windows' || item.name === 'Program Files' || item.name === 'Program Files (x86)' || item.name === 'ProgramData' || item.name === '.git' || item.name === 'node_modules' || item.name === 'flutter' || item.name === 'AppData' || item.name === 'dist' || item.name === '.next') continue;
      const p = path.join(dir, item.name);
      if (item.isFile()) {
        if (item.name.endsWith('.dart') || item.name.endsWith('.js') || item.name.endsWith('.ts') || item.name.endsWith('.tsx') || item.name.endsWith('.jsx')) {
          try {
            const content = fs.readFileSync(p, 'utf8');
            if (content.includes(targetStr) || content.includes('/api/me/learnings') || content.includes('Couldn\'t load lesson') || content.includes('Lesson not found')) {
              matches.push(p);
            }
          } catch (e) {}
        }
      } else if (item.isDirectory()) {
        search(p, depth + 1);
      }
    }
  } catch (e) {}
}

console.log('Searching for Flutter/frontend code with /lessons/ or "Lesson not found"...');
search('C:\\Users\\parva');
search('C:\\dev');

console.log('Matches found:', matches);
