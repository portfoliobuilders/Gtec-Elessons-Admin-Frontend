import http from 'http';

function request(options, body = null) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const reqOptions = {
      hostname: 'localhost',
      port: 3000,
      path: options.path,
      method: options.method,
      headers: {
        'Content-Type': 'application/json',
        ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
        ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    };

    const req = http.request(reqOptions, (res) => {
      let resBody = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => (resBody += chunk));
      res.on('end', () => {
        try {
          const json = resBody ? JSON.parse(resBody) : {};
          resolve({ status: res.statusCode, body: json });
        } catch {
          resolve({ status: res.statusCode, body: resBody });
        }
      });
    });

    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function runVerification() {
  console.log('=== Step 1: Login as Admin ===');
  const loginRes = await request({ path: '/api/auth/dev-login', method: 'POST' }, { email: 'admin@gtec.dev' });
  const token = loginRes.body.accessToken || loginRes.body.token;
  if (!token) {
    console.error('Login failed:', loginRes);
    process.exit(1);
  }
  console.log('Admin login successful!');

  const timestamp = Date.now();

  console.log('\n=== Step 2: Create Grade (POST /api/admin/grades) ===');
  const gradeRes = await request(
    { path: '/api/admin/grades', method: 'POST', token },
    { name: `Grade Audit ${timestamp}`, board: 'CBSE', syllabus: '2026' }
  );
  console.log('Grade creation status:', gradeRes.status, 'ID:', gradeRes.body.id);
  if (gradeRes.status !== 201) process.exit(1);
  const gradeId = gradeRes.body.id;

  console.log(`\n=== Step 3: Create Subject under Grade (POST /api/admin/grades/${gradeId}/subjects) ===`);
  const subjectRes = await request(
    { path: `/api/admin/grades/${gradeId}/subjects`, method: 'POST', token },
    { name: `Subject Audit ${timestamp}`, code: `SA${timestamp.toString().slice(-4)}` }
  );
  console.log('Subject creation status:', subjectRes.status, 'ID:', subjectRes.body.id, 'gradeId:', subjectRes.body.gradeId);
  if (subjectRes.status !== 201) process.exit(1);
  const subjectId = subjectRes.body.id;

  console.log(`\n=== Step 4: Create Chapter under Subject (POST /api/admin/subjects/${subjectId}/chapters) ===`);
  const chapterRes = await request(
    { path: `/api/admin/subjects/${subjectId}/chapters`, method: 'POST', token },
    { name: `Chapter Audit ${timestamp}` }
  );
  console.log('Chapter creation status:', chapterRes.status, 'ID:', chapterRes.body.id, 'subjectId:', chapterRes.body.subjectId);
  if (chapterRes.status !== 201) process.exit(1);
  const chapterId = chapterRes.body.id;

  console.log(`\n=== Step 5: Create Lesson under Chapter (POST /api/admin/chapters/${chapterId}/lessons) ===`);
  const lessonRes = await request(
    { path: `/api/admin/chapters/${chapterId}/lessons`, method: 'POST', token },
    { title: `Lesson Audit ${timestamp}`, isPublished: true }
  );
  console.log('Lesson creation status:', lessonRes.status, 'ID:', lessonRes.body.id, 'chapterId:', lessonRes.body.chapterId);
  if (lessonRes.status !== 201) process.exit(1);
  const lessonId = lessonRes.body.id;

  console.log(`\n=== Step 6: Create Grade Pricing (POST /api/admin/grades/${gradeId}/pricing) ===`);
  const gradePriceRes = await request(
    { path: `/api/admin/grades/${gradeId}/pricing`, method: 'POST', token },
    { title: `Full Class Product ${timestamp}`, amountCents: 500000, region: 'IN', currency: 'INR' }
  );
  console.log('Grade pricing creation status:', gradePriceRes.status, 'Product Type:', gradePriceRes.body.type, 'GradeId:', gradePriceRes.body.gradeId);
  if (gradePriceRes.status !== 201) process.exit(1);
  const gradeProductId = gradePriceRes.body.id;

  console.log(`\n=== Step 7: Create Subject Pricing (POST /api/admin/subjects/${subjectId}/pricing) ===`);
  const subjectPriceRes = await request(
    { path: `/api/admin/subjects/${subjectId}/pricing`, method: 'POST', token },
    { title: `Subject Product ${timestamp}`, amountCents: 200000, region: 'IN', currency: 'INR' }
  );
  console.log('Subject pricing creation status:', subjectPriceRes.status, 'Product Type:', subjectPriceRes.body.type, 'SubjectId:', subjectPriceRes.body.subjectId);
  if (subjectPriceRes.status !== 201) process.exit(1);
  const subjectProductId = subjectPriceRes.body.id;

  console.log(`\n=== Step 8: Create Chapter Pricing (POST /api/admin/chapters/${chapterId}/pricing) ===`);
  const chapterPriceRes = await request(
    { path: `/api/admin/chapters/${chapterId}/pricing`, method: 'POST', token },
    { title: `Module Product ${timestamp}`, amountCents: 50000, region: 'IN', currency: 'INR' }
  );
  console.log('Chapter pricing creation status:', chapterPriceRes.status, 'Product Type:', chapterPriceRes.body.type, 'ChapterId:', chapterPriceRes.body.chapterId);
  if (chapterPriceRes.status !== 201) process.exit(1);
  const chapterProductId = chapterPriceRes.body.id;

  console.log(`\n=== Step 9: Update Price via Nested Path (PATCH /api/admin/pricing/products/${subjectProductId}) ===`);
  const patchPriceRes = await request(
    { path: `/api/admin/pricing/products/${subjectProductId}`, method: 'PATCH', token },
    { region: 'IN', currency: 'INR', amountCents: 250000 }
  );
  console.log('Price update status:', patchPriceRes.status, 'New Amount:', patchPriceRes.body.amountCents);
  if (patchPriceRes.status !== 200) process.exit(1);

  console.log(`\n=== Step 10: Create Chapter Resource (POST /api/admin/chapters/${chapterId}/resources) ===`);
  const chapterResourceRes = await request(
    { path: `/api/admin/chapters/${chapterId}/resources`, method: 'POST', token },
    { title: 'Chapter Notes', fileKey: 'http://example.com/notes.pdf' }
  );
  console.log('Chapter resource creation status:', chapterResourceRes.status, 'ID:', chapterResourceRes.body.id, 'ChapterId:', chapterResourceRes.body.chapterId);
  if (chapterResourceRes.status !== 201) process.exit(1);

  console.log(`\n=== Step 11: Create Lesson Resource (POST /api/admin/lessons/${lessonId}/resources) ===`);
  const lessonResourceRes = await request(
    { path: `/api/admin/lessons/${lessonId}/resources`, method: 'POST', token },
    { title: 'Lesson Slides', fileKey: 'http://example.com/slides.pdf' }
  );
  console.log('Lesson resource creation status:', lessonResourceRes.status, 'ID:', lessonResourceRes.body.id, 'LessonId:', lessonResourceRes.body.lessonId);
  if (lessonResourceRes.status !== 201) process.exit(1);

  console.log(`\n=== Step 12: Create Batch under Subject (POST /api/admin/subjects/${subjectId}/batches) ===`);
  const batchRes = await request(
    { path: `/api/admin/subjects/${subjectId}/batches`, method: 'POST', token },
    { name: `Morning Batch ${timestamp}` }
  );
  console.log('Batch creation status:', batchRes.status, 'ID:', batchRes.body.id, 'SubjectId:', batchRes.body.subjectId, 'GradeId:', batchRes.body.gradeId);
  if (batchRes.status !== 201) process.exit(1);

  console.log('\n=== Step 13: Fetch Curriculum Tree (GET /api/admin/curriculum) ===');
  const treeRes = await request({ path: '/api/admin/curriculum', method: 'GET', token });
  console.log('Curriculum tree status:', treeRes.status);
  const createdGradeInTree = treeRes.body.find((g) => g.id === gradeId);
  if (!createdGradeInTree) {
    console.error('Grade not found in curriculum tree!');
    process.exit(1);
  }
  const createdSubjectInTree = createdGradeInTree.subjects.find((s) => s.id === subjectId);
  if (!createdSubjectInTree) {
    console.error('Subject not found under Grade in curriculum tree!');
    process.exit(1);
  }
  const createdChapterInTree = createdSubjectInTree.chapters.find((c) => c.id === chapterId);
  if (!createdChapterInTree) {
    console.error('Chapter not found under Subject in curriculum tree!');
    process.exit(1);
  }
  console.log('VERIFIED: Full tree linkage confirmed (Grade -> Subject -> Chapter)!');

  console.log('\n=== Step 14: Test Removed/Flat Routes (Expect 404) ===');
  const oldSubjectRes = await request({ path: '/api/admin/subjects', method: 'POST', token }, { name: 'Old', gradeId });
  console.log('POST /api/admin/subjects status:', oldSubjectRes.status, '(Expected 404)');

  const oldChapterRes = await request({ path: '/api/admin/chapters', method: 'POST', token }, { name: 'Old', subjectId });
  console.log('POST /api/admin/chapters status:', oldChapterRes.status, '(Expected 404)');

  const oldResourceRes = await request({ path: '/api/admin/resources', method: 'POST', token }, { title: 'Old', chapterId, fileKey: 'x' });
  console.log('POST /api/admin/resources status:', oldResourceRes.status, '(Expected 404)');

  const oldPricingRes = await request({ path: '/api/admin/pricing/products', method: 'POST', token }, { title: 'Old' });
  console.log('POST /api/admin/pricing/products status:', oldPricingRes.status, '(Expected 404)');

  if (oldSubjectRes.status === 404 && oldChapterRes.status === 404 && oldResourceRes.status === 404 && oldPricingRes.status === 404) {
    console.log('\nVERIFIED: All legacy flat routes correctly returned 404 Not Found!');
  } else {
    console.error('Flat route verification failed!');
    process.exit(1);
  }

  console.log('\n========================================');
  console.log('ALL NESTED ROUTE VERIFICATIONS PASSED 100%!');
  console.log('========================================');
}

runVerification().catch((err) => {
  console.error('Verification error:', err);
  process.exit(1);
});
