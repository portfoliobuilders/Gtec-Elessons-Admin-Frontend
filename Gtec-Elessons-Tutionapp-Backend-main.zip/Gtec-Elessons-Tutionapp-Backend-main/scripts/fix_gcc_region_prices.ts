// One-off data fix: 3 ProductPrice rows were seeded with region:"GCC", but the
// real Country table (and the current UsersService.setRegion() flow) only ever
// produces ISO country codes — the UAE is "AE", not "GCC". Those rows were
// unreachable: resolvePrice()'s exact region+currency match could never fire
// for a real student, since no code path can currently write region:"GCC" to
// a StudentProfile (confirmed: 0 StudentProfile rows have region "GCC").
//
// Fix: migrate region "GCC" -> "AE" so these admin-set AED overrides actually
// match UAE-profile students instead of silently falling back to a live/DB
// INR->AED conversion. Safe to run: verified no pre-existing region:"AE",
// currency:"AED" rows on the same 3 products (no unique-constraint collision).
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const before = await prisma.productPrice.findMany({ where: { region: 'GCC' } });
  console.log(`Found ${before.length} ProductPrice row(s) with region:"GCC":`);
  for (const r of before) console.log(`  - ${r.id} (product ${r.productId}, ${r.currency} ${r.amount})`);

  if (before.length === 0) {
    console.log('Nothing to migrate.');
    return;
  }

  const result = await prisma.productPrice.updateMany({
    where: { region: 'GCC' },
    data: { region: 'AE' },
  });
  console.log(`\nMigrated ${result.count} row(s): region "GCC" -> "AE".`);

  const remaining = await prisma.productPrice.count({ where: { region: 'GCC' } });
  console.log(`Remaining region:"GCC" rows: ${remaining}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
