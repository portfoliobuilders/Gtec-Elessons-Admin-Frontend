import { PrismaClient, ProductType, ProductFormat } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // ========== TASK 1: Verify Grade VIII videos (already restored earlier) ==========
  console.log('\n======= TASK 1: GRADE VIII VIDEO STATE =======');
  const grade8Lessons = await prisma.lesson.findMany({
    where: { id: { in: ['seed-lesson-solid-liquid-gas', 'seed-lesson-intro-whole-numbers', 'seed-lesson-parts-of-speech'] } },
    select: { id: true, title: true, youtubeId: true }
  });
  for (const l of grade8Lessons) {
    console.log(`  ${l.id}: "${l.title}" -> youtubeId: ${l.youtubeId}`);
  }

  // Ensure they're correct (idempotent patch)
  await prisma.lesson.update({
    where: { id: 'seed-lesson-solid-liquid-gas' },
    data: {
      youtubeId: 'F0pG79qCE9c',
      youtubeUrl: 'https://www.youtube.com/watch?v=F0pG79qCE9c',
      thumbnailUrl: 'https://img.youtube.com/vi/F0pG79qCE9c/hqdefault.jpg',
    }
  });
  await prisma.lesson.update({
    where: { id: 'seed-lesson-intro-whole-numbers' },
    data: {
      youtubeId: 'G-_GpCm6ViQ',
      youtubeUrl: 'https://www.youtube.com/watch?v=G-_GpCm6ViQ',
      thumbnailUrl: 'https://img.youtube.com/vi/G-_GpCm6ViQ/hqdefault.jpg',
    }
  });
  console.log('  ✅ Grade VIII videos confirmed/patched to correct IDs.');

  // ========== TASK 2: Investigate Grade 11 rows ==========
  console.log('\n======= TASK 2: GRADE 11 INVESTIGATION =======');
  const allGrades = await prisma.grade.findMany({ orderBy: { order: 'asc' } });
  console.log('All grades in DB:');
  for (const g of allGrades) {
    const subs = await prisma.subject.count({ where: { gradeId: g.id } });
    console.log(`  id=${g.id} | name="${g.name}" | board=${g.board} | order=${g.order} | subjects=${subs}`);
  }

  const cms3Grade = await prisma.grade.findUnique({ where: { id: 'cms3fj0zq000t1s74n2hum68a' } });
  if (cms3Grade) {
    console.log('\n  ⚠️  Found cms3fj0zq000t1s74n2hum68a:', cms3Grade);
    // Check what content is attached
    const cmsSubs = await prisma.subject.findMany({ where: { gradeId: 'cms3fj0zq000t1s74n2hum68a' }, include: { chapters: { include: { lessons: true } } } });
    console.log('  Subjects on cms3 grade:', JSON.stringify(cmsSubs, null, 2));
  } else {
    console.log('\n  ✅ cms3fj0zq000t1s74n2hum68a does NOT exist in DB.');
    console.log('  → "Plus One" (seed-grade-plus-one) is the only Class 11 row. No duplicate to consolidate.');
    console.log('  → "Plus One" = Kerala/CBSE terminology for Class 11 (Grade 11). Same academic year.');
  }

  // ========== TASK 3: Build Class 11 subjects under seed-grade-plus-one ==========
  console.log('\n======= TASK 3: BUILDING CLASS 11 SUBJECTS =======');

  const TEACHER_ID = 'seed-user-teacher';
  const GRADE_ID = 'seed-grade-plus-one';

  const CLASS11_SUBJECTS = [
    {
      subjectId: 'seed-subject-plus-one-accountancy',
      name: 'Accountancy',
      code: 'ACC11',
      order: 3,
      chapterId: 'seed-chapter-intro-accounting',
      chapterName: 'Introduction to Accounting',
      lessonId: 'seed-lesson-basics-of-accountancy',
      lessonTitle: 'Basics of Accountancy',
      youtubeId: 'bwmBKf-7sYA',
      productId: 'seed-product-plus-one-accountancy',
      priceInrId: 'seed-price-plus-one-accountancy-inr',
      priceInr: 8000,
    },
    {
      subjectId: 'seed-subject-plus-one-chemistry',
      name: 'Chemistry',
      code: 'CHEM11',
      order: 4,
      chapterId: 'seed-chapter-chemical-reactions',
      chapterName: 'Chemical Reactions',
      lessonId: 'seed-lesson-intro-chemistry',
      lessonTitle: 'Intro to Chemistry',
      youtubeId: 'AjG4xIDWmRo',
      productId: 'seed-product-plus-one-chemistry',
      priceInrId: 'seed-price-plus-one-chemistry-inr',
      priceInr: 10000,
    },
    {
      subjectId: 'seed-subject-plus-one-maths',
      name: 'Maths',
      code: 'MATH11',
      order: 0, // already exists but we'll update
      chapterId: 'seed-chapter-algebra-functions',
      chapterName: 'Algebra and Functions',
      lessonId: 'seed-lesson-intro-algebra',
      lessonTitle: 'Introduction to Algebra',
      youtubeId: 'jd_EIuOhkIU',
      productId: null, // already exists as seed-product-plus-one-maths
      priceInrId: null,
      priceInr: 10000,
    },
  ];

  // Note: seed-subject-plus-one-maths already exists from previous seed
  // We need to handle it carefully - update code + add chapter/lesson if missing

  for (const s of CLASS11_SUBJECTS) {
    console.log(`\n  → Upserting subject: ${s.name} (${s.subjectId})`);

    // For maths, subject already exists with a different id if previously seeded
    let subject;
    if (s.name === 'Maths') {
      // Check if it already exists
      const existing = await prisma.subject.findUnique({ where: { id: 'seed-subject-plus-one-maths' } });
      if (existing) {
        subject = await prisma.subject.update({
          where: { id: 'seed-subject-plus-one-maths' },
          data: { code: 'MATH11', teacherId: TEACHER_ID, teacherName: 'Teacher G-TEC', order: 0 }
        });
        console.log(`     Updated existing Maths subject: ${subject.id}`);
      } else {
        subject = await prisma.subject.create({
          data: {
            id: 'seed-subject-plus-one-maths',
            name: 'Maths',
            code: 'MATH11',
            gradeId: GRADE_ID,
            order: 0,
            teacherId: TEACHER_ID,
            teacherName: 'Teacher G-TEC',
          }
        });
        console.log(`     Created Maths subject: ${subject.id}`);
      }
    } else {
      subject = await prisma.subject.upsert({
        where: { id: s.subjectId },
        update: {
          name: s.name,
          code: s.code,
          gradeId: GRADE_ID,
          order: s.order,
          teacherId: TEACHER_ID,
          teacherName: 'Teacher G-TEC',
        },
        create: {
          id: s.subjectId,
          name: s.name,
          code: s.code,
          gradeId: GRADE_ID,
          order: s.order,
          teacherId: TEACHER_ID,
          teacherName: 'Teacher G-TEC',
        }
      });
      console.log(`     Upserted subject: ${subject.id}`);
    }

    // Upsert chapter
    const chapter = await prisma.chapter.upsert({
      where: { id: s.chapterId },
      update: { name: s.chapterName, subjectId: subject.id, order: 0 },
      create: { id: s.chapterId, name: s.chapterName, subjectId: subject.id, order: 0 }
    });
    console.log(`     Chapter: ${chapter.id} "${chapter.name}"`);

    // Upsert lesson with video
    const lesson = await prisma.lesson.upsert({
      where: { id: s.lessonId },
      update: {
        title: s.lessonTitle,
        chapterId: chapter.id,
        youtubeId: s.youtubeId,
        youtubeUrl: `https://www.youtube.com/watch?v=${s.youtubeId}`,
        thumbnailUrl: `https://img.youtube.com/vi/${s.youtubeId}/hqdefault.jpg`,
        isFreePreview: true,
        isPublished: true,
        order: 0,
      },
      create: {
        id: s.lessonId,
        title: s.lessonTitle,
        chapterId: chapter.id,
        youtubeId: s.youtubeId,
        youtubeUrl: `https://www.youtube.com/watch?v=${s.youtubeId}`,
        thumbnailUrl: `https://img.youtube.com/vi/${s.youtubeId}/hqdefault.jpg`,
        isFreePreview: true,
        isPublished: true,
        order: 0,
      }
    });
    console.log(`     Lesson: ${lesson.id} "${lesson.title}" -> youtubeId: ${lesson.youtubeId}`);

    // Upsert product + price (skip for Maths which already has one)
    if (s.productId) {
      const product = await prisma.product.upsert({
        where: { id: s.productId },
        update: {
          type: ProductType.SUBJECT,
          format: ProductFormat.RECORDED,
          title: `Class Plus One — ${s.name}`,
          subjectId: subject.id,
          isActive: true,
        },
        create: {
          id: s.productId,
          type: ProductType.SUBJECT,
          format: ProductFormat.RECORDED,
          title: `Class Plus One — ${s.name}`,
          subjectId: subject.id,
          isActive: true,
        }
      });
      await prisma.productPrice.upsert({
        where: { id: s.priceInrId },
        update: { productId: product.id, region: 'IN', currency: 'INR', amount: s.priceInr },
        create: { id: s.priceInrId, productId: product.id, region: 'IN', currency: 'INR', amount: s.priceInr }
      });
      console.log(`     Product: ${product.id} @ ₹${s.priceInr}`);
    } else {
      console.log(`     Product: using existing seed-product-plus-one-maths`);
    }
  }

  // ========== TASK 4: Curriculum tree summary ==========
  console.log('\n======= TASK 4: CURRICULUM TREE VERIFICATION =======');

  for (const gid of ['seed-grade-8', 'seed-grade-plus-one']) {
    const grade = await prisma.grade.findUnique({
      where: { id: gid },
      include: {
        subjects: {
          include: {
            chapters: {
              include: {
                lessons: { select: { id: true, title: true, youtubeId: true, isFreePreview: true, isPublished: true } }
              }
            }
          },
          orderBy: { order: 'asc' }
        }
      }
    });

    if (!grade) { console.log(`Grade ${gid} not found`); continue; }

    console.log(`\nGrade: "${grade.name}" (${grade.id})`);
    for (const sub of grade.subjects) {
      console.log(`  Subject: ${sub.name} [${sub.code}] (${sub.id})`);
      for (const ch of sub.chapters) {
        console.log(`    Chapter: "${ch.name}" (${ch.id})`);
        for (const l of ch.lessons) {
          console.log(`      Lesson: "${l.title}" | youtubeId: ${l.youtubeId} | free: ${l.isFreePreview} | published: ${l.isPublished}`);
        }
      }
    }
  }

  console.log('\n✅ All tasks complete.');
}

main().catch(console.error).finally(() => prisma.$disconnect());
