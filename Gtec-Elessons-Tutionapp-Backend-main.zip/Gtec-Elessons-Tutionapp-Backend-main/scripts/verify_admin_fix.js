import http from 'http';

function postDevLogin(email) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify({ email });
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/api/auth/dev-login',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
      }
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        if (res.statusCode >= 400) {
          reject(new Error(`dev-login failed with status ${res.statusCode}: ${body}`));
        } else {
          resolve(JSON.parse(body));
        }
      });
    });

    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

function getAdminCurriculum(token) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/api/admin/curriculum',
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body
        });
      });
    });

    req.on('error', reject);
    req.end();
  });
}

async function verify() {
  try {
    console.log('Step 1: Logging in as admin@gtec.dev via dev-login...');
    const loginData = await postDevLogin('admin@gtec.dev');
    console.log('Login successful!');
    console.log('Role in response:', loginData.user.role);
    console.log('Token snippet:', loginData.accessToken.substring(0, 25) + '...');

    if (loginData.user.role !== 'SUPER_ADMIN') {
      console.error('ERROR: Role is NOT SUPER_ADMIN. Got:', loginData.user.role);
      process.exit(1);
    }

    console.log('\nStep 2: Requesting GET /api/admin/curriculum using the token...');
    const result = await getAdminCurriculum(loginData.accessToken);
    console.log('Response Status:', result.statusCode);
    
    if (result.statusCode === 200) {
      console.log('SUCCESS: Admin curriculum loaded successfully (Status 200)!');
      const curriculum = JSON.parse(result.body);
      console.log('Curriculum grades count:', curriculum.length);
    } else {
      console.error('ERROR: Failed to load admin curriculum. Status:', result.statusCode);
      console.error('Body:', result.body);
      process.exit(1);
    }
  } catch (error) {
    console.error('Exception during verification:', error);
    process.exit(1);
  }
}

verify();
