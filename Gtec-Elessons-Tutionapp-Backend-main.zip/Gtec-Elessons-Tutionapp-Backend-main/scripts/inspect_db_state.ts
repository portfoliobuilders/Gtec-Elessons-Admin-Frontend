import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('=== ALL GRADES ===');
  const grades = await prisma.grade.findMany({
    include: {
      _count: {
        select: {
          subjects: true,
          products: true,
          enrollments: true,
          students: true,
          assessments: true,
          liveClasses: true,
          batches: true,
        },
      },
    },
  });
  console.log(JSON.stringify(grades, null, 2));

  console.log('\n=== ALL PRODUCTS & PRICES ===');
  const products = await prisma.product.findMany({
    include: {
      prices: true,
      grade: true,
      subject: true,
    },
  });
  console.log(JSON.stringify(products, null, 2));
}

main().catch(console.error).finally(() => prisma.$disconnect());
