import { PrismaClient } from '@prisma/client';
import { AccessService } from '../src/access/access.service';
import { PrismaService } from '../src/prisma/prisma.service';

// Standalone hasAccess verification — uses the same logic as the live server
const prisma = new PrismaClient();

async function main() {
  const student = await prisma.user.findUnique({
    where: { email: 'teststudent99@gmail.com' },
    select: { id: true, name: true },
  });
  if (!student) { console.log('student not found'); return; }
  console.log('Student:', student);

  // All Grade VIII lessons
  const lessons = await prisma.lesson.findMany({
    where: { chapter: { subject: { grade: { name: 'Grade VIII' } } } },
    select: {
      id: true, title: true, isFreePreview: true, isPublished: true,
      chapter: { select: { id: true, subjectId: true, subject: { select: { gradeId: true, name: true } } } },
    },
  });

  // Replicate canAccessLesson logic inline
  const enrollments = await prisma.enrollment.findMany({
    where: {
      userId: student.id,
      status: 'ACTIVE',
      OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
    },
    select: { scopeType: true, gradeId: true, subjectId: true, chapterId: true },
  });

  console.log('\n=== ENROLLMENT STATE ===');
  console.log(JSON.stringify(enrollments, null, 2));

  console.log('\n=== hasAccess CHECK PER LESSON ===');
  for (const lesson of lessons) {
    if (!lesson.isPublished) { console.log(`${lesson.title}: SKIPPED (not published)`); continue; }

    let hasAccess = false;
    if (lesson.isFreePreview) {
      hasAccess = true; // short-circuit, no enrollment needed
    } else {
      const chapterId = lesson.chapter.id;
      const subjectId = lesson.chapter.subjectId;
      const gradeId = lesson.chapter.subject.gradeId;
      hasAccess = enrollments.some((e) =>
        (e.scopeType === 'FULL_CLASS' && e.gradeId === gradeId) ||
        (e.scopeType === 'SUBJECT' && e.subjectId === subjectId) ||
        (e.scopeType === 'MODULE' && e.chapterId === chapterId),
      );
    }

    console.log(JSON.stringify({
      lessonId: lesson.id,
      title: lesson.title,
      subject: lesson.chapter.subject.name,
      isFreePreview: lesson.isFreePreview,
      hasAccess,
      locked: !hasAccess,
    }));
  }
}

main()
  .then(() => prisma.$disconnect())
  .catch((e) => { console.error(e); prisma.$disconnect(); process.exit(1); });
