const https = require('https');

const playlists = [
  { url: 'https://www.youtube.com/playlist?list=PLV4HVfstZAMw' },
  { url: 'https://www.youtube.com/playlist?list=PLNsVNHOlyj6U' },
  { url: 'https://www.youtube.com/playlist?list=PLAZIZ5WdedIY' },
];

function fetchPlaylist(url) {
  return new Promise((resolve) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' } }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        // Extract title
        const titleMatch = data.match(/<title>(.*?)<\/title>/);
        const title = titleMatch ? titleMatch[1].replace(' - YouTube', '') : 'Unknown';

        // Extract video IDs and titles from ytInitialData if present
        const videoIds = [];
        const matches = data.match(/"videoId":"([a-zA-Z0-9_-]{11})"/g);
        if (matches) {
          for (const m of matches) {
            const id = m.split(':"')[1].replace('"', '');
            if (!videoIds.includes(id)) {
              videoIds.push(id);
            }
          }
        }

        resolve({ url, title, videoIds: videoIds.slice(0, 5) });
      });
    });
  });
}

async function main() {
  for (const p of playlists) {
    const info = await fetchPlaylist(p.url);
    console.log(JSON.stringify(info, null, 2));
  }
}

main();
