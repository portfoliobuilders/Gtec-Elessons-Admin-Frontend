import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  // 1. Find the student
  const student = await prisma.user.findUnique({
    where: { email: 'teststudent99@gmail.com' },
    select: { id: true, name: true, email: true, role: true },
  });
  console.log('=== STUDENT ===');
  console.log(JSON.stringify(student, null, 2));

  if (!student) { console.log('STUDENT NOT FOUND'); return; }

  // 2. Check Enrollment table
  const enrollments = await prisma.enrollment.findMany({
    where: { userId: student.id },
    select: { id: true, scopeType: true, status: true, gradeId: true, subjectId: true, chapterId: true, expiresAt: true, startsAt: true },
  });
  console.log('\n=== ENROLLMENTS FOR THIS STUDENT ===');
  console.log(JSON.stringify(enrollments, null, 2));

  // 3. Check subjects (the three repurposed ones with their current names)
  const subjects = await prisma.subject.findMany({
    where: { grade: { name: 'Grade VIII' } },
    select: { id: true, name: true, code: true },
    orderBy: { order: 'asc' },
  });
  console.log('\n=== GRADE VIII SUBJECTS (current names in DB) ===');
  console.log(JSON.stringify(subjects, null, 2));

  // 4. Check lessons with isFreePreview for Grade VIII
  const lessons = await prisma.lesson.findMany({
    where: { chapter: { subject: { grade: { name: 'Grade VIII' } } } },
    select: {
      id: true,
      title: true,
      isFreePreview: true,
      isPublished: true,
      chapter: {
        select: {
          name: true,
          subject: { select: { name: true, code: true } },
        },
      },
    },
  });
  console.log('\n=== GRADE VIII LESSONS (isFreePreview + isPublished) ===');
  console.log(JSON.stringify(lessons, null, 2));

  // 5. Simulate GET /me/learnings for this student (mirror the service logic)
  //    First get access scopes
  const activeEnrollments = await prisma.enrollment.findMany({
    where: {
      userId: student.id,
      status: 'ACTIVE',
      OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
    },
    select: { scopeType: true, gradeId: true, subjectId: true, chapterId: true },
  });
  const scopes = {
    grades: activeEnrollments.filter((e: any) => e.gradeId).map((e: any) => e.gradeId!),
    subjects: activeEnrollments.filter((e: any) => e.subjectId).map((e: any) => e.subjectId!),
    chapters: activeEnrollments.filter((e: any) => e.chapterId).map((e: any) => e.chapterId!),
  };
  console.log('\n=== ACCESS SCOPES (grades/subjects/chapters) ===');
  console.log(JSON.stringify(scopes, null, 2));

  // Which subjects the student can see
  const accessibleSubjects = await prisma.subject.findMany({
    where: {
      OR: [
        { id: { in: scopes.subjects } },
        { gradeId: { in: scopes.grades } },
        { chapters: { some: { id: { in: scopes.chapters } } } },
      ],
    },
    include: {
      chapters: {
        include: {
          lessons: { where: { isPublished: true }, select: { id: true } },
        },
      },
    },
  });
  console.log('\n=== ACCESSIBLE SUBJECTS (for /me/learnings) ===');
  console.log(JSON.stringify(accessibleSubjects.map((s: any) => ({ id: s.id, name: s.name, code: s.code, lessonCount: s.chapters.flatMap((c: any) => c.lessons).length })), null, 2));

  // Final simulated response
  console.log('\n=== SIMULATED GET /me/learnings RESPONSE ===');
  const allLessonIds = accessibleSubjects.flatMap((s: any) => s.chapters.flatMap((c: any) => c.lessons.map((l: any) => l.id)));
  const progress = await prisma.lessonProgress.findMany({
    where: { userId: student.id, lessonId: { in: allLessonIds } },
    select: { lessonId: true, completed: true },
  });
  const completedSet = new Set(progress.filter((p: any) => p.completed).map((p: any) => p.lessonId));
  const courses = accessibleSubjects.map((s: any) => {
    const lessonIds = s.chapters.flatMap((c: any) => c.lessons.map((l: any) => l.id));
    const total = lessonIds.length;
    const done = lessonIds.filter((id: string) => completedSet.has(id)).length;
    const percent = total > 0 ? Math.round((done / total) * 100) : 0;
    return { subjectId: s.id, name: s.name, code: s.code, completedLessons: done, totalLessons: total, percent, isComplete: total > 0 && done === total };
  });
  console.log(JSON.stringify(courses, null, 2));
}

main()
  .then(() => prisma.$disconnect())
  .catch((e) => { console.error(e); prisma.$disconnect(); process.exit(1); });
