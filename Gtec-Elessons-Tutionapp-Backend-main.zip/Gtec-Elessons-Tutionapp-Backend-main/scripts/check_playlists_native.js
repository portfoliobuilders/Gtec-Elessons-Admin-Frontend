const https = require('https');

const playlists = [
  'https://www.youtube.com/playlist?list=PLV4HVfstZAMw',
  'https://www.youtube.com/playlist?list=PLNsVNHOlyj6U',
  'https://www.youtube.com/playlist?list=PLAZIZ5WdedIY',
];

function checkUrl(url) {
  return new Promise((resolve) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const isUnavailable = data.includes('This playlist does not exist') || data.includes('Playlist unavailable') || res.statusCode === 404;
        resolve({ url, statusCode: res.statusCode, isUnavailable, bodySnippet: data.substring(0, 300) });
      });
    }).on('error', (err) => {
      resolve({ url, statusCode: 0, isUnavailable: true, error: err.message });
    });
  });
}

async function main() {
  for (const url of playlists) {
    const res = await checkUrl(url);
    console.log(JSON.stringify(res, null, 2));
  }
}

main();
