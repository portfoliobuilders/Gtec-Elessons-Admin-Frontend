import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('=== SEARCHING FOR ALL GRADES OR DELETED/INACTIVE GRADES ===');
  const allGrades = await prisma.grade.findMany({});
  console.log('All grades count:', allGrades.length);
  console.log(allGrades);

  console.log('\n=== CHECKING SUBJECTS WITH GRADE IDs ===');
  const subjects = await prisma.subject.findMany({ select: { id: true, name: true, gradeId: true } });
  console.log(subjects);

  console.log('\n=== CHECKING PRODUCTS WITH GRADE IDs ===');
  const products = await prisma.product.findMany({ select: { id: true, title: true, gradeId: true, type: true } });
  console.log(products);

  console.log('\n=== CHECKING STUDENT PROFILES WITH GRADE IDs ===');
  const profiles = await prisma.studentProfile.findMany({ select: { id: true, gradeId: true } });
  console.log(profiles);

  console.log('\n=== CHECKING ENROLLMENTS WITH GRADE IDs ===');
  const enrollments = await prisma.enrollment.findMany({ select: { id: true, gradeId: true } });
  console.log(enrollments);
}

main().catch(console.error).finally(() => prisma.$disconnect());
