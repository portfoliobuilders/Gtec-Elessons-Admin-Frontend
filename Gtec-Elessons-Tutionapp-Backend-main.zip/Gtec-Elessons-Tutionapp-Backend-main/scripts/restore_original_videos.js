const http = require('http');

function makeRequest(options, body) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, body: data }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function main() {
  // Get admin token
  const loginBody = JSON.stringify({ email: 'admin@gtec.dev' });
  const loginRes = await makeRequest({
    hostname: 'localhost', port: 3000, path: '/api/auth/dev-login', method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(loginBody) }
  }, loginBody);
  const token = loginRes.body.accessToken;
  console.log('Token obtained:', !!token);

  // Restore original seed videos:
  // Grade VIII Science -> F0pG79qCE9c (original from seed)
  // Grade VIII Maths   -> G-_GpCm6ViQ (original from seed)
  const restorations = [
    {
      lessonId: 'seed-lesson-solid-liquid-gas',
      youtubeId: 'F0pG79qCE9c',
      label: 'Grade VIII Science — restoring original seed video (States of Matter demo)',
    },
    {
      lessonId: 'seed-lesson-intro-whole-numbers',
      youtubeId: 'G-_GpCm6ViQ',
      label: 'Grade VIII Maths — restoring original seed video (Whole Numbers intro)',
    },
  ];

  for (const r of restorations) {
    console.log(`\nRestoring ${r.label}...`);
    const body = JSON.stringify({ youtubeId: r.youtubeId });
    const res = await makeRequest({
      hostname: 'localhost', port: 3000,
      path: `/api/admin/lessons/${r.lessonId}/video`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'Authorization': `Bearer ${token}`
      }
    }, body);
    console.log('Status:', res.status);
    console.log('Response:', JSON.stringify(res.body, null, 2));
  }

  console.log('\n✅ Done. Both lessons restored to original seed videos.');
}

main().catch(console.error);
