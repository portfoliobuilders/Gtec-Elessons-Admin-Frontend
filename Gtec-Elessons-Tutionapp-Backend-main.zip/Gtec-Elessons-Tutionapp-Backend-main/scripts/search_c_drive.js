const fs = require('fs');
const path = require('path');

const found = [];

function search(dir, depth = 0) {
  if (depth > 5) return;
  try {
    const list = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of list) {
      if (item.name.startsWith('$') || item.name === 'Windows' || item.name === 'Program Files' || item.name === 'Program Files (x86)' || item.name === 'ProgramData' || item.name === '.git' || item.name === 'node_modules' || item.name === 'flutter' || item.name === 'AppData') continue;
      const p = path.join(dir, item.name);
      if (item.isFile() && item.name === 'pubspec.yaml') {
        found.push(p);
      } else if (item.isDirectory()) {
        search(p, depth + 1);
      }
    }
  } catch (e) {}
}

console.log('Searching C:\\ root folders...');
search('C:\\dev');
search('C:\\home');
search('C:\\Apps');
search('C:\\Users');

console.log('Found Flutter apps:', found);
