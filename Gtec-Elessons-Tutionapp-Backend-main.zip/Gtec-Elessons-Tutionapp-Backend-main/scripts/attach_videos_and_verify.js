const http = require('http');

// Step 1: Get admin token via dev-login
function makeRequest(options, body) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function main() {
  // 1. Login as admin
  const loginBody = JSON.stringify({ email: 'admin@gtec.dev' });
  const loginRes = await makeRequest({
    hostname: 'localhost', port: 3000, path: '/api/auth/dev-login', method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(loginBody) }
  }, loginBody);

  console.log('Login status:', loginRes.status);
  if (loginRes.status !== 200 && loginRes.status !== 201) {
    console.error('Login failed:', loginRes.body);
    return;
  }

  const token = loginRes.body.accessToken;
  console.log('Got token:', token ? 'YES' : 'NO');

  // Playlist resolution results:
  // PLV4HVfstZAMw  -> "Class 12 - Accountancy" -> first video: bwmBKf-7sYA  (NO MATCH - Accountancy != Science/Maths/English)
  // PLNsVNHOlyj6U  -> "Class 11 Chemistry"     -> first video: AjG4xIDWmRo  (BEST-GUESS -> Grade VIII Science)
  // PLAZIZ5WdedIY  -> "Class 11 - Maths"       -> first video: jd_EIuOhkIU  (BEST-GUESS -> Grade VIII Maths)

  const videoAttachments = [
    // Only attaching the 2 that have a reasonable subject mapping
    // Playlist 2 (Chemistry) -> Grade VIII Science lesson
    { lessonId: 'seed-lesson-solid-liquid-gas', youtubeId: 'AjG4xIDWmRo', label: 'Grade VIII Science (Chemistry playlist first video)' },
    // Playlist 3 (Maths) -> Grade VIII Maths lesson
    { lessonId: 'seed-lesson-intro-whole-numbers', youtubeId: 'jd_EIuOhkIU', label: 'Grade VIII Maths (Maths playlist first video)' },
    // Playlist 1 (Accountancy) -> NO MATCH - skipping (Accountancy != any Grade VIII subject)
  ];

  for (const att of videoAttachments) {
    console.log(`\n--- Attaching ${att.youtubeId} to lesson ${att.lessonId} (${att.label}) ---`);
    const body = JSON.stringify({ youtubeId: att.youtubeId });
    const res = await makeRequest({
      hostname: 'localhost', port: 3000,
      path: `/api/admin/lessons/${att.lessonId}/video`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'Authorization': `Bearer ${token}`
      }
    }, body);
    console.log('Status:', res.status);
    console.log('Response:', JSON.stringify(res.body, null, 2));
  }

  // 2. Verify all lesson videos via catalog
  console.log('\n\n=== VERIFYING FEE TABLE (GET /api/catalog/grades) ===');
  const catalogRes = await makeRequest({
    hostname: 'localhost', port: 3000, path: '/api/catalog/grades', method: 'GET',
    headers: { 'Authorization': `Bearer ${token}` }
  }, null);
  console.log('Catalog status:', catalogRes.status);
  console.log('Grades:', JSON.stringify(catalogRes.body, null, 2));
}

main().catch(console.error);
