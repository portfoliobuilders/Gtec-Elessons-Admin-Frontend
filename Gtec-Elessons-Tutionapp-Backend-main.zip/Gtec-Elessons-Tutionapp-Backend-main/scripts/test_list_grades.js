import http from 'http';

function getGrades() {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/api/grades',
      method: 'GET'
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          body: JSON.parse(body)
        });
      });
    });

    req.on('error', reject);
    req.end();
  });
}

async function run() {
  const result = await getGrades();
  console.log('=== GET /api/grades ===');
  console.log('Status:', result.statusCode);
  console.log('Body:', JSON.stringify(result.body, null, 2));
}

run().catch(console.error);
