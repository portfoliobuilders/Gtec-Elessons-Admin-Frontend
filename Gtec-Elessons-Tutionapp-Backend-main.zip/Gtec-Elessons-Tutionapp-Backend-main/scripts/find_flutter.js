const fs = require('fs');
const path = require('path');

function searchDir(dir, depth = 0) {
  if (depth > 4) return;
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === '.gradle' || entry.name === 'build' || entry.name === 'AppData') continue;
      const fullPath = path.join(dir, entry.name);
      if (entry.isFile() && entry.name === 'pubspec.yaml') {
        console.log('FOUND FLUTTER APP:', fullPath);
      } else if (entry.isDirectory()) {
        searchDir(fullPath, depth + 1);
      }
    }
  } catch (e) {}
}

console.log('Searching C:\\Users\\parva ...');
searchDir('C:\\Users\\parva');
console.log('Search complete.');
