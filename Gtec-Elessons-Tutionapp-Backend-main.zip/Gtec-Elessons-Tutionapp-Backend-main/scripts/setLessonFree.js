const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const id = process.argv[2] || 'cmrk6xm4q000hawoixg3zrede';

async function main() {
    await prisma.lesson.update({ where: { id }, data: { isFreePreview: true } });
    const l = await prisma.lesson.findUnique({ where: { id } });
    console.log(JSON.stringify(l, null, 2));
    await prisma.$disconnect();
}

main().catch(e => { console.error(e); process.exit(1) });
