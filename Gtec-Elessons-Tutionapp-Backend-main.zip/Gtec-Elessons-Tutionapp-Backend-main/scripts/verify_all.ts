import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function verify() {
  console.log('--- STEP 7: DB ID PERMANENCE VERIFICATION ---');

  const grades = await prisma.grade.findMany({ select: { id: true, name: true } });
  console.log('Grades in DB:', grades);

  const subjects = await prisma.subject.findMany({
    where: { gradeId: 'seed-grade-8' },
    select: { id: true, name: true, code: true },
  });
  console.log('Grade VIII Subjects in DB:', subjects);

  const chapters = await prisma.chapter.findMany({
    where: { subject: { gradeId: 'seed-grade-8' } },
    select: { id: true, name: true, subjectId: true },
  });
  console.log('Grade VIII Chapters in DB:', chapters);

  const lessons = await prisma.lesson.findMany({
    where: { chapter: { subject: { gradeId: 'seed-grade-8' } } },
    select: { id: true, title: true, chapterId: true },
  });
  console.log('Grade VIII Lessons in DB:', lessons);

  const products = await prisma.product.findMany({
    where: { OR: [{ gradeId: 'seed-grade-8' }, { subject: { gradeId: 'seed-grade-8' } }] },
    include: { prices: true },
  });
  console.log('Grade VIII Products & Prices in DB:');
  for (const p of products) {
    console.log(`Product [${p.id}] ${p.title} (type: ${p.type}, subjectId: ${p.subjectId}):`);
    for (const pr of p.prices) {
      console.log(`   Price [${pr.id}] region: ${pr.region}, currency: ${pr.currency}, amount: ${pr.amount} (${pr.amount} ${pr.currency})`);
    }
  }

  const demoEnrollment = await prisma.enrollment.findUnique({
    where: { id: 'seed-enrollment-demo' },
  });
  console.log('Demo Enrollment:', demoEnrollment);

  console.log('\n--- STEP 8: STORE / CATALOG PRICING VERIFICATION ---');

  const grade8 = await prisma.grade.findUnique({
    where: { id: 'seed-grade-8' },
    include: {
      subjects: {
        orderBy: { order: 'asc' },
        include: {
          products: { where: { isActive: true }, include: { prices: true } },
        },
      },
      products: { where: { isActive: true }, include: { prices: true } },
    },
  });

  if (!grade8) {
    throw new Error('Grade VIII not found!');
  }

  console.log(`Grade: ${grade8.name} (id: ${grade8.id})`);
  for (const sub of grade8.subjects) {
    console.log(`Subject: ${sub.name} (id: ${sub.id})`);
    for (const prod of sub.products) {
      console.log(`  Product: ${prod.title} (id: ${prod.id})`);
      for (const pr of prod.prices) {
        console.log(`    Price: ${pr.region} ${pr.currency} ${pr.amount}`);
      }
    }
  }

  console.log('\n--- STEP 9: LESSON DETAIL GET ENDPOINT VERIFICATION ---');
  const demoLessons = [
    'seed-lesson-solid-liquid-gas',
    'seed-lesson-intro-whole-numbers',
    'seed-lesson-parts-of-speech',
  ];

  for (const lessonId of demoLessons) {
    const l = await prisma.lesson.findUnique({
      where: { id: lessonId },
      include: { chapter: { include: { subject: true } } },
    });
    if (!l) {
      throw new Error(`Lesson ${lessonId} NOT FOUND!`);
    }
    console.log(`Lesson found: [${l.id}] ${l.title} in ${l.chapter.subject.name} -> ${l.chapter.name}`);
  }

  console.log('\nAll verification steps PASSED successfully!');
}

verify()
  .catch((e) => {
    console.error('Verification failed:', e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
