import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const grades = await prisma.grade.findMany({
    include: {
      subjects: {
        include: {
          chapters: {
            include: {
              lessons: true
            }
          }
        }
      },
      products: true,
      enrollments: true,
      students: true,
      assessments: true,
      liveClasses: true,
      batches: true,
    }
  });

  console.log(`Found ${grades.length} total grades in DB:`);
  for (const g of grades) {
    console.log(`- ID: ${g.id} | Name: "${g.name}" | Board: ${g.board}`);
    console.log(`  Subjects: ${g.subjects.length} (${g.subjects.map(s => s.name + ' [' + s.id + ']').join(', ')})`);
    console.log(`  Products: ${g.products.length}`);
    console.log(`  Enrollments: ${g.enrollments.length}`);
    console.log(`  Students: ${g.students.length}`);
    console.log(`  Assessments: ${g.assessments.length}`);
    console.log(`  LiveClasses: ${g.liveClasses.length}`);
    console.log(`  Batches: ${g.batches.length}`);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
