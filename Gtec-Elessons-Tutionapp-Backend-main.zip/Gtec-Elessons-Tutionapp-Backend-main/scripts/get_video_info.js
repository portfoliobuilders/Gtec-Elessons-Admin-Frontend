const https = require('https');

function getVideoInfo(videoId) {
  return new Promise((resolve) => {
    https.get(`https://www.youtube.com/watch?v=${videoId}`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        // Extract og:title
        const titleMatch = data.match(/"title":"([^"]+)"/);
        // Extract og:description
        const descMatch = data.match(/"shortDescription":"(.*?)","(?:isCrawlable|lengthSeconds)"/s);
        // Extract channel
        const channelMatch = data.match(/"ownerChannelName":"([^"]+)"/);
        // Extract category
        const categoryMatch = data.match(/"category":"([^"]+)"/);
        // Video title from meta
        const ogTitle = data.match(/<meta property="og:title" content="([^"]+)"/);
        const ogDesc = data.match(/<meta property="og:description" content="([^"]+)"/);

        resolve({
          videoId,
          title: ogTitle ? ogTitle[1] : (titleMatch ? titleMatch[1] : 'Not found'),
          description: ogDesc ? ogDesc[1].substring(0, 400) : (descMatch ? descMatch[1].substring(0, 400) : 'Not found'),
          channel: channelMatch ? channelMatch[1] : 'Not found',
          category: categoryMatch ? categoryMatch[1] : 'Not found',
        });
      });
    }).on('error', (err) => resolve({ videoId, error: err.message }));
  });
}

async function main() {
  console.log('Checking video: AjG4xIDWmRo (Chemistry)');
  const chem = await getVideoInfo('AjG4xIDWmRo');
  console.log(JSON.stringify(chem, null, 2));

  console.log('\nChecking video: jd_EIuOhkIU (Maths)');
  const maths = await getVideoInfo('jd_EIuOhkIU');
  console.log(JSON.stringify(maths, null, 2));
}

main();
