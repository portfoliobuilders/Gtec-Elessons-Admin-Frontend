const http = require('http');

function makeRequest(options, body) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function main() {
  // Login as admin
  const loginBody = JSON.stringify({ email: 'admin@gtec.dev' });
  const loginRes = await makeRequest({
    hostname: 'localhost', port: 3000, path: '/api/auth/dev-login', method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(loginBody) }
  }, loginBody);

  const token = loginRes.body.accessToken;

  // Try various catalog endpoints to find the right one
  const endpoints = [
    '/api/catalog',
    '/api/admin/catalog',
    '/api/catalog/grade',
    '/api/admin/grades',
    '/api/grades',
    '/api/admin/products',
    '/api/products',
  ];

  for (const ep of endpoints) {
    const res = await makeRequest({
      hostname: 'localhost', port: 3000, path: ep, method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` }
    }, null);
    console.log(`${ep} -> ${res.status}`);
    if (res.status !== 404) {
      console.log('BODY:', JSON.stringify(res.body).substring(0, 500));
    }
  }
}

main().catch(console.error);
