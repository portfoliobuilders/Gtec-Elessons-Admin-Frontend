import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const lessons = await prisma.lesson.findMany({
    include: {
      chapter: {
        include: {
          subject: {
            include: {
              grade: true
            }
          }
        }
      }
    }
  });

  console.log(`Found ${lessons.length} lessons:`);
  for (const l of lessons) {
    console.log(`- Lesson ID: ${l.id} | Title: "${l.title}"`);
    console.log(`  Chapter: ${l.chapter.name} (${l.chapter.id})`);
    console.log(`  Subject: ${l.chapter.subject.name} (${l.chapter.subject.id})`);
    console.log(`  Grade: ${l.chapter.subject.grade.name} (${l.chapter.subject.grade.id})`);
    console.log(`  Current youtubeId: ${l.youtubeId}`);
    console.log('---');
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
