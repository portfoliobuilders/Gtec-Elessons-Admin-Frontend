require('dotenv').config();
const Stripe = require('stripe');

async function testStripeCall() {
  console.log('Reading STRIPE_SECRET_KEY from process.env:');
  const key = process.env.STRIPE_SECRET_KEY;
  console.log('Key defined:', !!key);
  if (key) {
    console.log('Key prefix:', key.substring(0, 10));
    console.log('Key length:', key.length);
  }

  const stripe = new Stripe(key || '', {
    apiVersion: '2024-06-20',
  });

  try {
    console.log('\nAttempting stripe.checkout.sessions.create...');
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'inr',
            product_data: { name: 'Test Product' },
            unit_amount: 1000,
          },
          quantity: 1,
        },
      ],
      success_url: 'http://localhost:3000/success',
      cancel_url: 'http://localhost:3000/cancel',
    });
    console.log('Success! Session ID:', session.id);
  } catch (err) {
    console.log('\n=== EXACT STRIPE ERROR RETURNED ===');
    console.log('Type:', err.type);
    console.log('Code:', err.code);
    console.log('StatusCode:', err.statusCode);
    console.log('Message:', err.message);
    console.log('Full Error Object:\n', JSON.stringify(err, null, 2));
  }
}

testStripeCall();
