const http = require('http');

function makeRequest(options, body) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function main() {
  // 1. GET /api/grades — fee catalog verification
  const gradesRes = await makeRequest({
    hostname: 'localhost', port: 3000, path: '/api/grades', method: 'GET', headers: {}
  }, null);
  console.log('\n=== GET /api/grades ===');
  console.log('Status:', gradesRes.status);
  console.log(JSON.stringify(gradesRes.body, null, 2));

  // 2. GET specific grades to see products
  const gradeIds = ['seed-grade-8', 'seed-grade-ix', 'seed-grade-x', 'seed-grade-plus-one', 'seed-grade-plus-two'];
  for (const gid of gradeIds) {
    const res = await makeRequest({
      hostname: 'localhost', port: 3000, path: `/api/grades/${gid}?currency=INR`, method: 'GET', headers: {}
    }, null);
    console.log(`\n=== Grade ${gid} ===`);
    if (res.body && res.body.products) {
      const prices = res.body.products.map(p => ({
        title: p.title,
        type: p.type,
        price: p.prices?.[0]?.amountCents ? `₹${p.prices[0].amountCents / 100}` : 'N/A'
      }));
      console.log(JSON.stringify(prices, null, 2));
    } else {
      console.log(JSON.stringify(res.body, null, 2).substring(0, 800));
    }
  }
}

main().catch(console.error);
