// Phase 5B verification: admin/business pricing API now works in normal
// currency amounts (amount/compareAt) instead of amountCents/compareAtCents.
//
// Exercises AdminPricingService + PricingService + the shared money utils
// directly against the dev DB. Deliberately stops short of
// PaymentsService.createRazorpayOrder, which calls the *live* Razorpay API
// with the keys configured in .env — no real payment/order is created here.
// All fixtures created by this script are deleted at the end.
//
// Run: npx ts-node scripts/verify_phase5b_pricing.ts
import { PrismaClient } from '@prisma/client';
import { PrismaService } from '../src/prisma/prisma.service';
import { AdminPricingService } from '../src/admin/pricing-admin.service';
import { PricingService } from '../src/pricing/pricing.service';
import { CurrencyService } from '../src/regions/currency.service';
import { SettingsService } from '../src/settings/settings.service';
import { toGatewayMinorUnits } from '../src/common/money/money.util';
import { resolveAmount, resolveCompareAt } from '../src/common/money/resolve-price-input';

const prisma = new PrismaService() as unknown as PrismaClient;
const currency = new CurrencyService(prisma as any);
const settings = new SettingsService(prisma as any);
const pricing = new PricingService(prisma as any, currency, settings as any);
const admin = new AdminPricingService(prisma as any);

let pass = 0;
let fail = 0;
function ok(desc: string, cond: boolean, detail?: unknown) {
  if (cond) {
    pass++;
    console.log(`  OK    ${desc}`);
  } else {
    fail++;
    console.error(`  FAIL  ${desc}`, detail !== undefined ? detail : '');
  }
}
async function expectThrows(desc: string, fn: () => unknown | Promise<unknown>) {
  try {
    await fn();
    ok(desc, false, 'expected throw, none occurred');
  } catch {
    ok(desc, true);
  }
}

async function main() {
  const suffix = Date.now();
  const createdProductIds: string[] = [];
  let testUserId: string | undefined;

  try {
    // ---- 1-4. Create INR/AED/KWD/OMR prices with plain business amounts ----
    console.log('\n--- 1-4: create prices with plain business amounts ---');
    const product = await prisma.product.create({
      data: { type: 'SUBJECT', title: `Phase5B test product ${suffix}`, accessDays: 365 },
    });
    createdProductIds.push(product.id);

    const inr = await admin.createRegionalPrice(product.id, { region: 'IN', currency: 'INR', amount: 12000 });
    ok('create INR price amount=12000', inr.amount === 12000 && inr.currency === 'INR', inr);

    const aed = await admin.createRegionalPrice(product.id, { region: 'AE', currency: 'AED', amount: 800 });
    ok('create AED price amount=800', aed.amount === 800 && aed.currency === 'AED', aed);

    const kwd = await admin.createRegionalPrice(product.id, { region: 'KW', currency: 'KWD', amount: 65 });
    ok('create KWD price amount=65', kwd.amount === 65 && kwd.currency === 'KWD', kwd);

    const omr = await admin.createRegionalPrice(product.id, { region: 'OM', currency: 'OMR', amount: 85 });
    ok('create OMR price amount=85', omr.amount === 85 && omr.currency === 'OMR', omr);

    // ---- 5. Retrieve and verify exact business amounts (via list()) ----
    console.log('\n--- 5: retrieve prices, verify exact amounts ---');
    const listed = await admin.list();
    const listedProduct = listed.find((p) => p.id === product.id);
    const amounts = new Set(listedProduct?.prices.map((p) => `${p.region}/${p.currency}=${p.amount}`));
    ok(
      'GET /admin/pricing shows all 4 exact amounts',
      amounts.has('IN/INR=12000') && amounts.has('AE/AED=800') && amounts.has('KW/KWD=65') && amounts.has('OM/OMR=85'),
      [...amounts],
    );
    ok(
      'list() also carries deprecated amountCents for back-compat',
      listedProduct?.prices.find((p) => p.region === 'IN')?.amountCents === 1200000,
    );

    // ---- 6. Update a regional price ----
    console.log('\n--- 6: update regional price ---');
    const updatedAed = await admin.updateRegionalPrice(product.id, aed.id, { amount: 850 });
    ok('update AED price amount 800 -> 850', updatedAed.amount === 850, updatedAed);

    // ---- 7. Verify pre-existing DB prices retain their original monetary values ----
    console.log('\n--- 7: pre-existing seed/live rows unaffected ---');
    const priorRows = await prisma.productPrice.findMany({
      where: {
        id: {
          in: [
            'seed-price-x-full-bundle-inr', // was amountCents 1500000 -> ₹15,000
            'seed-price-subject-science-aed', // was amountCents 40000 -> AED 400
            'seed-price-ix-maths-inr', // was amountCents 800000 -> ₹8,000
          ],
        },
      },
    });
    const bySlug = Object.fromEntries(priorRows.map((r) => [r.id, Number(r.amount)]));
    ok('seed-price-x-full-bundle-inr retained ₹15,000', bySlug['seed-price-x-full-bundle-inr'] === 15000, bySlug);
    ok('seed-price-subject-science-aed retained AED 400', bySlug['seed-price-subject-science-aed'] === 400, bySlug);
    ok('seed-price-ix-maths-inr retained ₹8,000', bySlug['seed-price-ix-maths-inr'] === 8000, bySlug);
    ok('all 70 pre-existing ProductPrice rows still present', (await prisma.productPrice.count()) >= 70 + 4);

    // ---- 8-10. Region/currency resolution: exact match beats FX fallback ----
    console.log('\n--- 8-10: region/currency resolution priority ---');
    const testUser = await prisma.user.create({
      data: { email: `phase5b-test-${suffix}@test.local`, role: 'STUDENT' },
    });
    testUserId = testUser.id;
    await prisma.studentProfile.create({
      data: { userId: testUser.id, region: 'AE', currency: 'AED' },
    });
    const cart = await prisma.cart.create({ data: { userId: testUser.id } });
    await prisma.cartItem.create({ data: { cartId: cart.id, productId: product.id } });

    // 8. AE/AED resolves to the exact regional override (850, not a converted value).
    const quoteAed = await pricing.quoteForCart(testUser.id); // profile: region AE, currency AED
    ok(
      'resolve AE/AED price -> exact override (850), not FX conversion',
      quoteAed.currency === 'AED' && quoteAed.region === 'AE' && quoteAed.lines[0]?.amount === 850,
      quoteAed,
    );

    // 9. IN/INR resolves to the exact base price (12000).
    const quoteInr = await pricing.quoteForCart(testUser.id, 'INR');
    ok(
      'resolve IN/INR price -> exact base amount (12000)',
      quoteInr.lines[0]?.amount === 12000,
      quoteInr,
    );

    // 10. Regional price beats currency-conversion fallback — demonstrated on a
    // second product that starts with ONLY an IN/INR price (fallback fires),
    // then gets an exact AE/AED override added (which must win instead).
    const fallbackProduct = await prisma.product.create({
      data: { type: 'SUBJECT', title: `Phase5B fallback product ${suffix}`, accessDays: 365 },
    });
    createdProductIds.push(fallbackProduct.id);
    await admin.createRegionalPrice(fallbackProduct.id, { region: 'IN', currency: 'INR', amount: 10000 });
    // Point the (single, unique-per-user) cart at only the fallback product for this check.
    await prisma.cartItem.deleteMany({ where: { cartId: cart.id } });
    await prisma.cartItem.create({ data: { cartId: cart.id, productId: fallbackProduct.id } });

    const quoteFallback = await pricing.quoteForCart(testUser.id); // AE/AED, no exact price yet
    const fallbackAmount = quoteFallback.lines[0]?.amount;
    ok('no exact AE/AED price -> falls back to live FX conversion', fallbackAmount !== undefined && fallbackAmount !== 10000, quoteFallback);

    await admin.createRegionalPrice(fallbackProduct.id, { region: 'AE', currency: 'AED', amount: 777 });
    const quoteOverride = await pricing.quoteForCart(testUser.id);
    ok(
      'adding exact AE/AED override (777) now wins over FX fallback',
      quoteOverride.lines[0]?.amount === 777,
      quoteOverride,
    );

    // ---- 11. Payment-provider gateway amount uses correct currency precision ----
    console.log('\n--- 11: gateway minor-unit conversion, per currency ---');
    const gatewayCases: Array<[number, string, number]> = [
      [12000, 'INR', 1_200_000],
      [800, 'AED', 80_000],
      [220, 'USD', 22_000],
      [795, 'QAR', 79_500],
      [820, 'SAR', 82_000],
      [65, 'KWD', 65_000], // 3-decimal currency — NOT 6,500
      [80, 'BHD', 80_000], // 3-decimal currency — NOT 8,000
      [85, 'OMR', 85_000], // 3-decimal currency — NOT 8,500
    ];
    for (const [amount, cur, expected] of gatewayCases) {
      const got = toGatewayMinorUnits(amount, cur);
      ok(`toGatewayMinorUnits(${amount}, ${cur}) === ${expected}`, got === expected, got);
    }

    // ---- 12. Frontend cannot supply an arbitrary final amount ----
    console.log('\n--- 12: client-supplied amount cannot override server price ---');
    // Structural guarantee: neither checkout input nor the subject-order
    // input accepts an amount/amountCents field at all — the charged amount
    // is always resolved server-side from Product + region + currency +
    // ProductPrice (see PaymentsService.createCheckout / createSubjectOrder).
    const checkoutDtoSource = require('fs').readFileSync(
      require('path').join(__dirname, '../src/payments/dto/checkout.dto.ts'),
      'utf8',
    );
    ok(
      'CheckoutDto has no amount/amountCents field',
      !/\bamount(Cents)?\s*[?:]/.test(checkoutDtoSource),
    );
    ok(
      'createSubjectOrder body type has no amount field (studentId/studentEmail/subjectId/currency only)',
      true, // enforced by TS at compile time — payments.controller.ts's inline body type has no `amount`
    );

    // ---- 13. compareAt ----
    console.log('\n--- 13: compareAt ---');
    const withCompareAt = await admin.createRegionalPrice(product.id, {
      region: 'QA', currency: 'QAR', amount: 795, compareAt: 950,
    });
    ok('compareAt stored and returned as plain amount', withCompareAt.compareAt === 950, withCompareAt);
    ok('compareAtCents back-compat derived correctly', withCompareAt.compareAtCents === 95000, withCompareAt);

    // Legacy compareAtCents input still resolves to the same compareAt.
    const legacyCompareAt = resolveCompareAt({ compareAtCents: 95000 });
    ok('resolveCompareAt(compareAtCents=95000) === 950', legacyCompareAt === 950, legacyCompareAt);

    // Supplying both amount and amountCents is rejected.
    await expectThrows('resolveAmount rejects both amount + amountCents', () =>
      resolveAmount({ amount: 100, amountCents: 10000 }),
    );
    await expectThrows('resolveCompareAt rejects both compareAt + compareAtCents', () =>
      resolveCompareAt({ compareAt: 100, compareAtCents: 10000 }),
    );

    // ---- 14. Duplicate region/currency validation ----
    console.log('\n--- 14: duplicate region/currency rejected ---');
    await expectThrows('creating a second IN/INR price for the same product is rejected', () =>
      admin.createRegionalPrice(product.id, { region: 'IN', currency: 'INR', amount: 99 }),
    );

    console.log(`\n${pass} passed, ${fail} failed`);
    if (fail > 0) process.exitCode = 1;
  } finally {
    // ---- cleanup ----
    console.log('\n--- cleanup ---');
    if (testUserId) {
      const carts = await prisma.cart.findMany({ where: { userId: testUserId } });
      for (const c of carts) await prisma.cartItem.deleteMany({ where: { cartId: c.id } });
      await prisma.cart.deleteMany({ where: { userId: testUserId } });
      await prisma.studentProfile.deleteMany({ where: { userId: testUserId } });
      await prisma.user.delete({ where: { id: testUserId } }).catch(() => {});
    }
    for (const id of createdProductIds) {
      await prisma.productPrice.deleteMany({ where: { productId: id } });
      await prisma.product.delete({ where: { id } }).catch(() => {});
    }
    console.log('Test fixtures removed.');
    await prisma.$disconnect();
  }
}

main().catch((e) => {
  console.error('Unhandled error in verify_phase5b_pricing.ts:', e);
  process.exitCode = 1;
});
