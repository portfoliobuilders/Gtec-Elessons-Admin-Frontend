const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function run() {
  console.log('=== CHECKING admin@gtec.dev IN DATABASE ===');
  const admin = await prisma.user.findUnique({ where: { email: 'admin@gtec.dev' } });
  if (!admin) {
    console.log('RESULT: admin@gtec.dev does NOT exist in the database.');
    console.log('When dev-login is called for this email, it CREATES the user with:');
    console.log('  - name: "Test Student"');
    console.log('  - role: STUDENT (the Role enum default in schema.prisma)');
    console.log('  - googleId: "dev-admin@gtec.dev"');
    console.log('  - studentProfile: { created }');
    console.log('');
    console.log('This means the session returned has role=STUDENT, not ADMIN.');
    console.log('If the caller then hits an ADMIN-only endpoint, they get 403.');
  } else {
    console.log('FOUND user:');
    console.log('  ID:', admin.id);
    console.log('  Email:', admin.email);
    console.log('  Name:', admin.name);
    console.log('  Role:', admin.role);
    console.log('  Status:', admin.status);
    console.log('  passwordHash:', admin.passwordHash ? '(set)' : 'null');
    console.log('  googleId:', admin.googleId);
    console.log('  createdAt:', admin.createdAt);
  }

  console.log('\n=== ALL USERS IN DB ===');
  const all = await prisma.user.findMany({ select: { id: true, email: true, name: true, role: true, status: true, createdAt: true } });
  all.forEach(u => console.log(u));
}

run().catch(console.error).finally(() => prisma.$disconnect());
