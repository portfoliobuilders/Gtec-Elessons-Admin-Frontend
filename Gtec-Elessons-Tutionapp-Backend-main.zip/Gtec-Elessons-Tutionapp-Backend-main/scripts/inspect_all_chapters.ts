import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const chapters = await prisma.chapter.findMany({
    include: {
      subject: true,
      lessons: true
    }
  });

  console.log(`Found ${chapters.length} chapters:`);
  for (const c of chapters) {
    console.log(`- Chapter: ${c.name} (${c.id}) under Subject: ${c.subject.name} (${c.subject.id}, Grade: ${c.subject.gradeId})`);
    console.log(`  Lessons count: ${c.lessons.length}`);
    for (const l of c.lessons) {
      console.log(`    Lesson: ${l.title} (${l.id}) | youtubeId: ${l.youtubeId}`);
    }
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
