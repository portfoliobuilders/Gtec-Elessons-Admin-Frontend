const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const TARGET_SUBJECTS = {
  Science: { id: 'cms1f4vq90005pjh8451hj76h', priceINR: 800000 },  // ₹8,000 in cents
  Maths:   { id: 'cms1f4vr6000bpjh8l9o6i16e', priceINR: 800000 },  // ₹8,000 in cents
  English: { id: 'cms1f4vrs000hpjh86k02atp5', priceINR: 400000 },  // ₹4,000 in cents
};

async function run() {
  // 1. Show ALL products with their prices and subject links
  console.log('=== ALL PRODUCTS IN DB ===');
  const products = await prisma.product.findMany({
    include: {
      prices: true,
      subject: { select: { id: true, name: true, code: true } },
      grade:   { select: { id: true, name: true } },
    },
    orderBy: { type: 'asc' },
  });
  console.log(`Total products: ${products.length}`);
  products.forEach(p => {
    const price = p.prices[0];
    const priceFmt = price ? `₹${(price.amountCents / 100).toLocaleString('en-IN')}` : 'NO PRICE';
    const scope = p.subject
      ? `Subject: "${p.subject.name}" (${p.subject.code}) [${p.subject.id}]`
      : p.grade
        ? `Grade: "${p.grade.name}" [${p.grade.id}]`
        : 'NO SCOPE';
    console.log(`  [${p.type}] "${p.title}" → ${scope} → ${priceFmt}`);
  });

  // 2. Check specifically if our three subjects already have products linked
  console.log('\n=== SUBJECT-LEVEL PRODUCTS FOR GRADE VIII ===');
  const subjectProducts = await prisma.product.findMany({
    where: {
      type: 'SUBJECT',
      subjectId: { in: Object.values(TARGET_SUBJECTS).map(s => s.id) },
    },
    include: { prices: true, subject: true },
  });
  console.log(`Found ${subjectProducts.length} SUBJECT-type products linked to our 3 subjects`);
  subjectProducts.forEach(p => {
    console.log(`  productId=${p.id} | subject="${p.subject?.name}" | prices=${JSON.stringify(p.prices)}`);
  });

  // 3. Check if there are SUBJECT products for Grade VIII with NO subjectId (orphaned)
  const grade8 = await prisma.grade.findFirst({ where: { name: 'Grade VIII' } });
  const orphanedSubjectProducts = await prisma.product.findMany({
    where: { type: 'SUBJECT', gradeId: grade8?.id, subjectId: null },
    include: { prices: true },
  });
  console.log(`\n=== ORPHANED SUBJECT PRODUCTS (gradeId=Grade VIII, no subjectId) ===`);
  console.log(`Found ${orphanedSubjectProducts.length}`);
  orphanedSubjectProducts.forEach(p => {
    console.log(`  productId=${p.id} | title="${p.title}" | prices=${JSON.stringify(p.prices)}`);
  });

  // 4. Check ALL products for Grade VIII
  const grade8Products = await prisma.product.findMany({
    where: { gradeId: grade8?.id },
    include: { prices: true, subject: true },
  });
  console.log(`\n=== ALL PRODUCTS SCOPED TO GRADE VIII ===`);
  console.log(`Found ${grade8Products.length}`);
  grade8Products.forEach(p => {
    console.log(`  [${p.type}] productId=${p.id} | title="${p.title}" | subject=${p.subject?.name ?? 'null'} | prices=${JSON.stringify(p.prices.map(pr => pr.amountCents))}`);
  });
}

run().catch(console.error).finally(() => prisma.$disconnect());
