const fs = require('fs');
const path = require('path');

const found = [];

function search(dir, depth = 0) {
  if (depth > 6) return;
  try {
    const list = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of list) {
      if (item.name === 'node_modules' || item.name === 'flutter' || item.name === 'AppData') continue;
      const p = path.join(dir, item.name);
      if (item.isFile() && item.name.endsWith('.dart')) {
        found.push(p);
      } else if (item.isDirectory()) {
        search(p, depth + 1);
      }
    }
  } catch (e) {}
}

console.log('Deep scanning for Dart files...');
search('C:\\Users\\parva\\OneDrive');
search('C:\\Users\\parva\\Downloads');
search('C:\\Users\\parva\\Desktop');
search('C:\\Users\\parva\\Documents');
search('C:\\Users\\parva\\backend');
search('C:\\Users\\parva\\GTech');
search('C:\\dev');

console.log('Dart files found (total ' + found.length + '):');
found.forEach(f => console.log(' ->', f));
