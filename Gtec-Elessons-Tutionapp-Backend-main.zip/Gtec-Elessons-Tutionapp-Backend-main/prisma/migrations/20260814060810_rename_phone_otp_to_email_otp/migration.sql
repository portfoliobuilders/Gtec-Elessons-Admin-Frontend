-- Login OTP switches identifier from phone to email (delivery moves from an
-- unwired SMS stub to the real MailService). No production data exists for
-- this table yet (feature was never wired to a real delivery provider), so
-- this is a straight drop+recreate rather than a column rename+backfill.

-- DropTable
DROP TABLE "PhoneOtp";

-- CreateTable
CREATE TABLE "EmailOtp" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "codeHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "consumed" BOOLEAN NOT NULL DEFAULT false,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "EmailOtp_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "EmailOtp_email_idx" ON "EmailOtp"("email");
