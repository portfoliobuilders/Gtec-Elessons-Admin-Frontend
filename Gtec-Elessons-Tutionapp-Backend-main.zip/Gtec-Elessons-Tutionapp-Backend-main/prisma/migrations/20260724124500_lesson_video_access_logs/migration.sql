-- CreateTable
CREATE TABLE "LessonVideoAccessLog" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "lessonId" TEXT,
    "requestedLessonId" TEXT NOT NULL,
    "success" BOOLEAN NOT NULL,
    "reason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "LessonVideoAccessLog_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "LessonVideoAccessLog_userId_createdAt_idx" ON "LessonVideoAccessLog"("userId", "createdAt");

-- CreateIndex
CREATE INDEX "LessonVideoAccessLog_requestedLessonId_createdAt_idx" ON "LessonVideoAccessLog"("requestedLessonId", "createdAt");

-- CreateIndex
CREATE INDEX "LessonVideoAccessLog_success_createdAt_idx" ON "LessonVideoAccessLog"("success", "createdAt");

-- AddForeignKey
ALTER TABLE "LessonVideoAccessLog" ADD CONSTRAINT "LessonVideoAccessLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LessonVideoAccessLog" ADD CONSTRAINT "LessonVideoAccessLog_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES "Lesson"("id") ON DELETE SET NULL ON UPDATE CASCADE;
