-- CreateIndex
CREATE UNIQUE INDEX "Grade_name_board_key" ON "Grade"("name", "board");
