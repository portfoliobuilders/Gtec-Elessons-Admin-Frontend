-- AlterTable
ALTER TABLE "Assessment" ADD COLUMN     "negativeMarking" DOUBLE PRECISION DEFAULT 0,
ADD COLUMN     "shuffleQuestions" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "AssessmentAttempt" ALTER COLUMN "score" SET DATA TYPE DOUBLE PRECISION;
