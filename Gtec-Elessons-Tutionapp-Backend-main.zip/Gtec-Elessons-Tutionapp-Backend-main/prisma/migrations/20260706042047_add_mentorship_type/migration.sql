-- AlterEnum
ALTER TYPE "ProductType" ADD VALUE 'MENTORSHIP';
