-- Add optional preview/trailer video metadata to curriculum levels above lessons.
ALTER TABLE "Grade"
ADD COLUMN "trailerYoutubeId" TEXT,
ADD COLUMN "trailerThumbnailUrl" TEXT;

ALTER TABLE "Subject"
ADD COLUMN "trailerYoutubeId" TEXT,
ADD COLUMN "trailerThumbnailUrl" TEXT;

ALTER TABLE "Chapter"
ADD COLUMN "trailerYoutubeId" TEXT,
ADD COLUMN "trailerThumbnailUrl" TEXT;
