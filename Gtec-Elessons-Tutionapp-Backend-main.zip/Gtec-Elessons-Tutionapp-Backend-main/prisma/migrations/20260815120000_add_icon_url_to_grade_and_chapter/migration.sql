-- AlterTable
ALTER TABLE "Chapter" ADD COLUMN     "iconUrl" TEXT;

-- AlterTable
ALTER TABLE "Grade" ADD COLUMN     "iconUrl" TEXT;
