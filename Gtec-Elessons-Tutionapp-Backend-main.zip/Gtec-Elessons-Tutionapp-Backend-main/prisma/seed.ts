// Seeds the G-TEC fee catalog, demo curriculum (Grade VIII: Science, Maths, English),
// admin configuration, and initial test accounts (teacher@gtec.dev, teststudent99@gmail.com).
// All entities use fixed, permanent string IDs so re-running the seed updates rows in place.
// Run: npm run prisma:seed
import { PrismaClient, ProductType, ProductFormat } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();
const rupees = (n: number) => n; // Phase 5B: amount is business-currency decimal (e.g. 12000 for ₹12,000), not minor units

async function priceUpsert(id: string, productId: string, region: string, currency: string, amount: number) {
  return prisma.productPrice.upsert({
    where: { id },
    update: { productId, region, currency, amount },
    create: { id, productId, region, currency, amount },
  });
}

const CLASSES = [
  { name: 'VIII', slug: '8', order: 1, fullBundle: 12000, mentorship: 6000, recorded: 4000, recMentor: 5500 },
  { name: 'IX', slug: 'ix', order: 2, fullBundle: 12000, mentorship: 6000, maths: 8000, science: 8000, english: 4000, recorded: 4000, recMentor: 5500 },
  { name: 'X', slug: 'x', order: 3, fullBundle: 15000, mentorship: 7000, maths: 8000, science: 8000, english: 4000, recorded: 5000, recMentor: 7000 },
  { name: 'Plus One', slug: 'plus-one', order: 4, fullBundle: 18000, mentorship: 10000, maths: 10000, science: 10000, english: 4000, recorded: 6000, recMentor: 8000 },
  { name: 'Plus Two', slug: 'plus-two', order: 5, fullBundle: 18000, mentorship: 10000, maths: 10000, science: 10000, english: 4000, recorded: 6000, recMentor: 8000 },
];

async function seedUsers() {
  console.log('Seeding user accounts…');

  // Clean up legacy non-fixed ID user records if email matches to avoid unique key conflicts
  await prisma.user.deleteMany({
    where: {
      email: { in: ['teacher@gtec.dev', 'admin@gtec.dev', 'teststudent99@gmail.com'] },
      id: { notIn: ['seed-user-teacher', 'seed-user-admin', 'seed-user-student'] },
    },
  });

  const teacherPasswordHash = await bcrypt.hash('Teacher1234', 10);
  const teacher = await prisma.user.upsert({
    where: { id: 'seed-user-teacher' },
    update: {
      email: 'teacher@gtec.dev',
      role: 'TEACHER',
      name: 'Teacher G-TEC',
      passwordHash: teacherPasswordHash,
    },
    create: {
      id: 'seed-user-teacher',
      email: 'teacher@gtec.dev',
      name: 'Teacher G-TEC',
      role: 'TEACHER',
      passwordHash: teacherPasswordHash,
    },
  });

  const adminPasswordHash = await bcrypt.hash('Admin1234', 10);
  const admin = await prisma.user.upsert({
    where: { id: 'seed-user-admin' },
    update: {
      email: 'admin@gtec.dev',
      role: 'SUPER_ADMIN',
      name: 'Admin User',
      googleId: 'dev-admin@gtec.dev',
      passwordHash: adminPasswordHash,
    },
    create: {
      id: 'seed-user-admin',
      email: 'admin@gtec.dev',
      name: 'Admin User',
      role: 'SUPER_ADMIN',
      googleId: 'dev-admin@gtec.dev',
      passwordHash: adminPasswordHash,
    },
  });

  const studentPasswordHash = await bcrypt.hash('Test1234', 10);
  const student = await prisma.user.upsert({
    where: { id: 'seed-user-student' },
    update: {
      email: 'teststudent99@gmail.com',
      name: 'Test Student',
      googleId: 'dev-teststudent99@gmail.com',
      passwordHash: studentPasswordHash,
      role: 'STUDENT',
    },
    create: {
      id: 'seed-user-student',
      email: 'teststudent99@gmail.com',
      name: 'Test Student',
      googleId: 'dev-teststudent99@gmail.com',
      passwordHash: studentPasswordHash,
      role: 'STUDENT',
    },
  });

  await prisma.studentProfile.upsert({
    where: { userId: student.id },
    update: { region: 'IN', currency: 'INR', board: 'CBSE', onboarded: true },
    create: {
      id: 'seed-profile-student',
      userId: student.id,
      region: 'IN',
      currency: 'INR',
      board: 'CBSE',
      onboarded: true,
    },
  });

  console.log('Users seeded:', { teacherId: teacher.id, adminId: admin.id, studentId: student.id });
  return { teacher, admin, student };
}

async function seedDemoCurriculum(teacher: { id: string; name: string | null }) {
  console.log('Seeding demo curriculum for Grade VIII…');

  const grade = await prisma.grade.upsert({
    where: { name_board: { name: 'Grade VIII', board: 'CBSE' } },
    update: { id: 'seed-grade-8', order: 1, isActive: true },
    create: { id: 'seed-grade-8', name: 'Grade VIII', board: 'CBSE', order: 1, isActive: true },
  });

  const DEMO_SUBJECTS = [
    {
      id: 'seed-subject-science',
      name: 'Science',
      code: 'SCI8',
      order: 0,
      chapterId: 'seed-chapter-states-of-matter',
      chapterName: 'States of Matter',
      lessonId: 'seed-lesson-solid-liquid-gas',
      lessonTitle: 'Solid, Liquid, and Gas',
      youtubeId: 'F0pG79qCE9c',
      productId: 'seed-product-subject-science',
      priceInrId: 'seed-price-subject-science-inr',
      priceAedId: 'seed-price-subject-science-aed',
      priceInr: 8000,
      priceAed: 400,
    },
    {
      id: 'seed-subject-maths',
      name: 'Maths',
      code: 'MATH8',
      order: 1,
      chapterId: 'seed-chapter-numbers-and-operations',
      chapterName: 'Numbers and Operations',
      lessonId: 'seed-lesson-intro-whole-numbers',
      lessonTitle: 'Introduction to Whole Numbers',
      youtubeId: 'G-_GpCm6ViQ',
      productId: 'seed-product-subject-maths',
      priceInrId: 'seed-price-subject-maths-inr',
      priceAedId: 'seed-price-subject-maths-aed',
      priceInr: 8000,
      priceAed: 400,
    },
    {
      id: 'seed-subject-english',
      name: 'English',
      code: 'ENG8',
      order: 2,
      chapterId: 'seed-chapter-grammar-fundamentals',
      chapterName: 'Grammar Fundamentals',
      lessonId: 'seed-lesson-parts-of-speech',
      lessonTitle: 'Parts of Speech',
      youtubeId: 'SceDmiBEESI',
      productId: 'seed-product-subject-english',
      priceInrId: 'seed-price-subject-english-inr',
      priceAedId: 'seed-price-subject-english-aed',
      priceInr: 4000,
      priceAed: 400,
    },
  ];

  for (const s of DEMO_SUBJECTS) {
    const subject = await prisma.subject.upsert({
      where: { id: s.id },
      update: {
        name: s.name,
        code: s.code,
        gradeId: grade.id,
        order: s.order,
        teacherId: teacher.id,
        teacherName: teacher.name ?? 'Teacher G-TEC',
      },
      create: {
        id: s.id,
        name: s.name,
        code: s.code,
        gradeId: grade.id,
        order: s.order,
        teacherId: teacher.id,
        teacherName: teacher.name ?? 'Teacher G-TEC',
      },
    });

    const chapter = await prisma.chapter.upsert({
      where: { id: s.chapterId },
      update: {
        name: s.chapterName,
        subjectId: subject.id,
        order: 0,
      },
      create: {
        id: s.chapterId,
        name: s.chapterName,
        subjectId: subject.id,
        order: 0,
      },
    });

    await prisma.lesson.upsert({
      where: { id: s.lessonId },
      update: {
        title: s.lessonTitle,
        chapterId: chapter.id,
        youtubeId: s.youtubeId,
        youtubeUrl: `https://www.youtube.com/watch?v=${s.youtubeId}`,
        isFreePreview: true,
        isPublished: true,
        order: 0,
      },
      create: {
        id: s.lessonId,
        title: s.lessonTitle,
        chapterId: chapter.id,
        youtubeId: s.youtubeId,
        youtubeUrl: `https://www.youtube.com/watch?v=${s.youtubeId}`,
        isFreePreview: true,
        isPublished: true,
        order: 0,
      },
    });

    // Seed Subject Products and Prices (PART 2)
    const product = await prisma.product.upsert({
      where: { id: s.productId },
      update: {
        type: ProductType.SUBJECT,
        format: ProductFormat.RECORDED,
        title: `Class Grade VIII — ${s.name}`,
        subjectId: subject.id,
        isActive: true,
      },
      create: {
        id: s.productId,
        type: ProductType.SUBJECT,
        format: ProductFormat.RECORDED,
        title: `Class Grade VIII — ${s.name}`,
        subjectId: subject.id,
        isActive: true,
      },
    });

    // PAN INDIA INR Price (₹)
    await priceUpsert(s.priceInrId, product.id, 'IN', 'INR', rupees(s.priceInr));

    // GCC UAE AED Price (AED)
    await priceUpsert(s.priceAedId, product.id, 'GCC', 'AED', rupees(s.priceAed));
  }

  console.log('Demo curriculum seeded successfully.');
}

async function seedDemoEnrollment(student: { id: string }) {
  console.log('Seeding demo enrollment for teststudent99@gmail.com…');

  const gradeId = 'seed-grade-8';

  const demoProduct = await prisma.product.upsert({
    where: { id: 'seed-product-grade-8-demo' },
    update: {
      type: ProductType.FULL_CLASS,
      format: ProductFormat.RECORDED,
      title: 'Grade VIII — Demo Access',
      gradeId: gradeId,
      isActive: false,
    },
    create: {
      id: 'seed-product-grade-8-demo',
      type: ProductType.FULL_CLASS,
      format: ProductFormat.RECORDED,
      title: 'Grade VIII — Demo Access',
      gradeId: gradeId,
      isActive: false,
    },
  });

  await prisma.enrollment.upsert({
    where: { id: 'seed-enrollment-demo' },
    update: {
      userId: student.id,
      productId: demoProduct.id,
      scopeType: ProductType.FULL_CLASS,
      gradeId: gradeId,
      format: ProductFormat.RECORDED,
      status: 'ACTIVE',
    },
    create: {
      id: 'seed-enrollment-demo',
      userId: student.id,
      productId: demoProduct.id,
      scopeType: ProductType.FULL_CLASS,
      gradeId: gradeId,
      format: ProductFormat.RECORDED,
      status: 'ACTIVE',
      startsAt: new Date('2025-01-01T00:00:00.000Z'),
      expiresAt: null,
    },
  });

  console.log('Demo enrollment created/updated: FULL_CLASS on Grade VIII, no expiry.');
}

async function main() {
  console.log('Seeding G-TEC catalog and users…');

  const { teacher, student } = await seedUsers();

  // Remove legacy non-fixed-ID rows from database on first run
  await prisma.enrollment.deleteMany({ where: { id: { not: { startsWith: 'seed-' } } } });
  await prisma.productPrice.deleteMany({ where: { id: { not: { startsWith: 'seed-' } } } });
  await prisma.product.deleteMany({ where: { id: { not: { startsWith: 'seed-' } } } });
  await prisma.lesson.deleteMany({ where: { id: { not: { startsWith: 'seed-' } } } });
  await prisma.chapter.deleteMany({ where: { id: { not: { startsWith: 'seed-' } } } });
  await prisma.subject.deleteMany({ where: { id: { not: { startsWith: 'seed-' } } } });
  await prisma.grade.deleteMany({ where: { id: { not: { startsWith: 'seed-' } } } });

  // Seed demo Grade VIII curriculum
  await seedDemoCurriculum(teacher);

  // Grant teststudent99 a permanent FULL_CLASS enrollment on Grade VIII
  await seedDemoEnrollment(student);

  // Seed standard pricing catalog classes
  for (const c of CLASSES) {
    const gradeId = `seed-grade-${c.slug}`;
    const gradeName = c.name === 'VIII' ? 'Grade VIII' : c.name;
    const grade = await prisma.grade.upsert({
      where: { name_board: { name: gradeName, board: 'CBSE' } },
      update: { id: gradeId, order: c.order, isActive: true },
      create: { id: gradeId, name: gradeName, board: 'CBSE', order: c.order, isActive: true },
    });

    // Standard Full Bundle & Mentorship Products for all classes
    const fullBundle = await prisma.product.upsert({
      where: { id: `seed-product-${c.slug}-full-bundle` },
      update: { type: ProductType.FULL_CLASS, title: `Class ${c.name} — Full Bundle`, gradeId: grade.id },
      create: { id: `seed-product-${c.slug}-full-bundle`, type: ProductType.FULL_CLASS, title: `Class ${c.name} — Full Bundle`, gradeId: grade.id },
    });
    await priceUpsert(`seed-price-${c.slug}-full-bundle-inr`, fullBundle.id, 'IN', 'INR', rupees(c.fullBundle));

    const mentorship = await prisma.product.upsert({
      where: { id: `seed-product-${c.slug}-mentorship` },
      update: { type: ProductType.MENTORSHIP, title: `Class ${c.name} — Mentorship`, gradeId: grade.id },
      create: { id: `seed-product-${c.slug}-mentorship`, type: ProductType.MENTORSHIP, title: `Class ${c.name} — Mentorship`, gradeId: grade.id },
    });
    await priceUpsert(`seed-price-${c.slug}-mentorship-inr`, mentorship.id, 'IN', 'INR', rupees(c.mentorship));

    const recorded = await prisma.product.upsert({
      where: { id: `seed-product-${c.slug}-recorded` },
      update: { type: ProductType.FULL_CLASS, format: ProductFormat.RECORDED, title: `Class ${c.name} — Recorded`, gradeId: grade.id },
      create: { id: `seed-product-${c.slug}-recorded`, type: ProductType.FULL_CLASS, format: ProductFormat.RECORDED, title: `Class ${c.name} — Recorded`, gradeId: grade.id },
    });
    await priceUpsert(`seed-price-${c.slug}-recorded-inr`, recorded.id, 'IN', 'INR', rupees(c.recorded));

    const recMentor = await prisma.product.upsert({
      where: { id: `seed-product-${c.slug}-rec-mentor` },
      update: { type: ProductType.FULL_CLASS, format: ProductFormat.LIVE_AND_RECORDED, title: `Class ${c.name} — Recorded + Mentor`, gradeId: grade.id },
      create: { id: `seed-product-${c.slug}-rec-mentor`, type: ProductType.FULL_CLASS, format: ProductFormat.LIVE_AND_RECORDED, title: `Class ${c.name} — Recorded + Mentor`, gradeId: grade.id },
    });
    await priceUpsert(`seed-price-${c.slug}-rec-mentor-inr`, recMentor.id, 'IN', 'INR', rupees(c.recMentor));

    // Per-subject products for IX, X, Plus One, Plus Two
    if (c.name !== 'VIII' && c.maths && c.science && c.english) {
      const maths = await prisma.subject.upsert({
        where: { id: `seed-subject-${c.slug}-maths` },
        update: { name: 'Maths', code: `MATH-${c.slug}`, gradeId: grade.id, order: 0 },
        create: { id: `seed-subject-${c.slug}-maths`, name: 'Maths', code: `MATH-${c.slug}`, gradeId: grade.id, order: 0 },
      });
      const science = await prisma.subject.upsert({
        where: { id: `seed-subject-${c.slug}-science` },
        update: { name: 'Science', code: `SCI-${c.slug}`, gradeId: grade.id, order: 1 },
        create: { id: `seed-subject-${c.slug}-science`, name: 'Science', code: `SCI-${c.slug}`, gradeId: grade.id, order: 1 },
      });
      const english = await prisma.subject.upsert({
        where: { id: `seed-subject-${c.slug}-english` },
        update: { name: 'English', code: `ENG-${c.slug}`, gradeId: grade.id, order: 2 },
        create: { id: `seed-subject-${c.slug}-english`, name: 'English', code: `ENG-${c.slug}`, gradeId: grade.id, order: 2 },
      });

      const mathsProduct = await prisma.product.upsert({
        where: { id: `seed-product-${c.slug}-maths` },
        update: { type: ProductType.SUBJECT, title: `Class ${c.name} — Maths`, subjectId: maths.id },
        create: { id: `seed-product-${c.slug}-maths`, type: ProductType.SUBJECT, title: `Class ${c.name} — Maths`, subjectId: maths.id },
      });
      await priceUpsert(`seed-price-${c.slug}-maths-inr`, mathsProduct.id, 'IN', 'INR', rupees(c.maths));

      const scienceProduct = await prisma.product.upsert({
        where: { id: `seed-product-${c.slug}-science` },
        update: { type: ProductType.SUBJECT, title: `Class ${c.name} — Science`, subjectId: science.id },
        create: { id: `seed-product-${c.slug}-science`, type: ProductType.SUBJECT, title: `Class ${c.name} — Science`, subjectId: science.id },
      });
      await priceUpsert(`seed-price-${c.slug}-science-inr`, scienceProduct.id, 'IN', 'INR', rupees(c.science));

      const englishProduct = await prisma.product.upsert({
        where: { id: `seed-product-${c.slug}-english` },
        update: { type: ProductType.SUBJECT, title: `Class ${c.name} — English`, subjectId: english.id },
        create: { id: `seed-product-${c.slug}-english`, type: ProductType.SUBJECT, title: `Class ${c.name} — English`, subjectId: english.id },
      });
      await priceUpsert(`seed-price-${c.slug}-english-inr`, englishProduct.id, 'IN', 'INR', rupees(c.english));
    }
  }

  const counts = {
    grades: await prisma.grade.count(),
    subjects: await prisma.subject.count(),
    products: await prisma.product.count(),
    prices: await prisma.productPrice.count(),
  };
  console.log('Seed complete:', counts);

  await seedConfig();
}

// Admin-configurable settings (Setting/Country/ExchangeRate/NotificationTemplate).
async function seedConfig() {
  console.log('Seeding admin-configurable settings…');

  const SETTINGS = [
    { key: 'gst_percent', value: '18' },
    { key: 'default_currency', value: 'INR' },
  ];
  for (const s of SETTINGS) {
    await prisma.setting.upsert({ where: { key: s.key }, update: {}, create: s });
  }

  const COUNTRIES = [
    { code: 'IN', name: 'India', currency: 'INR', symbol: '₹' },
    { code: 'AE', name: 'United Arab Emirates', currency: 'AED', symbol: 'AED' },
    { code: 'SA', name: 'Saudi Arabia', currency: 'SAR', symbol: 'SAR' },
    { code: 'QA', name: 'Qatar', currency: 'QAR', symbol: 'QAR' },
    { code: 'KW', name: 'Kuwait', currency: 'KWD', symbol: 'KWD' },
    { code: 'BH', name: 'Bahrain', currency: 'BHD', symbol: 'BHD' },
    { code: 'OM', name: 'Oman', currency: 'OMR', symbol: 'OMR' },
    { code: 'US', name: 'United States', currency: 'USD', symbol: '$' },
    { code: 'GB', name: 'United Kingdom', currency: 'GBP', symbol: '£' },
    { code: 'CA', name: 'Canada', currency: 'CAD', symbol: 'C$' },
    { code: 'AU', name: 'Australia', currency: 'AUD', symbol: 'A$' },
    { code: 'NZ', name: 'New Zealand', currency: 'NZD', symbol: 'NZ$' },
    { code: 'SG', name: 'Singapore', currency: 'SGD', symbol: 'S$' },
    { code: 'MY', name: 'Malaysia', currency: 'MYR', symbol: 'RM' },
    { code: 'LK', name: 'Sri Lanka', currency: 'LKR', symbol: 'Rs' },
    { code: 'NP', name: 'Nepal', currency: 'NPR', symbol: 'Rs' },
    { code: 'ZA', name: 'South Africa', currency: 'ZAR', symbol: 'R' },
    { code: 'DE', name: 'Germany', currency: 'EUR', symbol: '€' },
    { code: 'FR', name: 'France', currency: 'EUR', symbol: '€' },
    { code: 'IE', name: 'Ireland', currency: 'EUR', symbol: '€' },
    { code: 'JP', name: 'Japan', currency: 'JPY', symbol: '¥' },
    { code: 'CN', name: 'China', currency: 'CNY', symbol: '¥' },
  ];
  for (const c of COUNTRIES) {
    await prisma.country.upsert({ where: { code: c.code }, update: {}, create: { ...c, isActive: true } });
  }

  const RATES: Record<string, number> = {
    INR: 1, USD: 0.012, EUR: 0.011, GBP: 0.0095, AED: 0.044, SAR: 0.045,
    QAR: 0.044, KWD: 0.0037, BHD: 0.0045, OMR: 0.0046, CAD: 0.016, AUD: 0.018,
    NZD: 0.02, SGD: 0.016, MYR: 0.056, LKR: 3.6, NPR: 1.6, ZAR: 0.22, JPY: 1.9, CNY: 0.087,
  };
  for (const [currency, rateToInr] of Object.entries(RATES)) {
    await prisma.exchangeRate.upsert({ where: { currency }, update: {}, create: { currency, rateToInr } });
  }

  const TEMPLATES = [
    { type: 'DOUBT_ANSWERED', title: 'Your doubt was answered', body: '{{answer}}' },
    { type: 'PAYMENT_SUCCESS', title: 'Payment successful', body: 'Your order {{orderNumber}} is confirmed — your courses are unlocked.' },
    { type: 'PAYMENT_REFUND', title: 'Order refunded', body: 'Your order {{orderNumber}} has been refunded{{reasonSuffix}}' },
  ];
  for (const t of TEMPLATES) {
    await prisma.notificationTemplate.upsert({ where: { type: t.type }, update: {}, create: t });
  }

  console.log('Config seed complete:', {
    settings: SETTINGS.length, countries: COUNTRIES.length, rates: Object.keys(RATES).length, templates: TEMPLATES.length,
  });
}

(process.argv.includes('--config-only') ? seedConfig() : main())
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
